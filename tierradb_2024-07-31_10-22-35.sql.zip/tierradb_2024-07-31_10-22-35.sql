/*!999999\- enable the sandbox mode */ 
-- MariaDB dump 10.19  Distrib 10.5.25-MariaDB, for Linux (x86_64)
--
-- Host: localhost    Database: tierradb
-- ------------------------------------------------------
-- Server version	10.5.25-MariaDB-cll-lve

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `brands`
--

DROP TABLE IF EXISTS `brands`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `brands` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(45) NOT NULL,
  `description` text DEFAULT NULL,
  `isActive` int(11) DEFAULT 1,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `brands`
--

LOCK TABLES `brands` WRITE;
/*!40000 ALTER TABLE `brands` DISABLE KEYS */;
INSERT INTO `brands` VALUES (1,'APIVITA',NULL,0),(2,'KORRES',NULL,0),(3,'FREZY DERM',NULL,0),(4,'HELIOS',NULL,0),(5,'PHARMACEPT',NULL,0);
/*!40000 ALTER TABLE `brands` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `business_details`
--

DROP TABLE IF EXISTS `business_details`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `business_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `hours` varchar(100) NOT NULL,
  `phone` varchar(10) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `business_details`
--

LOCK TABLES `business_details` WRITE;
/*!40000 ALTER TABLE `business_details` DISABLE KEYS */;
INSERT INTO `business_details` VALUES (1,'9:00 - 17:00','6977137837');
/*!40000 ALTER TABLE `business_details` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `carts`
--

DROP TABLE IF EXISTS `carts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `carts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `dateCreated` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `carts`
--

LOCK TABLES `carts` WRITE;
/*!40000 ALTER TABLE `carts` DISABLE KEYS */;
INSERT INTO `carts` VALUES (1,'2024-05-13 16:52:36'),(2,'2024-05-13 20:31:13'),(3,'2024-05-13 20:35:00'),(4,'2024-05-14 07:26:59'),(5,'2024-05-14 09:08:50'),(6,'2024-05-14 22:16:36');
/*!40000 ALTER TABLE `carts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `carts_products`
--

DROP TABLE IF EXISTS `carts_products`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `carts_products` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `cart_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `product_initial_price` double NOT NULL,
  `product_price` double NOT NULL,
  `product_items` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `carts_products`
--

LOCK TABLES `carts_products` WRITE;
/*!40000 ALTER TABLE `carts_products` DISABLE KEYS */;
INSERT INTO `carts_products` VALUES (1,1,76,0,98,1),(2,2,76,0,98,1),(3,3,76,0,98,2),(4,4,76,0,98,1),(5,5,76,0,98,3),(6,6,76,0,98,1);
/*!40000 ALTER TABLE `carts_products` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `categories`
--

DROP TABLE IF EXISTS `categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `categories` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(45) NOT NULL,
  `description` text DEFAULT NULL,
  `isActive` int(11) DEFAULT 1,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `categories`
--

LOCK TABLES `categories` WRITE;
/*!40000 ALTER TABLE `categories` DISABLE KEYS */;
INSERT INTO `categories` VALUES (1,'NEW','fasdfasdasdfads2',1),(2,'SUMMER','kgjgkjgkjgkjgh',1),(3,'WINTER','fasdfasdfadsfds',1),(4,'SPECIAL OCCASIONS',NULL,1),(5,'OFFERS',NULL,1);
/*!40000 ALTER TABLE `categories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `categories_subcategories`
--

DROP TABLE IF EXISTS `categories_subcategories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `categories_subcategories` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `category_id` int(11) NOT NULL,
  `subcategory_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=46 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `categories_subcategories`
--

LOCK TABLES `categories_subcategories` WRITE;
/*!40000 ALTER TABLE `categories_subcategories` DISABLE KEYS */;
INSERT INTO `categories_subcategories` VALUES (35,2,3),(36,2,4),(43,1,1),(44,1,2),(45,1,3);
/*!40000 ALTER TABLE `categories_subcategories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `countries`
--

DROP TABLE IF EXISTS `countries`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `countries` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `country_code` varchar(45) NOT NULL,
  `country_name` varchar(45) NOT NULL,
  `isActive` int(11) DEFAULT 0,
  `cost` int(11) DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=230 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `countries`
--

LOCK TABLES `countries` WRITE;
/*!40000 ALTER TABLE `countries` DISABLE KEYS */;
INSERT INTO `countries` VALUES (2,'AF','Afghanistan',1,0),(3,'AL','Albania',1,0),(4,'DZ','Algeria',1,0),(5,'AS','American Samoa',1,0),(6,'AD','Andorra',1,0),(7,'AO','Angola',1,0),(8,'AI','Anguilla',1,0),(9,'AQ','Antarctica',1,0),(10,'AG','Antigua and Barbuda',1,0),(11,'AR','Argentina',1,0),(12,'AM','Armenia',1,0),(13,'AW','Aruba',1,0),(14,'AU','Australia',1,0),(15,'AT','Austria',1,0),(16,'AZ','Azerbaijan',1,0),(17,'BS','Bahamas',1,0),(18,'BH','Bahrain',1,0),(19,'BD','Bangladesh',1,0),(20,'BB','Barbados',1,0),(21,'BY','Belarus',1,0),(22,'BE','Belgium',1,0),(23,'BZ','Belize',1,0),(24,'BJ','Benin',1,0),(25,'BM','Bermuda',1,0),(26,'BT','Bhutan',1,0),(27,'BA','Bosnia and Herzegovina',1,0),(28,'BW','Botswana',1,0),(29,'BV','Bouvet Island',1,0),(30,'BR','Brazil',1,0),(31,'IO','British Indian Ocean Territory',1,0),(32,'BN','Brunei Darussalam',1,0),(33,'BG','Bulgaria',1,0),(34,'BF','Burkina Faso',1,0),(35,'BI','Burundi',1,0),(36,'KH','Cambodia',1,0),(37,'CM','Cameroon',1,0),(38,'CA','Canada',1,0),(39,'CV','Cape Verde',1,0),(40,'KY','Cayman Islands',1,0),(41,'CF','Central African Republic',1,0),(42,'TD','Chad',1,0),(43,'CL','Chile',1,0),(44,'CN','China',1,0),(45,'CX','Christmas Island',1,0),(46,'CC','Cocos (Keeling) Islands',1,0),(47,'CO','Colombia',1,0),(48,'KM','Comoros',1,0),(49,'CG','Congo',1,0),(50,'CK','Cook Islands',1,0),(51,'CR','Costa Rica',1,0),(52,'HR','Croatia',1,0),(53,'CU','Cuba',1,0),(54,'CY','Cyprus',1,0),(55,'CZ','Czech Republic',1,0),(56,'DK','Denmark',1,0),(57,'DJ','Djibouti',1,0),(58,'DM','Dominica',1,0),(59,'DO','Dominican Republic',1,0),(60,'EC','Ecuador',1,0),(61,'EG','Egypt',1,0),(62,'SV','El Salvador',1,0),(63,'GQ','Equatorial Guinea',1,0),(64,'ER','Eritrea',1,0),(65,'EE','Estonia',1,0),(66,'ET','Ethiopia',1,0),(67,'FK','Falkland Islands (Malvinas)',1,0),(68,'FO','Faroe Islands',1,0),(69,'FJ','Fiji',1,0),(70,'FI','Finland',1,0),(71,'FR','France',1,0),(72,'GF','French Guiana',1,0),(73,'PF','French Polynesia',1,0),(74,'TF','French Southern Territories',1,0),(75,'GA','Gabon',1,0),(76,'GM','Gambia',1,0),(77,'GE','Georgia',1,0),(78,'DE','Germany',1,0),(79,'GH','Ghana',1,0),(80,'GI','Gibraltar',1,0),(81,'GR','Greece',1,0),(82,'GL','Greenland',1,0),(83,'GD','Grenada',1,0),(84,'GP','Guadeloupe',1,0),(85,'GU','Guam',1,0),(86,'GT','Guatemala',1,0),(87,'GG','Guernsey',1,0),(88,'GN','Guinea',1,0),(89,'GW','Guinea-Bissau',1,0),(90,'GY','Guyana',1,0),(91,'HT','Haiti',1,0),(92,'HM','Heard Island and McDonald Islands',1,0),(93,'VA','Holy See (Vatican City State)',1,0),(94,'HN','Honduras',1,0),(95,'HK','Hong Kong',1,0),(96,'HU','Hungary',1,0),(97,'IS','Iceland',1,0),(98,'IN','India',1,0),(99,'ID','Indonesia',1,0),(100,'IQ','Iraq',1,0),(101,'IE','Ireland',1,0),(102,'IM','Isle of Man',1,0),(103,'IL','Israel',1,0),(104,'IT','Italy',1,0),(105,'JM','Jamaica',1,0),(106,'JP','Japan',1,0),(107,'JE','Jersey',1,0),(108,'JO','Jordan',1,0),(109,'KZ','Kazakhstan',1,0),(110,'KE','Kenya',1,0),(111,'KI','Kiribati',1,0),(112,'KW','Kuwait',1,0),(113,'KG','Kyrgyzstan',1,0),(114,'LA','Lao Peoples Democratic Republic',1,0),(115,'LV','Latvia',1,0),(116,'LB','Lebanon',1,0),(117,'LS','Lesotho',1,0),(118,'LR','Liberia',1,0),(119,'LY','Libya',1,0),(120,'LI','Liechtenstein',1,0),(121,'LT','Lithuania',1,0),(122,'LU','Luxembourg',1,0),(123,'MO','Macao',1,0),(124,'MG','Madagascar',1,0),(125,'MW','Malawi',1,0),(126,'MY','Malaysia',1,0),(127,'MV','Maldives',1,0),(128,'ML','Mali',1,0),(129,'MT','Malta',1,0),(130,'MH','Marshall Islands',1,0),(131,'MQ','Martinique',1,0),(132,'MR','Mauritania',1,0),(133,'MU','Mauritius',1,0),(134,'YT','Mayotte',1,0),(135,'MX','Mexico',1,0),(136,'MC','Monaco',1,0),(137,'MN','Mongolia',1,0),(138,'ME','Montenegro',1,0),(139,'MS','Montserrat',1,0),(140,'MA','Morocco',1,0),(141,'MZ','Mozambique',1,0),(142,'MM','Myanmar',1,0),(143,'NA','Namibia',1,0),(144,'NR','Nauru',1,0),(145,'NP','Nepal',1,0),(146,'NL','Netherlands',1,0),(147,'NC','New Caledonia',1,0),(148,'NZ','New Zealand',1,0),(149,'NI','Nicaragua',1,0),(150,'NE','Niger',1,0),(151,'NG','Nigeria',1,0),(152,'NU','Niue',1,0),(153,'NF','Norfolk Island',1,0),(154,'MP','Northern Mariana Islands',1,0),(155,'NO','Norway',1,0),(156,'OM','Oman',1,0),(157,'PK','Pakistan',1,0),(158,'PW','Palau',1,0),(159,'PA','Panama',1,0),(160,'PG','Papua New Guinea',1,0),(161,'PY','Paraguay',1,0),(162,'PE','Peru',1,0),(163,'PH','Philippines',1,0),(164,'PN','Pitcairn',1,0),(165,'PL','Poland',1,0),(166,'PT','Portugal',1,0),(167,'PR','Puerto Rico',1,0),(168,'QA','Qatar',1,0),(169,'RO','Romania',1,0),(170,'RU','Russian Federation',1,0),(171,'RW','Rwanda',1,0),(172,'KN','Saint Kitts and Nevis',1,0),(173,'LC','Saint Lucia',1,0),(174,'MF','Saint Martin (French part)',1,0),(175,'PM','Saint Pierre and Miquelon',1,0),(176,'VC','Saint Vincent and the Grenadines',1,0),(177,'WS','Samoa',1,0),(178,'SM','San Marino',1,0),(179,'ST','Sao Tome and Principe',1,0),(180,'SA','Saudi Arabia',1,0),(181,'SN','Senegal',1,0),(182,'RS','Serbia',1,0),(183,'SC','Seychelles',1,0),(184,'SL','Sierra Leone',1,0),(185,'SG','Singapore',1,0),(186,'SX','Sint Maarten (Dutch part)',1,0),(187,'SK','Slovakia',1,0),(188,'SI','Slovenia',1,0),(189,'SB','Solomon Islands',1,0),(190,'SO','Somalia',1,0),(191,'ZA','South Africa',1,0),(192,'GS','South Georgia and the South Sandwich Islands',1,0),(193,'SS','South Sudan',1,0),(194,'ES','Spain',1,0),(195,'LK','Sri Lanka',1,0),(196,'SD','Sudan',1,0),(197,'SR','Suricountry_name',1,0),(198,'SJ','Svalbard and Jan Mayen',1,0),(199,'SZ','Swaziland',1,0),(200,'SE','Sweden',1,0),(201,'CH','Switzerland',1,0),(202,'SY','Syrian Arab Republic',1,0),(203,'TJ','Tajikistan',1,0),(204,'TH','Thailand',1,0),(205,'TL','Timor-Leste',1,0),(206,'TG','Togo',1,0),(207,'TK','Tokelau',1,0),(208,'TO','Tonga',1,0),(209,'TT','Trinidad and Tobago',1,0),(210,'TN','Tunisia',1,0),(211,'TR','Turkey',1,0),(212,'TM','Turkmenistan',1,0),(213,'TC','Turks and Caicos Islands',1,0),(214,'TV','Tuvalu',1,0),(215,'UG','Uganda',1,0),(216,'UA','Ukraine',1,0),(217,'AE','United Arab Emirates',1,0),(218,'GB','United Kingdom',1,0),(219,'US','United States',1,0),(220,'UM','United States Minor Outlying Islands',1,0),(221,'UY','Uruguay',1,0),(222,'UZ','Uzbekistan',1,0),(223,'VU','Vanuatu',1,0),(224,'VN','Viet Nam',1,0),(225,'WF','Wallis and Futuna',1,0),(226,'EH','Western Sahara',1,0),(227,'YE','Yemen',1,0),(228,'ZM','Zambia',1,0),(229,'ZW','Zimbabwe',1,0);
/*!40000 ALTER TABLE `countries` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coupons`
--

DROP TABLE IF EXISTS `coupons`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coupons` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `code` varchar(30) NOT NULL,
  `hours` int(11) NOT NULL DEFAULT 0,
  `isActive` int(11) NOT NULL DEFAULT 0,
  `discount` int(11) NOT NULL DEFAULT 0,
  `email` text NOT NULL DEFAULT '',
  `dateUpdated` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coupons`
--

LOCK TABLES `coupons` WRITE;
/*!40000 ALTER TABLE `coupons` DISABLE KEYS */;
INSERT INTO `coupons` VALUES (1,'MARIA',600,0,4,'','2024-05-13 19:51:08'),(2,'MARIA2',1000,0,0,'','2024-05-10 18:11:52'),(7,'NEWSLETTER10',0,0,10,'tierrqboutique20@gmail.com','2024-06-11 18:26:47');
/*!40000 ALTER TABLE `coupons` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `doy`
--

DROP TABLE IF EXISTS `doy`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `doy` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` text NOT NULL,
  `isActive` int(11) NOT NULL DEFAULT 1,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=311 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `doy`
--

LOCK TABLES `doy` WRITE;
/*!40000 ALTER TABLE `doy` DISABLE KEYS */;
INSERT INTO `doy` VALUES (1,'ΔΟΥ ΓΑΛΑΤΣΙΟΥ',1),(2,'Α ΑΘΗΝΩΝ',1),(3,'Β ΑΘΗΝΩΝ',1),(4,'Γ ΑΘΗΝΩΝ',1),(5,'Δ ΑΘΗΝΩΝ (Δ, Η, Ι , ΙΑ)',1),(6,'Ε-Θ ΑΘΗΝΩΝ',1),(7,'ΣΤ ΑΘΗΝΩΝ',1),(8,'Ζ ΑΘΗΝΩΝ',1),(9,'Η ΑΘΗΝΩΝ',1),(10,'Θ ΑΘΗΝΩΝ',1),(11,'ΙΑ ΑΘΗΝΩΝ',1),(12,'ΙΒ ΑΘΗΝΩΝ',1),(13,'ΙΓ ΑΘΗΝΩΝ',1),(14,'ΙΔ ΑΘΗΝΩΝ',1),(15,'ΙΕ ΑΘΗΝΩΝ',1),(16,'ΙΣΤ ΑΘΗΝΩΝ',1),(17,'ΙΖ-ΙΗ ΑΘΗΝΩΝ',1),(18,'ΙΘ ΑΘΗΝΩΝ',1),(19,'Κ ΑΘΗΝΩΝ',1),(20,'ΚΑ ΑΘΗΝΩΝ',1),(21,'ΚΒ ΑΘΗΝΩΝ',1),(22,'ΚΓ ΑΘΗΝΩΝ',1),(23,'ΜΕΓΑΛΩΝ ΕΠΙΧΕΙΡΗΣΕΩΝ',1),(24,'ΕΛΕΥΘΕΡΩΝ ΕΠΑΓΓΕΛΜΑΤΙΩΝ Α',1),(25,'ΕΛΕΥΘΕΡΩΝ ΕΠΑΓΓΕΛΜΑΤΙΩΝ Β',1),(26,'ΚΑΤΟΙΚΩΝ ΕΞΩΤΕΡΙΚΟΥ',1),(27,'ΑΓΙΟΥ ΔΗΜΗΤΡΙΟΥ',1),(28,'Α ΚΑΛΛΙΘΕΑΣ',1),(29,'ΝΕΑΣ ΙΩΝΙΑΣ',1),(30,'ΝΕΑΣ ΣΜΥΡΝΗΣ',1),(31,'ΠΑΛΑΙΟΥ ΦΑΛΗΡΟΥ',1),(32,'ΧΑΛΑΝΔΡΙΟΥ',1),(33,'ΑΜΑΡΟΥΣΙΟΥ',1),(34,'ΑΓΙΩΝ ΑΝΑΡΓΥΡΩΝ',1),(35,'ΑΙΓΑΛΕΩ - ΧΑΙΔΑΡΙΟΥ',1),(36,'Α ΠΕΡΙΣΤΕΡΙΟΥ',1),(37,'ΓΛΥΦΑΔΑΣ',1),(38,'ΔΑΦΝΗΣ',1),(39,'ΝΕΟΥ ΗΡΑΚΛΕΙΟΥ',1),(40,'ΧΟΛΑΡΓΟΥ - ΑΓΙΑΣ ΠΑΡΑΣΚΕΥΗΣ',1),(41,'ΒΥΡΩΝΑ',1),(42,'ΚΗΦΙΣΙΑΣ',1),(43,'ΙΛΙΟΥ',1),(44,'Β ΠΕΡΙΣΤΕΡΙΟΥ',1),(45,'ΦΑΕ ΑΘΗΝΩΝ',1),(46,'ΚΕΦΑΛΑΙΟΥ ΑΘ. Α',1),(47,'ΚΕΦΑΛΑΙΟΥ ΑΘ. Β',1),(48,'ΚΕΦΑΛΑΙΟΥ ΠΕΙΡΑΙΑ',1),(49,'ΖΩΓΡΑΦΟΥ',1),(50,'ΗΛΙΟΥΠΟΛΗΣ',1),(51,'ΚΑΛΛΙΘΕΑΣ Β',1),(52,'ΨΥΧΙΚΟΥ',1),(53,'ΧΟΛΑΡΓΟΥ',1),(54,'ΗΛΙΟΥΠΟΛΗΣ - ΑΡΓΥΡΟΥΠΟΛΗΣ',1),(55,'ΠΕΤΡΟΥΠΟΛΕΩΣ',1),(56,'ΑΝΩ ΛΙΟΣΙΩΝ',1),(57,'Α ΠΕΙΡΑΙΑ',1),(58,'Β ΠΕΙΡΑΙΑ',1),(59,'Γ ΠΕΙΡΑΙΑ',1),(60,'Δ ΠΕΙΡΑΙΑ',1),(61,'Ε ΠΕΙΡΑΙΑ',1),(62,'ΣΤ ΠΕΙΡΑΙΑ',1),(63,'ΦΑΕ ΠΕΙΡΑΙΑ',1),(64,'ΠΛΟΙΩΝ ΠΕΙΡΑΙΑ',1),(65,'ΚΟΡΥΔΑΛΛΟΥ',1),(66,'ΜΟΣΧΑΤΟΥ',1),(67,'ΕΝΣΜΩΝ ΔΙΚΕΙΣ ΠΕΙΡΑΙΩΣ',1),(68,'ΓΕΝΙΚΩΝ ΕΣΟΔΩΝ ΠΕΙΡΑΙΩΣ',1),(69,'ΝΙΚΑΙΑΣ',1),(70,'ΑΙΓΙΝΑΣ',1),(71,'ΑΧΑΡΝΩΝ',1),(72,'ΕΛΕΥΣΙΝΑΣ',1),(73,'ΚΟΡΩΠΙΟΥ',1),(74,'ΚΥΘΗΡΩΝ',1),(75,'ΛΑΥΡΙΟΥ',1),(76,'ΑΓΙΟΥ ΣΤΕΦΑΝΟΥ',1),(77,'ΜΕΓΑΡΩΝ',1),(78,'ΣΑΛΑΜΙΝΑΣ',1),(79,'ΠΟΡΟΥ',1),(80,'ΠΑΛΛΗΝΗΣ',1),(81,'ΘΗΒΑΣ',1),(82,'ΛΙΒΑΔΕΙΑΣ',1),(83,'ΑΜΦΙΛΟΧΕΙΑΣ',1),(84,'ΑΣΤΑΚΟΥ',1),(85,'ΒΟΝΙΤΣΑΣ',1),(86,'ΜΕΣΟΛΟΓΓΙΟΥ',1),(87,'ΝΑΥΠΑΚΤΟΥ',1),(88,'ΘΕΡΜΟΥ',1),(89,'ΑΓΡΙΝΙΟΥ',1),(90,'ΚΑΡΠΕΝΗΣΙΟΥ',1),(91,'ΙΣΤΙΑΙΑΣ',1),(92,'ΚΑΡΥΣΤΟΥ',1),(93,'ΚΥΜΗΣ',1),(94,'ΛΙΜΝΗΣ',1),(95,'ΧΑΛΚΙΔΑΣ',1),(96,'ΔΟΜΟΚΟΥ',1),(97,'ΑΜΦΙΣΣΗΣ',1),(98,'ΑΜΦΙΚΛΕΙΑΣ',1),(99,'ΑΤΑΛΑΝΤΗΣ',1),(100,'ΜΑΚΡΑΚΩΜΗΣ',1),(101,'ΛΑΜΙΑΣ',1),(102,'ΣΤΥΛΙΔΑΣ',1),(103,'ΛΙΔΟΡΙΚΙΟΥ',1),(104,'ΑΡΓΟΥΣ',1),(105,'ΟΡΕΣΤΙΚΟΥ',1),(106,'ΣΠΕΤΣΩΝ',1),(107,'ΚΡΑΝΙΔΙΟΥ',1),(108,'ΥΔΡΑΣ',1),(109,'ΝΑΥΠΛΙΟΥ',1),(110,'ΔΗΜΗΤΣΑΝΑΣ',1),(111,'ΛΕΩΝΙΔΙΟΥ',1),(112,'ΤΡΟΠΑΙΩΝ',1),(113,'ΑΣΤΡΟΥΣ',1),(114,'ΤΡΙΠΟΛΗΣ',1),(115,'ΜΕΓΑΛΟΠΟΛΗΣ',1),(116,'ΑΙΓΙΟΥ',1),(117,'ΑΚΡΑΤΑΣ',1),(118,'ΚΑΛΑΒΡΥΤΩΝ',1),(119,'ΚΛΕΙΤΟΡΙΑΣ',1),(120,'Α ΠΑΤΡΩΝ',1),(121,'Β ΠΑΤΡΩΝ',1),(122,'Γ ΠΑΤΡΩΝ',1),(123,'ΚΑΤΩ ΑΧΑΙΑΣ',1),(124,'ΑΜΑΛΙΑΔΑΣ',1),(125,'ΠΥΡΓΟΥ',1),(126,'ΓΑΣΤΟΥΝΗΣ',1),(127,'ΒΑΡΔΑ',1),(128,'ΑΜΠΕΛΟΚΗΠΩΝ ΘΕΣΝΙΚΗΣ',1),(130,'ΚΡΕΣΤΕΝΩΝ',1),(131,'ΛΕΧΑΙΝΩΝ',1),(132,'ΑΝΔΡΙΤΣΑΙΝΑΣ',1),(133,'ΖΑΧΑΡΩΣ',1),(134,'ΧΑΝΙΩΝ Β',1),(135,'ΔΕΡΒΕΝΙΟΥ',1),(136,'ΚΙΑΤΟΥ',1),(137,'ΚΟΡΙΝΘΟΥ',1),(138,'ΝΕΜΕΑΣ',1),(139,'ΞΥΛΟΚΑΣΤΡΟΥ',1),(140,'ΓΥΘΕΙΟΥ',1),(141,'ΜΟΛΑΩΝ',1),(142,'ΝΕΑΠΟΛΗΣ ΒΟΙΩΝ',1),(143,'ΣΚΑΛΑΣ',1),(144,'ΚΡΟΚΕΩΝ',1),(145,'ΣΠΑΡΤΗΣ',1),(146,'ΑΡΕΟΠΟΛΗΣ',1),(147,'ΚΑΛΑΜΑΤΑΣ',1),(148,'ΜΕΛΙΓΑΛΑ',1),(149,'ΜΕΣΣΗΝΗΣ',1),(150,'ΠΥΛΟΥ',1),(151,'ΓΑΡΓΑΛΙΑΝΩΝ',1),(152,'ΚΥΠΑΡΙΣΣΙΑΣ',1),(153,'ΦΙΛΙΑΤΡΩΝ',1),(154,'ΚΑΡΔΙΤΣΑΣ',1),(155,'ΜΟΥΖΑΚΙΟΥ',1),(156,'ΣΟΦΑΔΩΝ',1),(157,'ΠΑΛΑΜΑ ΚΑΡΔΙΤΣΑΣ',1),(158,'ΑΓΙΑΣ',1),(159,'ΕΛΑΣΣΟΝΑΣ',1),(160,'ΔΕΣΚΑΤΗΣ',1),(161,'ΛΑΡΙΣΑΣ Α',1),(162,'ΛΑΡΙΣΑΣ Β',1),(163,'ΛΑΡΙΣΑΣ Γ',1),(164,'ΤΥΡΝΑΒΟΥ',1),(165,'ΦΑΡΣΑΛΩΝ',1),(166,'ΑΛΜΥΡΟΥ',1),(167,'ΒΟΛΟΥ',1),(168,'ΒΟΛΟΥ Β',1),(169,'ΙΩΝΙΑΣ ΜΑΓΝΗΣΙΑΣ',1),(170,'ΣΚΟΠΕΛΟΥ',1),(171,'ΣΚΙΑΘΟΥ',1),(172,'ΚΑΛΑΜΠΑΚΑΣ',1),(173,'ΤΡΙΚΑΛΩΝ',1),(174,'ΠΥΛΗΣ ΤΡΙΚΑΛΩΝ',1),(175,'ΑΛΕΞΑΝΔΡΕΙΑΣ',1),(176,'ΒΕΡΟΙΑΣ',1),(177,'ΝΑΟΥΣΑΣ',1),(178,'ΘΕΣΣΑΛΟΝΙΚΗΣ Α',1),(179,'ΘΕΣΣΑΛΟΝΙΚΗΣ Β',1),(180,'ΘΕΣΣΑΛΟΝΙΚΗΣ Γ',1),(181,'ΘΕΣΣΑΛΟΝΙΚΗΣ Δ',1),(182,'ΘΕΣΣΑΛΟΝΙΚΗΣ Ε',1),(183,'ΘΕΣΣΑΛΟΝΙΚΗΣ ΣΤ',1),(184,'ΘΕΣΣΑΛΟΝΙΚΗΣ Ζ',1),(185,'ΘΕΣΣΑΛΟΝΙΚΗΣ Ι',1),(186,'ΘΕΣΣΑΛΟΝΙΚΗΣ Η',1),(187,'ΘΕΣΣΑΛΟΝΙΚΗΣ Θ',1),(188,'ΚΕΦΑΛΑΙΟΥ ΘΕΣΣΑΛΟΝΙΚΗΣ',1),(189,'ΖΑΓΚΛΙΒΕΡΙΟΥ',1),(190,'ΛΑΓΚΑΔΑ',1),(191,'ΣΟΧΟΥ',1),(192,'ΦΑΕ ΘΕΣΣΑΛΟΝΙΚΗΣ',1),(193,'ΝΕΑΠΟΛΗΣ ΘΕΣΣΑΛΟΝΙΚΗΣ',1),(194,'ΤΟΥΜΠΑΣ ΘΕΣΣΑΛΟΝΙΚΗΣ',1),(195,'ΙΩΝΙΑΣ ΘΕΣΣΑΛΟΝΙΚΗΣ',1),(196,'ΑΓ. ΑΘΑΝΑΣΙΟΥ ΘΕΣΣΑΛΟΝΙΚΗΣ',1),(197,'ΚΑΛΑΜΑΡΙΑΣ',1),(198,'ΑΜΠΕΛΟΚΗΠΩΝ',1),(199,'ΚΑΣΤΟΡΙΑΣ',1),(205,'ΝΕΣΤΟΡΙΟΥ',1),(206,'ΚΙΛΚΙΣ',1),(207,'ΓΟΥΜΕΝΙΣΣΑΣ',1),(208,'ΓΡΕΒΕΝΩΝ',1),(209,'ΠΤΟΛΕΜΑΙΔΑΣ',1),(210,'ΚΟΖΑΝΗΣ',1),(211,'ΣΕΡΒΙΩΝ',1),(212,'ΣΙΑΤΙΣΤΑΣ',1),(213,'ΑΡΙΔΑΙΑΣ',1),(214,'ΓΙΑΝΝΙΤΣΩΝ',1),(215,'ΕΔΕΣΣΑΣ',1),(216,'ΣΚΥΔΡΑΣ',1),(217,'ΚΑΤΕΡΙΝΗΣ',1),(218,'ΚΑΤΕΡΙΝΗΣ Β',1),(219,'ΑΙΓΙΝΙΟΥ',1),(220,'ΑΜΥΝΤΑΙΟΥ',1),(221,'ΦΛΩΡΙΝΗΣ',1),(222,'ΑΡΝΑΙΑΣ',1),(223,'ΚΑΣΣΑΝΔΡΑΣ',1),(224,'ΠΟΛΥΓΥΡΟΥ',1),(225,'ΝΕΩΝ ΜΟΥΔΑΝΙΩΝ',1),(226,'ΔΡΑΜΑΣ',1),(227,'ΝΕΥΡΟΚΟΠΙΟΥ',1),(228,'ΑΛΕΞΑΝΔΡΟΥΠΟΛΗΣ',1),(229,'ΔΙΔΥΜΟΤΕΙΧΟΥ',1),(230,'ΟΡΕΣΤΙΑΔΑΣ',1),(231,'ΣΟΥΦΛΙΟΥ',1),(232,'ΘΑΣΟΥ',1),(233,'ΚΑΒΑΛΑΣ Α',1),(234,'ΚΑΒΑΛΑΣ Β',1),(235,'ΚΑΒΑΛΑΣ ΑΒ',1),(236,'ΧΡΥΣΟΥΠΟΛΗΣ',1),(237,'ΕΛΕΥΘΕΡΟΥΠΟΛΗΣ',1),(238,'ΞΑΝΘΗΣ Α',1),(239,'ΞΑΝΘΗΣ Β',1),(240,'ΚΟΜΟΤΗΝΗΣ',1),(241,'ΣΑΠΠΩΝ',1),(242,'ΝΙΓΡΙΤΑΣ',1),(243,'ΣΕΡΡΩΝ Α',1),(244,'ΣΕΡΡΩΝ Β',1),(245,'ΣΙΔΗΡΟΚΑΣΤΡΟΥ',1),(246,'ΗΡΑΚΛΕΙΑΣ',1),(247,'ΝΕΑΣ ΖΙΧΝΗΣ',1),(248,'ΑΡΤΑΣ',1),(249,'ΦΙΛΙΠΠΙΑΔΑΣ',1),(250,'ΗΓΟΥΜΕΝΙΤΣΑΣ',1),(251,'ΠΑΡΓΑΣ',1),(252,'ΠΑΡΑΜΥΘΙΑΣ',1),(253,'ΦΙΛΙΑΤΩΝ',1),(254,'ΙΩΑΝΝΙΝΩΝ Α-Β',1),(255,'ΙΩΑΝΝΙΝΩΝ Β',1),(256,'ΔΕΛΒΙΝΑΚΙΟΥ',1),(257,'ΜΕΤΣΟΒΟΥ',1),(258,'ΚΟΝΙΤΣΑΣ',1),(259,'ΠΡΕΒΕΖΑΣ',1),(260,'ΑΝΔΡΟΥ',1),(261,'ΘΗΡΑΣ',1),(262,'ΚΕΑΣ',1),(263,'ΜΗΛΟΥ',1),(264,'ΝΑΞΟΥ',1),(265,'ΠΑΡΟΥ',1),(266,'ΣΥΡΟΥ',1),(267,'ΜΥΚΟΝΟΥ',1),(268,'ΤΗΝΟΥ',1),(269,'ΛΗΜΝΟΥ',1),(270,'ΛΕΡΟΥ',1),(271,'ΚΑΛΛΟΝΗΣ',1),(272,'ΜΗΘΥΜΝΑΣ',1),(273,'ΜΥΤΙΛΗΝΗΣ',1),(274,'ΠΛΩΜΑΡΙΟΥ',1),(275,'ΑΓ. ΚΗΡΥΚΟΥ ΙΚΑΡΙΑΣ',1),(276,'ΚΑΡΛΟΒΑΣΙΟΥ',1),(277,'ΣΑΜΟΥ',1),(278,'ΧΙΟΥ',1),(279,'ΚΑΛΥΜΝΟΥ',1),(281,'ΚΑΡΠΑΘΟΥ',1),(282,'ΚΩ',1),(283,'ΡΟΔΟΥ',1),(284,'ΗΡΑΚΛΕΙΟΥ Α',1),(285,'ΗΡΑΚΛΕΙΟΥ Β',1),(286,'ΜΟΙΡΩΝ',1),(287,'ΤΥΜΠΑΚΙΟΥ ΗΡΑΚΛΕΙΟΥ',1),(288,'ΛΙΜΕΝΑΣ ΧΕΡΣΟΝΗΣΟΥ',1),(289,'ΚΑΣΤΕΛΙΟΥ ΠΕΔΙΑΔΟΣ',1),(290,'ΑΡΚΑΛΟΧΩΡΙΟΥ',1),(291,'ΙΕΡΑΠΕΤΡΑΣ',1),(292,'ΑΓ. ΝΙΚΟΛΑΟΥ',1),(293,'ΝΕΑΠΟΛΗΣ ΚΡΗΤΗΣ',1),(294,'ΣΗΤΕΙΑΣ',1),(295,'ΡΕΘΥΜΝΟΥ',1),(296,'ΚΑΣΤΕΛΙΟΥ ΚΙΣΣΙΜΟΥ',1),(297,'ΧΑΝΙΩΝ Α-Β',1),(299,'ΖΑΚΥΝΘΟΥ',1),(300,'ΚΕΡΚΥΡΑΣ Α',1),(301,'ΚΕΡΚΥΡΑΣ Β',1),(302,'ΠΑΞΩΝ',1),(303,'ΑΡΓΟΣΤΟΛΙΟΥ',1),(304,'ΛΗΞΟΥΡΙΟΥ',1),(305,'ΙΘΑΚΗΣ',1),(306,'ΛΕΥΚΑΔΑΣ',1),(307,'ΣΕΡΡΩΝ',1),(309,'ΦΑΡΚΑΔΟΝΑΣ',1),(310,'ΦΑΝΑΡΙΟΥ',1);
/*!40000 ALTER TABLE `doy` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `home_banners`
--

DROP TABLE IF EXISTS `home_banners`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `home_banners` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` text NOT NULL,
  `imgHref` varchar(150) NOT NULL,
  `link` text DEFAULT NULL,
  `isActive` int(11) NOT NULL DEFAULT 0,
  `isVideo` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `home_banners`
--

LOCK TABLES `home_banners` WRITE;
/*!40000 ALTER TABLE `home_banners` DISABLE KEYS */;
INSERT INTO `home_banners` VALUES (1,'SPECIAL OCCASIONS','SUMMER (12).jpg','http://tierrapurses.com/catalog?category=4',1,0),(2,'SUMMER SALES -30%','sales.webp','http://tierrapurses.com/catalog?category=2',1,0),(10,'NEW','NEW (2).webp','http://tierrapurses.com/catalog?category=5',1,0),(11,'Video link','samplevideo.mp4','http://tierrapurses.gr/catalog?category=1',0,1),(12,'fads','trail-5yOnGsKUNGw-unsplash.jpg','fasd',0,0);
/*!40000 ALTER TABLE `home_banners` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `home_banners_section`
--

DROP TABLE IF EXISTS `home_banners_section`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `home_banners_section` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `imgHref` varchar(80) NOT NULL,
  `description` text NOT NULL,
  `link` text NOT NULL,
  `isActive` int(11) NOT NULL DEFAULT 0,
  `isVideo` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `home_banners_section`
--

LOCK TABLES `home_banners_section` WRITE;
/*!40000 ALTER TABLE `home_banners_section` DISABLE KEYS */;
INSERT INTO `home_banners_section` VALUES (1,'NEWIMAGEFOOTER.png','NEW COLLECTION','http://tierrapurses.com/catalog?category=1',1,0),(3,'banner-min.jpg','Hi','http://www.google.gr',0,0);
/*!40000 ALTER TABLE `home_banners_section` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `home_major_sections`
--

DROP TABLE IF EXISTS `home_major_sections`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `home_major_sections` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(45) NOT NULL,
  `isActive` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `home_major_sections`
--

LOCK TABLES `home_major_sections` WRITE;
/*!40000 ALTER TABLE `home_major_sections` DISABLE KEYS */;
INSERT INTO `home_major_sections` VALUES (1,'Marketing2',0),(2,'OFFERS',1),(3,'fasdfads',0),(4,'NEW IN',0),(5,'NEW IN',0);
/*!40000 ALTER TABLE `home_major_sections` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `home_major_sections_products`
--

DROP TABLE IF EXISTS `home_major_sections_products`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `home_major_sections_products` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `home_major_section_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=52 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `home_major_sections_products`
--

LOCK TABLES `home_major_sections_products` WRITE;
/*!40000 ALTER TABLE `home_major_sections_products` DISABLE KEYS */;
INSERT INTO `home_major_sections_products` VALUES (17,1,15),(18,1,16),(19,1,3),(20,3,2),(21,3,5),(33,4,75),(43,5,75),(44,5,65),(45,5,74),(49,2,62),(50,2,64),(51,2,63);
/*!40000 ALTER TABLE `home_major_sections_products` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `home_tabs`
--

DROP TABLE IF EXISTS `home_tabs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `home_tabs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(45) NOT NULL,
  `isActive` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `home_tabs`
--

LOCK TABLES `home_tabs` WRITE;
/*!40000 ALTER TABLE `home_tabs` DISABLE KEYS */;
INSERT INTO `home_tabs` VALUES (1,'Summer',1),(3,'Winter',1),(4,'Best Sellers',0);
/*!40000 ALTER TABLE `home_tabs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `home_tabs_products`
--

DROP TABLE IF EXISTS `home_tabs_products`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `home_tabs_products` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `home_tabs_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=76 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `home_tabs_products`
--

LOCK TABLES `home_tabs_products` WRITE;
/*!40000 ALTER TABLE `home_tabs_products` DISABLE KEYS */;
INSERT INTO `home_tabs_products` VALUES (34,4,41),(59,3,38),(60,3,40),(61,3,43),(62,3,42),(63,3,41),(64,3,49),(65,1,52),(66,1,73),(67,1,72),(68,1,74),(69,1,65),(70,1,53),(71,1,71),(72,1,75),(73,1,70),(74,1,91),(75,1,92);
/*!40000 ALTER TABLE `home_tabs_products` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `logo`
--

DROP TABLE IF EXISTS `logo`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `logo` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `image` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `logo`
--

LOCK TABLES `logo` WRITE;
/*!40000 ALTER TABLE `logo` DISABLE KEYS */;
INSERT INTO `logo` VALUES (8,'LIMITED HANDMADE PURSES (500 x 500 px).png');
/*!40000 ALTER TABLE `logo` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `newsletter_users`
--

DROP TABLE IF EXISTS `newsletter_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `newsletter_users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `email` varchar(65) NOT NULL,
  `isActive` int(11) NOT NULL,
  `createdAt` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `newsletter_users`
--

LOCK TABLES `newsletter_users` WRITE;
/*!40000 ALTER TABLE `newsletter_users` DISABLE KEYS */;
INSERT INTO `newsletter_users` VALUES (1,'fasadsfsd@fasddsfad.gr',1,'2022-10-17 10:05:52'),(3,'akis.staikopoulos@gmail.com',1,'2024-05-14 09:30:11'),(4,'theodosios.staikopoulos@ifco.com',1,'2024-05-14 09:30:25'),(5,'ted.staikos@hotmail.com',1,'2024-05-14 09:30:45'),(6,'athanasia.stavrop@hotmail.com',1,'2024-05-14 09:31:23'),(7,'lidia.staikopoulou@gmail.com',1,'2024-05-14 09:31:46'),(8,'Mstaiko98@gmail.com',1,'2024-05-16 19:21:12'),(9,'m.tasiadami@gmail.com',1,'2024-05-18 10:13:53'),(10,'m.tasiadami@gmail.com',1,'2024-05-18 10:14:01'),(11,'fasdfasd@fasdfasdfasdfd.gr',1,'2024-05-24 12:22:11'),(13,'fasadsfsd2@fasddsfad.gr',1,'2024-05-24 13:28:14'),(14,'fasdasd@fadsfsd.gr',1,'2024-05-24 13:30:31'),(20,'tierrqboutique20@gmail.com',1,'2024-06-11 15:26:47');
/*!40000 ALTER TABLE `newsletter_users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `newslettercoupon`
--

DROP TABLE IF EXISTS `newslettercoupon`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `newslettercoupon` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `isActive` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `newslettercoupon`
--

LOCK TABLES `newslettercoupon` WRITE;
/*!40000 ALTER TABLE `newslettercoupon` DISABLE KEYS */;
INSERT INTO `newslettercoupon` VALUES (1,1);
/*!40000 ALTER TABLE `newslettercoupon` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `offers_title`
--

DROP TABLE IF EXISTS `offers_title`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `offers_title` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `offers_title`
--

LOCK TABLES `offers_title` WRITE;
/*!40000 ALTER TABLE `offers_title` DISABLE KEYS */;
INSERT INTO `offers_title` VALUES (1,'BEST SELLERS');
/*!40000 ALTER TABLE `offers_title` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `order_statuses`
--

DROP TABLE IF EXISTS `order_statuses`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `order_statuses` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `order_id` int(11) NOT NULL,
  `status_id` int(11) DEFAULT NULL,
  `dateCreated` timestamp NOT NULL DEFAULT current_timestamp(),
  `status_completed` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `order_statuses`
--

LOCK TABLES `order_statuses` WRITE;
/*!40000 ALTER TABLE `order_statuses` DISABLE KEYS */;
INSERT INTO `order_statuses` VALUES (1,1,1,'2024-05-13 16:52:36',0),(2,2,1,'2024-05-13 20:31:13',0),(3,3,1,'2024-05-13 20:35:00',0),(4,4,1,'2024-05-14 07:26:59',0),(5,5,1,'2024-05-14 09:08:50',0),(6,6,1,'2024-05-14 22:16:36',0),(7,6,2,'2024-05-20 08:13:17',1),(8,5,2,'2024-05-20 08:24:52',1),(9,1,2,'2024-05-20 08:50:11',1);
/*!40000 ALTER TABLE `order_statuses` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `orders`
--

DROP TABLE IF EXISTS `orders`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `orders` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `cart_id` int(11) NOT NULL,
  `paymentmethod_id` int(11) NOT NULL,
  `shippingmethod_id` int(11) NOT NULL,
  `dateCreated` timestamp NOT NULL DEFAULT current_timestamp(),
  `paymentinfo_id` int(11) NOT NULL,
  `shippinginfo_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL DEFAULT 0,
  `order_code` varchar(45) DEFAULT NULL,
  `paymentmethod_cost` double NOT NULL DEFAULT 0,
  `shippingmethod_cost` double NOT NULL DEFAULT 0,
  `notes` text DEFAULT NULL,
  `couponDiscount` double NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `orders`
--

LOCK TABLES `orders` WRITE;
/*!40000 ALTER TABLE `orders` DISABLE KEYS */;
INSERT INTO `orders` VALUES (1,1,1,1,'2024-05-13 16:52:36',1,1,14,'A17156191564851233',4,5,'',4),(2,2,1,1,'2024-05-13 20:31:13',2,2,0,'A17156322732969563',4,5,'',4),(3,3,1,1,'2024-05-13 20:35:00',3,3,14,'A1715632500015851',4,5,'',4),(4,4,1,1,'2024-05-14 07:26:59',4,4,0,'A17156716198043381',4,5,'',4),(5,5,1,1,'2024-05-14 09:08:50',5,5,14,'A17156777300961365',4,5,'',4),(6,6,1,1,'2024-05-14 22:16:36',6,6,14,'A17157249969786477',4,5,'',4);
/*!40000 ALTER TABLE `orders` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pages_keywords`
--

DROP TABLE IF EXISTS `pages_keywords`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pages_keywords` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `page` varchar(100) NOT NULL,
  `keywords` text DEFAULT NULL,
  `slug` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pages_keywords`
--

LOCK TABLES `pages_keywords` WRITE;
/*!40000 ALTER TABLE `pages_keywords` DISABLE KEYS */;
INSERT INTO `pages_keywords` VALUES (1,'Catalog','<p>Amarillo Amare Chloe Vanilla Safari Evelyn Elvira Amelie Croco Marron Naomi Bohemian JeannyChoo, Vaqueros, Jasmine, Bella, Marine, Magenta, Paloma, Bianca, Verano, Selva, Estrella, El Mar, Diamante (silver), Diamante (black), Kates, Princessa, Argenta, Cinderella, Aurelia, Morocco, Cheryl, Pistachio, Africa (black), Africa (white), Sienna, Limoncello, Winter, New, Summer, Sales, Offers</p>','catalog'),(2,'Login','Amarillo	\r\nAmare	\r\nChloe	\r\nVanilla	\r\nSafari	\r\nEvelyn	\r\nElvira	\r\nAmelie	\r\nCroco	\r\nMarron	\r\nNaomi	\r\nBohemian	\r\nJeannyChoo,\r\nVaqueros,\r\nJasmine,\r\nBella,\r\nMarine,\r\nMagenta,\r\nPaloma,\r\nBianca,\r\nVerano,\r\nSelva,\r\nEstrella,\r\nEl Mar,\r\nDiamante (silver),\r\nDiamante (black),\r\nKates,\r\nPrincessa,\r\nArgenta,\r\nCinderella,\r\nAurelia,\r\nMorocco,\r\nCheryl,\r\nPistachio,\r\nAfrica (black),\r\nAfrica (white),\r\nSienna,\r\nLimoncello','login'),(3,'Register','Amarillo	\r\nAmare	\r\nChloe	\r\nVanilla	\r\nSafari	\r\nEvelyn	\r\nElvira	\r\nAmelie	\r\nCroco	\r\nMarron	\r\nNaomi	\r\nBohemian	\r\nJeannyChoo,\r\nVaqueros,\r\nJasmine,\r\nBella,\r\nMarine,\r\nMagenta,\r\nPaloma,\r\nBianca,\r\nVerano,\r\nSelva,\r\nEstrella,\r\nEl Mar,\r\nDiamante (silver),\r\nDiamante (black),\r\nKates,\r\nPrincessa,\r\nArgenta,\r\nCinderella,\r\nAurelia,\r\nMorocco,\r\nCheryl,\r\nPistachio,\r\nAfrica (black),\r\nAfrica (white),\r\nSienna,\r\nLimoncello','register'),(4,'Contact','Amarillo	\r\nAmare	\r\nChloe	\r\nVanilla	\r\nSafari	\r\nEvelyn	\r\nElvira	\r\nAmelie	\r\nCroco	\r\nMarron	\r\nNaomi	\r\nBohemian	\r\nJeannyChoo,\r\nVaqueros,\r\nJasmine,\r\nBella,\r\nMarine,\r\nMagenta,\r\nPaloma,\r\nBianca,\r\nVerano,\r\nSelva,\r\nEstrella,\r\nEl Mar,\r\nDiamante (silver),\r\nDiamante (black),\r\nKates,\r\nPrincessa,\r\nArgenta,\r\nCinderella,\r\nAurelia,\r\nMorocco,\r\nCheryl,\r\nPistachio,\r\nAfrica (black),\r\nAfrica (white),\r\nSienna,\r\nLimoncello','contact'),(5,'Home','Amarillo	\r\nAmare	\r\nChloe	\r\nVanilla	\r\nSafari	\r\nEvelyn	\r\nElvira	\r\nAmelie	\r\nCroco	\r\nMarron	\r\nNaomi	\r\nBohemian	\r\nJeannyChoo,\r\nVaqueros,\r\nJasmine,\r\nBella,\r\nMarine,\r\nMagenta,\r\nPaloma,\r\nBianca,\r\nVerano,\r\nSelva,\r\nEstrella,\r\nEl Mar,\r\nDiamante (silver),\r\nDiamante (black),\r\nKates,\r\nPrincessa,\r\nArgenta,\r\nCinderella,\r\nAurelia,\r\nMorocco,\r\nCheryl,\r\nPistachio,\r\nAfrica (black),\r\nAfrica (white),\r\nSienna,\r\nLimoncello','home');
/*!40000 ALTER TABLE `pages_keywords` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `payment_infos`
--

DROP TABLE IF EXISTS `payment_infos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `payment_infos` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `first_name` varchar(45) NOT NULL,
  `last_name` varchar(45) NOT NULL,
  `email` varchar(45) NOT NULL,
  `phone` varchar(45) DEFAULT NULL,
  `mobile` varchar(45) NOT NULL,
  `address` varchar(45) NOT NULL,
  `postcode` int(11) NOT NULL,
  `city` varchar(45) DEFAULT NULL,
  `region` varchar(45) DEFAULT NULL,
  `isReceipt` varchar(45) NOT NULL,
  `country_id` int(11) NOT NULL,
  `prefecture_id` int(11) NOT NULL,
  `eponymia` text NOT NULL DEFAULT '',
  `afm` varchar(10) NOT NULL DEFAULT '',
  `doy` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `payment_infos`
--

LOCK TABLES `payment_infos` WRITE;
/*!40000 ALTER TABLE `payment_infos` DISABLE KEYS */;
INSERT INTO `payment_infos` VALUES (1,'vdvsv','sdvsvsvsvsvsv','mstaiko98@gmail.com','6977137837','6977137837','vdvds',13231,'athens',NULL,'receipt',81,5,'','',NULL),(2,'Maria ','Staikopoulou ','mstaiko98@gmail.com','6977137837','6977137837','Ermou',13221,'Peristeri',NULL,'receipt',81,52,'','',NULL),(3,'Maria ','Staikopoulou ','mstaiko98@gmail.com','6977137837','6977137837','Ermou',13221,'Peristeri',NULL,'receipt',81,52,'','',NULL),(4,'Christos','Krokidis','Chriskrokidis@gmail.com','6987703523','6987703523','Kanari',13231,'Petroupoli',NULL,'receipt',81,9,'','',NULL),(5,'Maria ','Staikopoulou ','mstaiko98@gmail.com','6977137837','6977137837','Ermou',13221,'Peristeri',NULL,'receipt',81,52,'','',NULL),(6,'vdvsv','sdvsvsvsvsvsv','mstaiko98@gmail.com','6977137837','6977137837','vdvds',13231,'',NULL,'receipt',81,52,'','',NULL);
/*!40000 ALTER TABLE `payment_infos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `payment_methods`
--

DROP TABLE IF EXISTS `payment_methods`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `payment_methods` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(45) NOT NULL,
  `description` text DEFAULT NULL,
  `cost` int(11) NOT NULL DEFAULT 0,
  `isActive` int(11) DEFAULT 1,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `payment_methods`
--

LOCK TABLES `payment_methods` WRITE;
/*!40000 ALTER TABLE `payment_methods` DISABLE KEYS */;
INSERT INTO `payment_methods` VALUES (1,'ΑΝΤΙΚΑΤΑΒΟΛΗ',NULL,2,1),(2,'ΠΛΗΡΩΜΗ ΣΤΟ ΚΑΤΑΣΤΗΜΑ',NULL,0,0),(3,'ΚΑΤΑΘΕΣΗ ΣΕ ΤΡΑΠΕΖΑ','Για την περίπτωση που επιλέξετε ΚΑΤΑΘΕΣΗ ΣΕ ΤΡΑΠΕΖΑ, σας υπενθυμίζουμε ότι τα προιόντα θα τα παραλάβετε εφόσον καταθέσετε το απαιτούμενο χρηματικό ποσό σε έναν από τους λογαριασμούς μας και μας αποστείλλετε το αποδεικτικό κατάθεσης. Για περισσότερες πληροφορίες επισκεφτείτε την σελίδα μας ΤΡΟΠΟΙ ΠΛΗΡΩΜΗΣ',0,1),(4,'fasdfasd','',1,0),(5,'fasdfasd','',0,0);
/*!40000 ALTER TABLE `payment_methods` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `prefectures`
--

DROP TABLE IF EXISTS `prefectures`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `prefectures` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `prefecture_name` varchar(100) NOT NULL,
  `country_id` int(11) NOT NULL,
  `shipping_cost` int(11) NOT NULL DEFAULT 0,
  `isActive` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=53 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `prefectures`
--

LOCK TABLES `prefectures` WRITE;
/*!40000 ALTER TABLE `prefectures` DISABLE KEYS */;
INSERT INTO `prefectures` VALUES (1,'Αιτωλοακαρνανίας',81,0,1),(2,'Λάρισας',81,0,1),(3,'Ιωαννίνων',81,0,1),(4,'Φθιώτιδας',81,0,1),(5,'Αρκαδίας',81,0,1),(6,'Έβρου',81,0,1),(7,'Εύβοιας',81,0,1),(8,'Σερρών',81,0,1),(9,'Αττικής',81,0,1),(10,'Θεσσαλονίκης',81,0,1),(11,'Λακωνίας',81,0,1),(12,'Κοζάνης',81,0,1),(13,'Δράμας',81,0,1),(14,'Τρικάλων',81,0,1),(15,'Αχαΐας',81,0,1),(16,'Μεσσηνίας',81,0,1),(17,'Βοιωτίας',81,0,1),(18,'Χαλκιδικής',81,0,1),(19,'Δωδεκανήσου',81,0,1),(20,'Ηρακλείου',81,0,1),(21,'Καρδίτσας',81,0,1),(22,'Μαγνησίας',81,0,1),(23,'Ηλείας',81,0,1),(24,'Κυκλάδων',81,0,1),(25,'Ροδόπης',81,0,1),(26,'Κιλκίς',81,0,1),(27,'Πέλλας',81,0,1),(28,'Χανίων',81,0,1),(29,'Γρεβενών',81,0,1),(30,'Κορινθίας',81,0,1),(31,'Αργολίδας',81,0,1),(32,'Λέσβου',81,0,1),(33,'Φωκίδας',81,0,1),(34,'Καβάλας',81,0,1),(35,'Φλώρινας',81,0,1),(36,'Ευρυτανίας',81,0,1),(37,'Λασιθίου',81,0,1),(38,'Ξάνθης',81,0,1),(39,'Καστοριάς',81,0,1),(40,'Ημαθίας',81,0,1),(41,'Άρτας',81,0,1),(42,'Πιερίας',81,0,1),(43,'Θεσπρωτίας',81,0,1),(44,'Ρεθύμνου',81,0,1),(45,'Πρέβεζας',81,0,1),(46,'Χίου',81,0,1),(47,'Κεφαλληνίας',81,0,1),(48,'Σάμου',81,0,1),(49,'Κέρκυρας',81,0,1),(50,'Ζακύνθου',81,0,1),(51,'Λευκάδας',81,0,1),(52,'Άγιο Όρος',81,0,1);
/*!40000 ALTER TABLE `prefectures` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `products`
--

DROP TABLE IF EXISTS `products`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `products` (
  `productId` int(11) NOT NULL AUTO_INCREMENT,
  `productTitle` varchar(100) NOT NULL,
  `productDescription` text NOT NULL,
  `productSubHeader` varchar(45) DEFAULT NULL,
  `stock` int(11) NOT NULL,
  `imgHref` text DEFAULT NULL,
  `price` double NOT NULL,
  `initialPrice` double NOT NULL,
  `code` varchar(45) NOT NULL,
  `related_products` varchar(45) DEFAULT NULL,
  `isActive` int(11) NOT NULL,
  `productLargeDescription` text NOT NULL,
  `isNew` int(11) NOT NULL DEFAULT 0,
  `colorOptions` text NOT NULL DEFAULT '',
  PRIMARY KEY (`productId`)
) ENGINE=InnoDB AUTO_INCREMENT=96 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `products`
--

LOCK TABLES `products` WRITE;
/*!40000 ALTER TABLE `products` DISABLE KEYS */;
INSERT INTO `products` VALUES (38,'Amarillo','Introducing \"Amarillo\" purse—sophistication meets practicality. Stain-resistant fabric, luxurious satin interior, and secure clasp. \n\n*Coming with a personalised dustbag.\n\n\n\n\n\n','',6,'IMG_0549.jpg#IMG_6950.jpg#',89.6,128,'Amarillo','Chloe, Vanilla',1,'<p>Introducing the \"Amarillo\" purse from our winter collection—a fusion of sophistication and practicality. Crafted with precision from stain-resistant fabric, effortlessly cleanable with a tissue or sponge. Inside, discover a luxurious satin interior and a meticulously organized vanity, secured by an engraved clasp. Delivered in a branded dustbag and cardboard box for safekeeping. <br>\n<br>\n<br>\nFeatures: <br>\n<br>\n➺ Stain-resistant fabric <br>\n<br>\n➺ Effortless cleanup with just a tissue or sponge <br>\n<br>\n➺ Luxurious satin interior <br>\n<br>\n➺ Securely delivered in a branded dustbag and cardboard box <br>\n<br>\n➺ Crafted from certified Italian fabric <br>\n<br>\n<br>\nCreation &amp; Delivery: <br>\n<br>\nSavor the anticipation as skilled hands craft your handmade purse, delivered to you within 8-10 working days. <br>\n<br>\n<br>\nMaintenance &amp; Repair:<br>\n<br>\n➺ Do not overfill the bag; store it in its dust bag <br>\n<br>\n➺ For repair reach out to Tierraboutique20@gmail.com after sales service.</p>',0,'Chloe'),(39,'Amare','Introducing \"Amare\"—a summer purse with a vibrant boho pattern, metallic handle, and magnetic button closure. Complete with luxurious satin lining for added comfort and style.\n\n*Coming with a personalised dustbag.\n\n\n\n\n\n','',3,'DSC_0022.jpg#IMG_0537.jpg#',89.6,128,'Amare','Estrella, ElMar, Paloma, Verano',1,'<p>Introducing \"Amare,\" the ultimate summer purse with a vibrant boho pattern, metallic handle, and magnetic button closure. Luxurious satin lining adds comfort and style to your adventures. <br>\n<br>\n<br>\nFeatures: <br>\n<br>\n➺ High quality fabric <br>\n<br>\n➺ Luxurious satin interior <br>\n<br>\n➺ Metallic handle <br>\n<br>\n<br>\nCreation &amp; Delivery: <br>\n<br>\nSavor the anticipation as skilled hands craft your handmade purse, delivered to you within 8-10 working days. <br>\n<br>\n<br>\nMaintenance &amp; Repair: <br>\n<br>\n➺ Do not overfill the bag; store it in its dust bag <br>\n<br>\n➺ For repair reach out to Tierraboutique20@gmail.com after sales service.</p>',0,''),(40,'Chloe','Introducing \"Chloe\" purse—sophistication and practicality combined. Stain-resistant fabric, luxurious satin interior, and secure clasp. \n\n*Coming with a personalised dustbag.\n\n\n','',6,'B2BCB614-8565-4482-9A90-78A51DBEB2D7.jpg#IMG_8965.jpg#',89.6,128,'Chloe','Amarillo, Vanilla',1,'<p>Introducing the \"Chloe\" purse from our winter collection—a fusion of sophistication and practicality. Crafted with precision from stain-resistant fabric, effortlessly cleanable with a tissue or sponge. Inside, discover a luxurious satin interior and a meticulously organized vanity, secured by an engraved clasp. Delivered in a branded dustbag and cardboard box for safekeeping. *The dustbag comes personalised with the first letter of your name. <br>\n<br>\n<br>\nFeatures: <br>\n<br>\n➺ Stain-resistant fabric <br>\n<br>\n➺ Effortless cleanup with just a tissue or sponge <br>\n<br>\n➺ Luxurious satin interior <br>\n<br>\n➺ Securely delivered in a branded dustbag and cardboard box <br>\n<br>\n➺ Crafted from certified Italian fabric <br>\n<br>\n<br>\nCreation &amp; Delivery: <br>\n<br>\nSavor the anticipation as skilled hands craft your handmade purse, delivered to you within 8-10 working days. <br>\n<br>\n<br>\nMaintenance &amp; Repair: <br>\n<br>\n➺ Do not overfill the bag; store it in its dust bag <br>\n<br>\n➺ For repair reach out to Tierraboutique20@gmail.com after sales service.</p>',0,'Amarillo'),(41,'Vanilla','Introducing the \"Vanilla\" purse—elegance meets versatility. Stain-resistant fabric, luxurious satin interior, and secure zip closure. \n\n*Coming with a personalised dustbag.','',5,'IMG_8383.jpg#',94.5,135,'Vanilla','Amarillo, Chloy',1,'<p>Introducing \"Vanilla\" purse from our winter collection, where elegance meets versatility. Crafted with finesse from stain-resistant fabric, cleaning becomes a breeze with just a tissue or sponge. Inside, luxuriate in the satin interior, while a thoughtful vanity ensures your belongings stay organized. This essential accessory is secured with an engraved clasp on the flap, complemented by a reliable zip closure for added security. Delivered in a branded dustbag and cardboard box, your purse is meticulously protected. *Personalize your dustbag with the first letter of your name. <br>\n<br>\nFeatures: <br>\n<br>\n➺ Stain-resistant fabric <br>\n<br>\n➺ Effortless cleanup with just a tissue or sponge <br>\n<br>\n➺ Luxurious satin interior <br>\n<br>\n➺ Secure delivery in a branded dustbag and cardboard box <br>\n<br>\n➺ Crafted with care from certified Italian fabric <br>\n<br>\n➺ Reliable zip closure <br>\n<br>\n<br>\nCreation &amp; Delivery: <br>\n<br>\nSavor the anticipation as skilled hands craft your handmade purse, delivered to you within 8-10 working days. <br>\n<br>\n<br>\nMaintenance &amp; Repair: <br>\n<br>\n➺ Ensure optimal care by avoiding overfilling the bag and storing it in its dust bag. <br>\n<br>\n➺ For repairs and maintenance inquiries, reach out to Tierraboutique20@gmail.com.</p>',0,''),(42,'Safari','Introducing the \"#Safari\" purse—adventure meets elegance. Crafted from eco-leather, it balances sustainability with style. Adorned with a metallic chain and clasp for sophistication. \n\n*Coming with a personalised dustbag.\n\n\n\n\n\n\n','',8,'IMG_7762.jpg#IMG_6547.HEIC#',89.6,128,'Safari','Evelyn, Croco, Elvira',1,'<p>Introducing the \"#Safari\" purse, a symbol of adventure and elegance. Crafted from high-quality eco-leather, this purse embodies sustainability without compromising on style. Adorned with a metallic chain and clasp, it exudes sophistication with a touch of edge. Inside, indulge in the luxurious satin lining, providing both comfort and refinement. *Personalize your dustbag with the first letter of your name. <br>\n<br>\n<br>\nFeatures: <br>\n<br>\n➺ High-quality eco-leather <br>\n<br>\n➺ Metallic chain and clasp <br>\n<br>\n➺ Luxurious satin lining <br>\n<br>\n<br>\nCreation &amp; Delivery: <br>\n<br>\nSavor the anticipation as skilled hands craft your handmade purse, delivered to you within 8-10 working days. <br>\n<br>\n<br>\nMaintenance &amp; Repair: <br>\n<br>\n➺ To maintain its pristine appearance, store the purse in its dust bag when not in use. <br>\n<br>\n➺ For repairs and maintenance inquiries, please contact Tierraboutique20@gmail.com.</p>',0,'Evelyn'),(43,'Evelyn','Introducing the \"Evelyn\" purse—timeless charm. Crafted from jacquard fabric, it exudes elegance. Adorned with a metallic clasp and chain for a touch of glamour. \n\n*Coming with a personalised dustbag.\n\n\n\n\n','',6,'IMG_7024.JPG#',89.6,128,'Evelyn','Safari, Croco, Elvira',1,'<p>Introducing the \"Evelyn\" purse, a timeless accessory blending sophistication and charm. Crafted from high-quality jacquard fabric, it exudes elegance with every detail. Adorned with a metallic clasp and chain, this purse adds a touch of glamour to any ensemble. Inside, experience luxury with the satin lining, providing both comfort and refinement. *Personalize your dustbag with the first letter of your name. <br>\n<br>\n<br>\nFeatures: <br>\n<br>\n➺ High-quality jacquard fabric <br>\n<br>\n➺ Metallic clasp and chain <br>\n<br>\n➺ Luxurious satin lining <br>\n<br>\n<br>\nCreation &amp; Delivery: <br>\n<br>\nSavor the anticipation as skilled hands craft your handmade purse, delivered to you within 8-10 working days. <br>\n<br>\n<br>\nMaintenance &amp; Repair: <br>\n<br>\n➺ To preserve its pristine appearance, store the purse in its dust bag when not in use. <br>\n<br>\n➺ For repairs and maintenance inquiries, please contact Tierraboutique20@gmail.com.</p>',0,'Safari'),(44,'Elvira','Introducing the \"Elvira\" purse—a glamorous essential. Crafted from high-quality fabric with a metallic clasp and chain for added sophistication. \n\n*Coming with a personalised dustbag.\n\n\n\n\n\n','',7,'IMG_6584.jpg#',64.4,92,'Elvira','Evelyn, Croco, Safari',1,'<p>Introducing the \"Elvira\" purse, your go-to accessory for glamorous nights out.&nbsp;</p>\n<p>Crafted from high-quality fabric, it exudes luxury and style, complete with a metallic clasp and chain for added sophistication. Inside, enjoy the comfort of the satin lining as you dance the night away. *Personalize your dustbag with the first letter of your name.&nbsp;</p>\n<p><br></p>\n<p>Features:&nbsp;</p>\n<p>➺ High-quality fabric&nbsp;</p>\n<p>➺ Metallic clasp and chain&nbsp;</p>\n<p>➺ Luxurious satin lining&nbsp;</p>\n<p><br></p>\n<p>Creation &amp; Delivery:&nbsp;</p>\n<p>Savor the anticipation as skilled hands craft your handmade purse, delivered to you within 8-10 working days.&nbsp;</p>\n<p><br></p>\n<p>Maintenance &amp; Repair:&nbsp;</p>\n<p>➺ To maintain its allure, store the purse in its dust bag when not in use.&nbsp;</p>\n<p>➺ For repairs and maintenance inquiries, please contact Tierraboutique20@gmail.com.</p>',0,''),(45,'Amelie','Introducing the \"Amelie\" winter purse—sophistication meets functionality. Crafted from high-quality fabric with chic metallic details. Spacious interior with a vanity for organization. Adjustable strap for convenience. \n\n*Coming with a personalised dustbag.\n\n','',5,'IMG_0540.jpg#IMG_3163.jpg#',89.6,128,'Amelie','Croco, JeannyChoo, Bohemian',1,'<p>Introducing the \"Amelie\" winter purse, a stylish blend of sophistication and functionality. Crafted from high-quality fabric with chic metallic details, it exudes timeless elegance. Inside, revel in the spacious interior featuring a vanity for effortless organization. Complete with an adjustable strap for added convenience. *Personalize your dustbag with the first letter of your name. <br>\n<br>\nFeatures: <br>\n<br>\n➺ High-quality fabric <br>\n<br>\n➺ Metallic details <br>\n<br>\n➺ Spacious interior with vanity <br>\n<br>\n➺ Adjustable strap <br>\n<br>\n➺ Luxurious satin lining <br>\n<br>\n<br>\nCreation &amp; Delivery: <br>\n<br>\nSavor the anticipation as skilled hands craft your handmade purse, delivered to you within 8-10 working days. <br>\n<br>\n<br>\nMaintenance &amp; Repair: <br>\n<br>\n➺ Avoid overfilling the bag; store it in its dust bag <br>\n<br>\n➺ For repairs, contact Tierraboutique20@gmail.com for after-sales service.</p>',0,''),(46,'Croco','.Introducing the \"Croco\" purse—sleek and luxurious. Crafted from high-quality eco-leather with metallic clasp and chain accents for elegance. \n\n*Coming with a personalised dustbag.\n\n\n\n\n\n','',4,'IMG_0526.jpg#',84,120,'Croco','Safari, Evelyn',1,'<p>Introducing the \"Croco\" purse, a sleek and luxurious accessory crafted from high-quality eco-leather. With metallic clasp and chain accents, it exudes elegance. Inside, enjoy the plush comfort of the satin lining. *Personalize your dustbag with the first letter of your name. <br>\n<br>\n<br>\nFeatures: <br>\n<br>\n➺ High-quality eco-leather <br>\n<br>\n➺ Metallic clasp and chain <br>\n<br>\n➺ Plush satin lining <br>\n<br>\n<br>\nCreation &amp; Delivery: <br>\n<br>\nSavor the anticipation as skilled hands craft your handmade purse, delivered to you within 8-10 working days. <br>\n<br>\n<br>\nMaintenance &amp; Repair: <br>\n<br>\n➺ Store the purse in its dust bag when not in use to maintain its pristine condition. <br>\n<br>\n➺ For any repairs or maintenance inquiries, please contact Tierraboutique20@gmail.com</p>',0,''),(47,'Marron','Introducing \"Marron\"—a chic handbag with a metallic chain strap and leopard print pattern. Ideal for day-to-night wear with a detachable vanity.\n\n*Coming with a personalised dustbag.\n\n\n\n\n','',5,'IMG_0579.jpg#IMG_0580.jpg#',89.6,128,'Marron','Croco, Bohemian, JeannyChoo',1,'<p>Introducing \"Marron\"—a stylish handbag with a metallic chain strap and textured surface. Adorned with a leopard or animal print pattern, it\'s perfect for everyday wear from day to night, with a detachable vanity for added convenience.</p>\n<p><br></p>\n<p>Features:</p>\n<p>➺ High-quality fabric</p>\n<p>➺ Metallic details &amp; chain</p>\n<p>➺ Detachable vanity</p>\n<p>➺ Luxurious satin lining</p>\n<p><br></p>\n<p>Creation &amp; Delivery:</p>\n<p>Savor the anticipation as skilled hands craft your handmade purse, delivered to you within 8-10 working days.</p>\n<p><br></p>\n<p>Maintenance &amp; Repair:</p>\n<p>➺ Store the purse in its dust bag when not in use to preserve its pristine condition.</p>\n<p>➺ For repairs or maintenance inquiries, please contact Tierraboutique20@gmail.com.</p>',0,''),(48,'Naomi','Introducing the \"Naomi\" purse—a captivating blend of sophistication and sparkle. Crafted from high-quality fabric, exuding timeless elegance. Metallic details and an acrylic chain add glamour. \n\n*Coming with a personalised dustbag.\n\n\n\n\n\n\n\n','',6,'DSC_0876.JPG#IMG_0527.jpg#',62.3,89,'Naomi','Elvira',1,'<p>Introducing the \"Naomi\" purse, a captivating blend of sophistication and sparkle. Crafted from high-quality fabric, it exudes timeless elegance, complemented by metallic details and an acrylic chain that add a touch of glamour. Inside, indulge in the luxurious comfort of the satin lining.</p>\n<p>*Personalize your dustbag with the first letter of your name.</p>\n<p><br></p>\n<p>Features:</p>\n<p>➺ High-quality fabric</p>\n<p>➺ Metallic details and acrylic chain</p>\n<p>➺ Luxurious satin lining</p>\n<p><br></p>\n<p>Creation &amp; Delivery:</p>\n<p>Savor the anticipation as skilled hands craft your handmade purse, delivered to you within 8-10 working days.</p>\n<p><br></p>\n<p>Maintenance &amp; Repair:</p>\n<p>➺ Store the purse in its dust bag when not in use to preserve its pristine condition.</p>\n<p>➺ For repairs or maintenance inquiries, please contact Tierraboutique20@gmail.com.</p>',0,''),(49,'Bohemian','.\n\n\n\nIntroducing the \"Bohemian\" purse—a fusion of style and elegance. Crafted from high-quality velvet fabric for luxurious texture. \n\n*Coming with a personalised dustbag.\n\n\n\n\n','',6,'IMG_0547.jpg#IMG_6522.jpg#',65.1,93,'Bohemian','Amelie, Marron',1,'<p>Introducing the \"Bohemian\" purse, a fusion of free-spirited style and elegance.&nbsp;</p>\n<p>Crafted from high-quality velvet fabric, it exudes luxurious texture and sophistication. Inside, revel in the comfort of the satin lining, adding a touch of opulence to your ensemble.&nbsp;</p>\n<p>*Personalize your dustbag with the first letter of your name.&nbsp;</p>\n<p><br></p>\n<p>Features:&nbsp;</p>\n<p>➺ High-quality velvet fabric&nbsp;</p>\n<p>➺Luxurious satin lining&nbsp;</p>\n<p><br></p>\n<p>Creation &amp; Delivery:&nbsp;</p>\n<p>Savor the anticipation as skilled hands craft your handmade purse, delivered to you within 8-10 working days.&nbsp;</p>\n<p><br></p>\n<p>Maintenance &amp; Repair:&nbsp;</p>\n<p>➺ Store the purse in its dust bag when not in use to maintain its pristine condition.&nbsp;</p>\n<p>➺ For any repairs or maintenance inquiries, please contact Tierraboutique20@gmail.com</p>',0,''),(50,'JeannyChoo','\r\n\r\n\r\n\r\nIntroducing the \"Jeanny Choo\" purse—a chic and versatile accessory. Crafted from high-quality jean fabric for a casual yet stylish vibe. Detachable vanity offers convenience on the go. \r\n\r\n*Coming with a personalised dustbag.\r\n\r\n\r\n\r\n\r\n','',6,'IMG_6392.jpg#IMG_6393.jpg#',64.4,92,'JeannyChoo','Amelie, Marron, Bohemian',1,'<p>Introducing the \"Jeanny Choo\" purse, a chic and versatile accessory designed for everyday elegance. Made from high-quality jean fabric, it exudes a casual yet stylish vibe. Complete with a detachable vanity, this purse offers convenience and organization on the go. Inside, indulge in the luxurious comfort of the satin lining.</p>\n<p>*Personalize your dustbag with the first letter of your name.</p>\n<p><br></p>\n<p>Features:</p>\n<p>➺ High-quality jean fabric</p>\n<p>➺ Detachable vanity</p>\n<p>➺ Luxurious satin lining</p>\n<p><br></p>\n<p>Creation &amp; Delivery:</p>\n<p>Savor the anticipation as skilled hands craft your handmade purse, delivered to you within 8-10 working days.</p>\n<p><br></p>\n<p>Maintenance &amp; Repair:</p>\n<p>➺ Store the purse in its dust bag when not in use to maintain its pristine condition.</p>\n<p>➺ For any repairs or maintenance inquiries, please contact Tierraboutique20@gmail.com.</p>',0,''),(51,'Vaqueros','Introducing \"Vaqueros\"—a trendy jean purse with golden details and metallic handles. Featuring a luxurious satin lining for added elegance.\n\n*Coming with a personalised dustbag.\n','',3,'IMG_0536.jpg#',66.5,95,'Vaqueros','Jeanny Choo',1,'<p>Introducing \"Vaqueros,\" a stylish jean purse with golden details and metallic handles. Featuring a luxurious satin lining for added elegance and comfort. Perfect for adding a touch of glamour to any outfit.&nbsp;</p>\n<p>Features:&nbsp;</p>\n<p>➺ High-quality jean fabric&nbsp;</p>\n<p>➺ Metallic handles&nbsp;</p>\n<p>➺ Luxurious satin lining&nbsp;</p>\n<p><br></p>\n<p>Creation &amp; Delivery:&nbsp;</p>\n<p>Savor the anticipation as skilled hands craft your handmade purse, delivered to you within 8-10 working days.</p>\n<p><br></p>\n<p>Maintenance &amp; Repair:&nbsp;</p>\n<p>➺ Store the purse in its dust bag when not in use to maintain its pristine condition.&nbsp;</p>\n<p>➺ For any repairs or maintenance inquiries, please contact Tierraboutique20@gmail.com.</p>',0,''),(52,'Jasmine','\r\nIntroducing the \"Jasmine\" purse—timeless elegance and sophistication. Crafted from high-quality jacquard fabric, exuding luxury. Adorned with a metallic clasp and pearl chain for glamour. \r\n\r\n*Coming with a personalised dustbag.\r\n\r\n\r\n\r\n\r\n\r\n','',6,'IMG_3232 (1)-min.jpeg#',75.6,108,'Jasmine','Bella, Limoncello',1,'<p>Introducing the \"Jasmine\" purse, an epitome of timeless elegance and sophistication. Crafted from high-quality jacquard fabric, it exudes luxury with every detail. Adorned with a metallic clasp and a pearl chain, it adds a touch of glamour to any ensemble. Inside, indulge in the plush comfort of the satin lining, ensuring a delightful experience every time you reach for your essentials.</p>\n<p>Features:</p>\n<p>➺ High-quality jacquard fabric</p>\n<p>➺ Metallic clasp and pearl chain</p>\n<p>➺ Plush satin lining for luxurious comfort</p>\n<p><br></p>\n<p>Creation &amp; Delivery:</p>\n<p>Savor the anticipation as skilled hands craft your handmade purse, delivered to you within 8-10 working days.</p>\n<p><br></p>\n<p>Maintenance &amp; Repair:</p>\n<p>➺ Store the purse in its dust bag when not in use to maintain its pristine condition.</p>\n<p>➺ For repairs or maintenance inquiries, please contact Tierraboutique20@gmail.com.</p>',0,'Bella'),(53,'Bella','Introducing the \"Bella\" purse—timeless elegance and sophistication. Crafted from high-quality jacquard fabric, exuding luxury. Adorned with a metallic clasp and pearl chain for glamour. \n\n*Coming with a personalised dustbag.\n','',8,'IMG_1007.jpg#IMG_1269.jpeg#',75.6,108,'Bella','Jasmine, Limoncello',1,'<p>Introducing the \"Bella\" purse, an epitome of timeless elegance and sophistication. Crafted from high-quality jacquard fabric, it exudes luxury with every detail. Adorned with a metallic clasp and a pearl chain, it adds a touch of glamour to any ensemble. Inside, indulge in the plush comfort of the satin lining, ensuring a delightful experience every time you reach for your essentials.</p>\n<p><br></p>\n<p>Features:</p>\n<p>➺ High-quality jacquard fabric</p>\n<p>➺ Metallic clasp and pearl chain</p>\n<p>➺ Plush satin lining for luxurious comfort</p>\n<p><br></p>\n<p>Creation &amp; Delivery:</p>\n<p>Savor the anticipation as skilled hands craft your handmade purse, delivered to you within 8-10 working days.</p>\n<p><br></p>\n<p>Maintenance &amp; Repair:</p>\n<p>➺ Store the purse in its dust bag when not in use to maintain its pristine condition.</p>\n<p>➺ For repairs or maintenance inquiries, please contact Tierraboutique20@gmail.com.</p>',0,'Jasmine'),(54,'Marine','Introducing the Marine purse, the epitome of summer chic. Crafted from high-quality jean fabric with plush satin lining, making it perfect for leisurely island strolls. \n\n*Coming with a personalised dustbag.\n\n\n\n','',9,'IMG_2398.jpg#IMG_2404.jpg#',36.4,52,'Marine','Magenta, ElMar, Paloma',1,'<p>Introducing the \"Marine\" purse, the ultimate summer accessory for leisurely island strolls. Crafted from high-quality fabric, it embodies the relaxed elegance of coastal living. The plush satin lining ensures comfort while adding a touch of luxury to your seaside adventures.</p>\n<p>Features:</p>\n<p>➺High-quality fabric</p>\n<p>➺Luxurious satin lining</p>\n<p>➺Perfect for island strolls and summer adventures</p>\n<p><br></p>\n<p>Creation &amp; Delivery:</p>\n<p>Savor the anticipation as skilled hands craft your handmade purse, delivered to you within 8-10 working days.</p>\n<p><br></p>\n<p>Maintenance &amp; Repair:</p>\n<p>➺Store the purse in its dust bag when not in use to maintain its pristine condition.</p>\n<p>➺For repairs or maintenance inquiries, please contact Tierraboutique20@gmail.com</p>',0,'Magenta'),(55,'Magenta','Introducing the \"Magenta\" purse—the epitome of summer chic. Crafted from high-quality leopard fabric with plush satin lining, making it perfect for leisurely island strolls. \n. \n\n*Coming with a personalised dustbag.\n\n\n\n\n\n\n','',9,'03C8C3F7-DE1C-41D6-AE65-3F8B717A56E0.JPEG#IMG_1962.jpg#',36.4,52,'Magenta','Marine, ElMar, Paloma',1,'<p>Introducing the \"Magenta\" purse, the ultimate summer accessory for leisurely island strolls.&nbsp;</p>\n<p>Crafted from high-quality fabric, it embodies the relaxed elegance of coastal living. The plush satin lining ensures comfort while adding a touch of luxury to your seaside adventures.&nbsp;</p>\n<p>Features:&nbsp;</p>\n<p>➺ High-quality fabric&nbsp;</p>\n<p>➺ Luxurious satin lining&nbsp;</p>\n<p>➺ Perfect for island strolls and summer adventures&nbsp;</p>\n<p><br></p>\n<p>Creation &amp; Delivery:&nbsp;</p>\n<p>Savor the anticipation as skilled hands craft your handmade purse, delivered to you within 8-10 working days.&nbsp;</p>\n<p><br></p>\n<p>Maintenance &amp; Repair:&nbsp;</p>\n<p>➺ Store the purse in its dust bag when not in use to maintain its pristine condition.&nbsp;</p>\n<p>➺ For repairs or maintenance inquiries, please contact Tierraboutique20@gmail.com</p>',0,'Marine'),(56,'Paloma','Introducing the \"Paloma\" purse—your go-to boho-chic accessory for summer. Featuring a vibrant bohemian pattern with red and gold details, and a detachable strap for versatile styling. Luxurious satin lining ensures comfort, making it perfect for leisurely island strolls. \n\n*Coming with a personalised dustbag.\n\n\n\n\n\n\n','',6,'IMG_0534.jpg#',68.6,98,'Paloma','ElMar, Marine, Magenta',1,'<p>Introducing the \"Paloma\" purse, your quintessential summer accessory with a boho twist. Crafted from high-quality fabric adorned with a vibrant bohemian pattern, it captures the essence of carefree island strolls. Accentuated with striking red and gold details and featuring a detachable strap for versatile styling. Inside, indulge in the luxurious comfort of the satin lining.</p>\n<p><br></p>\n<p>Features:</p>\n<p>➺High-quality fabric in striking red hue</p>\n<p>➺ Metallic details</p>\n<p>➺ Luxurious satin lining</p>\n<p><br></p>\n<p>Creation &amp; Delivery:</p>\n<p>Savor the anticipation as skilled hands craft your handmade purse, delivered to you within 8-10 working days.</p>\n<p><br></p>\n<p>Maintenance &amp; Repair:</p>\n<p>➺ Store the purse in its dust bag when not in use to maintain its pristine condition</p>\n<p>➺ For any repairs or maintenance inquiries, please contact Tierraboutique20@gmail.com</p>',0,'ElMar'),(57,'Bianca','Introducing the \"Bianca\" purse—your go-to accessory for sunny days. Cream color with golden details, featuring metallic accents and a detachable strap for versatility. Luxurious satin lining ensures comfort, making it perfect for stylish strolls in town.\n\n*Coming with a personalised dustbag.\n\n\n\n\n\n','',7,'IMG_0546.jpg#',68.6,98,'Bianca','Limoncello, Vanilla',1,'<p>Introducing the \"Bianca\" purse—an ideal companion for sunny days, perfect for everyday occasions and stylish strolls in town. Crafted from high-quality fabric in a cream color with golden details. Complete with metallic details and a detachable strap for versatile styling. Inside, indulge in the luxurious comfort of the satin lining.<br>\n</p>\n<p>Features:</p>\n<p>➺High-quality</p>\n<p>➺ Detachable strap</p>\n<p>➺ Metallic details</p>\n<p>➺ Luxurious satin lining</p>\n<p><br></p>\n<p>Creation &amp; Delivery:</p>\n<p>Savor the anticipation as skilled hands craft your handmade purse, delivered to you within 8-10 working days.</p>\n<p><br></p>\n<p>Maintenance &amp; Repair:</p>\n<p>➺ Store the purse in its dust bag when not in use to maintain its pristine condition</p>\n<p>➺ For any repairs or maintenance inquiries, please contact Tierraboutique20@gmail.com</p>',0,''),(58,'Verano','Introducing \"Verano\"—the epitome of summer chic. Crafted from straw with shinning stones and golden details, featuring metallic accents and beads. With luxurious satin lining. \n\n*Coming with a personalised dustbag.','',5,'IMG_0533.jpg#',92.4,132,'Verano','Estrella, ElMar, Paloma',1,'<p>Introducing \"Verano,\" the ultimate summer purse radiating with elegance and charm. Crafted from straw with shinning stones and golden details, it embodies the essence of summertime luxury. Its metallic details and beads add a touch of sophistication, while the satin lining ensures comfort. Complete with a stylish handle, this purse is your perfect companion for sunny days and warm evenings.<br>\n</p>\n<p>Features:</p>\n<p>➺High-quality</p>\n<p>➺ Handle</p>\n<p>➺ Metallic details</p>\n<p>➺ Luxurious satin lining</p>\n<p><br></p>\n<p>Creation &amp; Delivery:</p>\n<p>Savor the anticipation as skilled hands craft your handmade purse, delivered to you within 8-10 working days.</p>\n<p><br></p>\n<p>Maintenance &amp; Repair:</p>\n<p>➺ Store the purse in its dust bag when not in use to maintain its pristine condition</p>\n<p>➺ For any repairs or maintenance inquiries, please contact Tierraboutique20@gmail.com</p>',0,'Estrella'),(59,'Selva','Introducing the \"Selva\" purse—your tropical getaway essential. Crafted from straw with metallic details and a vibrant green acrylic chain. Satin lining ensures comfort. Perfect for adding a playful touch to your summer ensemble.\n\n\n*Coming with a personalised dustbag.\n\n\n\n','',1,'IMG_0535.jpg#IMG_0538.jpg#',92.4,132,'Selva','Verano, Estrella',1,'<p>Introducing the \"Selva\" purse—a summer essential that exudes tropical charm. Crafted from straw with metallic details, it captures the essence of a lush jungle retreat. Adorned with a vibrant green acrylic chain for a pop of color, it adds a playful touch to your ensemble. Inside, indulge in the luxurious comfort of the satin lining, ensuring both style and relaxation during sunny summer days.</p>\n<p><br>\nFeatures:</p>\n<p>➺High-quality straw composition</p>\n<p>➺ Acrylic handles</p>\n<p>➺ Luxurious satin lining</p>\n<p><br></p>\n<p>Creation &amp; Delivery:</p>\n<p>Savor the anticipation as skilled hands craft your handmade purse, delivered to you within 8-10 working days.</p>\n<p><br></p>\n<p>Maintenance &amp; Repair:</p>\n<p>➺ Store the purse in its dust bag when not in use to maintain its pristine condition</p>\n<p>➺ For any repairs or maintenance inquiries, please contact Tierraboutique20@gmail.com</p>',0,''),(60,'Estrella','Introducing \"Estrella\"—the epitome of summer chic. Crafted from straw with shinning, golden details. With luxurious satin lining and metallic handle. \n\n*Coming with a personalised dustbag.','',7,'IMG_0539.jpg#IMG_0545.jpg#',92.4,132,'Estrella','Verano, Selva, Paloma, ElMar',1,'<p>Introducing \"Estrella,\" the ultimate summer purse radiating with elegance and charm. Crafted from straw with shinning, golden details, it embodies the essence of summertime luxury. Its metallic touches add a touch of sophistication, while the satin lining ensures comfort. Complete with a stylish handle, this purse is your perfect companion for sunny days and warm evenings. <br>\n<br>\n<br>\nFeatures: <br>\n<br>\n➺High-quality <br>\n<br>\n➺ Merallic handle <br>\n<br>\n➺ Metallic details <br>\n<br>\n➺ Luxurious satin lining <br>\n<br>\n<br>\nCreation &amp; Delivery: <br>\n<br>\nSavor the anticipation as skilled hands craft your handmade purse, delivered to you within 8-10 working days. <br>\n<br>\n<br>\nMaintenance &amp; Repair: <br>\n<br>\n➺ Store the purse in its dust bag when not in use to maintain its pristine condition <br>\n<br>\n➺ For any repairs or maintenance inquiries, please contact Tierraboutique20@gmail.com</p>',0,'Verano'),(61,'El Mar','Introducing the \"El Mar\" purse—your go-to boho-chic accessory for summer. Featuring a vibrant bohemian pattern with blue and gold details, and a detachable strap for versatile styling. Luxurious satin lining ensures comfort, making it perfect for leisurely island strolls. \n\n*Coming with a personalised dustbag.\n\n\n\n\n\n\n','',2,'IMG_0543.jpg#IMG_0548.jpg#',68.6,98,'ElMar','Paloma, Verano, Estrella, Selva',1,'<p>Introducing the \"El Mar\" purse, your quintessential summer accessory with a boho twist. Crafted from high-quality fabric adorned with a vibrant bohemian pattern, it captures the essence of carefree island strolls. Accentuated with striking blue and gold details and featuring a detachable strap for versatile styling. Inside, indulge in the luxurious comfort of the satin lining.</p>\n<p>Features:</p>\n<p>➺High-quality fabric in striking blue hue</p>\n<p>➺ Metallic details</p>\n<p>➺ Luxurious satin lining</p>\n<p><br></p>\n<p>Creation &amp; Delivery:</p>\n<p>Savor the anticipation as skilled hands craft your handmade purse, delivered to you within 8-10 working days.</p>\n<p><br></p>\n<p>Maintenance &amp; Repair:</p>\n<p>➺ Store the purse in its dust bag when not in use to maintain its pristine condition</p>\n<p>➺ For any repairs or maintenance inquiries, please contact Tierraboutique20@gmail.com</p>',0,'Paloma'),(62,'Diamante (silver)','Introducing \"Diamante\"—a purse from our limited luxury collection, perfect for special occasions. Crafted from high-quality satin fabric with a metallic clasp and Swarovski-type rhinestones. Satin lining ensures luxurious comfort.\n\n*Coming with a personalised dustbag.\n\n\n\n\n','',8,'IMG_0541.jpg#',89.6,128,'DiamanteSilver','DiamanteBlack, Cinderella, Argenta, Princessa',1,'<p>Introducing \"Diamante,\" a purse from our limited luxury collection, designed for special occasions where elegance reigns supreme. Crafted from high-quality satin fabric, it exudes sophistication and refinement. Adorned with a metallic clasp and Swarovski-type rhinestones, it adds a touch of sparkle and glamour to your ensemble. Inside, indulge in the luxurious comfort of the satin lining, ensuring you feel pampered and stylish throughout the event.<br>\n</p>\n<p>Features:</p>\n<p>➺ High-quality fabric</p>\n<p>➺ Swarovski-type rhinestones</p>\n<p>➺ Metallic details</p>\n<p>➺ Luxurious satin lining</p>\n<p><br></p>\n<p>Creation &amp; Delivery:</p>\n<p>Savor the anticipation as skilled hands craft your handmade purse, delivered to you within 8-10 working days.</p>\n<p><br></p>\n<p>Maintenance &amp; Repair:</p>\n<p>➺ Store the purse in its dust bag when not in use to maintain its pristine condition</p>\n<p>➺ For any repairs or maintenance inquiries, please contact Tierraboutique20@gmail.com</p>',0,'DiamanteBlack'),(63,'Diamante (black)','Introducing \"Diamante\"—a purse from our limited luxury collection, perfect for special occasions. Crafted from high-quality satin fabric with a metallic clasp and Swarovski-type rhinestones. Satin lining ensures luxurious comfort.\n\n*Coming with a personalised dustbag.\n\n','',8,'IMG_0542.jpg#IMG_7763.jpg#',89.6,128,'DiamanteBlack','DiamanteSilver, Cinderella, Argenta, Princess',1,'<p>Introducing \"Diamante,\" a purse from our limited luxury collection, designed for special occasions where elegance reigns supreme. Crafted from high-quality satin fabric, it exudes sophistication and refinement. Adorned with a metallic clasp and Swarovski-type rhinestones, it adds a touch of sparkle and glamour to your ensemble. Inside, indulge in the luxurious comfort of the satin lining, ensuring you feel pampered and stylish throughout the event. &nbsp;<br>\n<br>\n<br>\nFeatures:<br>\n<br>\n➺ High-quality fabric &nbsp;<br>\n<br>\n➺ Swarovski-type rhinestones<br>\n<br>\n➺ Metallic details &nbsp;<br>\n<br>\n➺ Luxurious satin lining &nbsp;&nbsp;<br>\n<br>\n<br>\nCreation &amp; Delivery:<br>\n<br>\nSavor the anticipation as skilled hands craft your handmade purse, delivered to you within 8-10 working days. &nbsp;<br>\n<br>\n<br>\n<br>\nMaintenance &amp; Repair:<br>\n<br>\n➺ Store the purse in its dust bag when not in use to maintain its pristine condition<br>\n<br>\n➺ For any repairs or maintenance inquiries, please contact Tierraboutique20@gmail.com<br>\n&nbsp;</p>',0,'DiamanteSilver'),(64,'Oceano','Introducing \"Oceano\"—a purse from our limited luxury collection, perfect for special occasions. Crafted from high-quality satin fabric with a metallic clasp and adorned with goose\'s feathers. Satin lining ensures luxurious comfort.\n\n*Coming with a personalised dustbag.\n\n\n\n','',8,'C958CA8C-BE1C-4312-B999-879059BB3247.webp#',92.4,132,'Oceano','Cinderella, Argenta, Princessa, Violeta',1,'<p>Introducing \"Oceano,\" a purse from our limited luxury collection, designed for special occasions where opulence meets elegance. Crafted from high-quality satin fabric, it exudes sophistication and refinement. Adorned with a metallic clasp and delicately embellished with goose\'s feathers, it adds a touch of luxury and allure to your ensemble. Inside, indulge in the luxurious comfort of the satin lining, ensuring you feel pampered and stylish throughout the event.</p>\n<p><br>\nFeatures:</p>\n<p>➺ High-quality fabric</p>\n<p>➺ Goose\'s feathers</p>\n<p>➺ Metallic details</p>\n<p>➺ Luxurious satin lining</p>\n<p><br></p>\n<p>Creation &amp; Delivery:</p>\n<p>Savor the anticipation as skilled hands craft your handmade purse, delivered to you within 8-10 working days.</p>\n<p><br></p>\n<p>Maintenance &amp; Repair:</p>\n<p>➺ Store the purse in its dust bag when not in use to maintain its pristine condition</p>\n<p>➺ For any repairs or maintenance inquiries, please contact Tierraboutique20@gmail.com</p>',0,'Princessa, Violeta'),(65,'Princessa','Introducing \"Princessa\"—a purse from our limited luxury collection, perfect for special occasions. Crafted from high-quality satin fabric with a metallic clasp and adorned with feathers. Satin lining ensures luxurious comfort.\n\n*Coming with a personalised dustbag.','',9,'princessa1.jpg#princessa2.jpg#',92.4,132,'Princessa','Cinderella, Argenta, Kates',1,'<p>Introducing \"Princessa,\" a purse from our limited luxury collection, designed for special occasions where opulence meets elegance. Crafted from high-quality satin fabric, it exudes sophistication and refinement. Adorned with a metallic clasp and delicately embellished with feathers, it adds a touch of luxury and allure to your ensemble.<br>\nInside, indulge in the luxurious comfort of the satin lining, ensuring you feel pampered and stylish throughout the event.</p>\n<p><br>\nFeatures:</p>\n<p>➺ High-quality fabric</p>\n<p>➺ Feathers</p>\n<p>➺ Metallic details</p>\n<p>➺ Luxurious satin lining<br>\n<br>\n<br>\nCreation &amp; Delivery:<br>\n<br>\nSavor the anticipation as skilled hands craft your handmade purse, delivered to you within 8-10 working days.<br>\n&nbsp;</p>\n<p>Maintenance &amp; Repair:</p>\n<p>➺ Store the purse in its dust bag when not in use to maintain its pristine condition</p>\n<p>➺ For any repairs or maintenance inquiries, please contact Tierraboutique20@gmail.com</p>',0,'Kates'),(66,'Argenta','Introducing \"Argenta\"—a dazzling purse adorned with shimmering sequins for ultimate glamour. Featuring a metallic clasp and satin lining for added elegance and comfort.\n\n*Coming with a personalised dustbag.\n','',4,'IMG_0532.jpg#',92.4,132,'Argenta','DiamanteBlack, DiamanteSilver, Cinderella',1,'<p>Introducing \"Argenta,\" a dazzling purse that epitomizes glamour and sophistication. This exquisite piece is adorned with shimmering sequins that catch and reflect the light, ensuring you sparkle and shine at every special occasion. Complete with a metallic clasp for added elegance and a satin lining for luxurious comfort, the \"Argenta\" purse is the perfect accessory to elevate your ensemble. <br>\n<br>\nFeatures: <br>\n<br>\n➺ High-quality sequin fabric <br>\n<br>\n➺ Metallic details <br>\n<br>\n➺ Luxurious satin lining <br>\n<br>\n<br>\nCreation &amp; Delivery: <br>\n<br>\nSavor the anticipation as skilled hands craft your handmade purse, delivered to you within 8-10 working days. <br>\n<br>\n<br>\nMaintenance &amp; Repair: <br>\n<br>\n➺ Store the purse in its dust bag when not in use to maintain its pristine condition <br>\n<br>\n➺ For any repairs or maintenance inquiries, please contact Tierraboutique20@gmail.com</p>',0,'Cinderella, Aurelia'),(67,'Cinderella','Introducing \"Cinderella\"—a dazzling purse adorned with shimmering sequins for ultimate glamour. Featuring a metallic clasp and satin lining for added elegance and comfort.\n\n*Coming with a personalised dustbag.\n','',5,'DSC_0817.JPG#IMG_0525.jpg#',92.4,132,'Cinderella','DiamanteBlack, DiamanteSilver, Argenta',1,'<p>Introducing \"Cinderella,\" a dazzling purse that epitomizes glamour and sophistication. This exquisite piece is adorned with shimmering sequins that catch and reflect the light, ensuring you sparkle and shine at every special occasion. Complete with a metallic clasp for added elegance and a satin lining for luxurious comfort, the \"Argenta\" purse is the perfect accessory to elevate your ensemble. <br>\n<br>\n<br>\nFeatures: <br>\n<br>\n➺ High-quality sequin fabric <br>\n<br>\n➺ Metallic details <br>\n<br>\n➺ Luxurious satin lining <br>\n<br>\n<br>\nCreation &amp; Delivery: <br>\n<br>\nSavor the anticipation as skilled hands craft your handmade purse, delivered to you within 8-10 working days. <br>\n<br>\n<br>\nMaintenance &amp; Repair: <br>\n<br>\n➺ Store the purse in its dust bag when not in use to maintain its pristine condition <br>\n<br>\n➺ For any repairs or maintenance inquiries, please contact Tierraboutique20@gmail.com</p>',0,'Aurelia, Argenta'),(68,'Aurelia','Introducing \"Aurelia\"—a dazzling purse adorned with shimmering sequins for ultimate glamour. Featuring a metallic clasp and satin lining for added elegance and comfort.\n\n*Coming with a personalised dustbag.\n','',1,'IMG_0528.jpg#',101.5,145,'Aurelia','DiamanteBlack, DiamanteSilver, Cinderella, Ar',1,'<p>Introducing \"Aurelia,\" a dazzling purse that epitomizes glamour and sophistication. This exquisite piece is adorned with shimmering sequins that catch and reflect the light, ensuring you sparkle and shine at every special occasion. Complete with a metallic clasp for added elegance and a satin lining for luxurious comfort, the \"Argenta\" purse is the perfect accessory to elevate your ensemble. <br>\n<br>\nFeatures: <br>\n<br>\n➺ High-quality sequin fabric <br>\n<br>\n➺ Metallic details <br>\n<br>\n➺ Luxurious satin lining <br>\n<br>\n<br>\nCreation &amp; Delivery: <br>\n<br>\nSavor the anticipation as skilled hands craft your handmade purse, delivered to you within 8-10 working days. <br>\n<br>\n<br>\nMaintenance &amp; Repair: <br>\n<br>\n➺ Store the purse in its dust bag when not in use to maintain its pristine condition <br>\n<br>\n➺ For any repairs or maintenance inquiries, please contact Tierraboutique20@gmail.com</p>',0,'Cinderella, Argenta'),(69,'Morocco','Introducing the \"Morocco\" purse—a luxurious addition to our collection crafted from stain-resistant and excellent quality fabric. Easy to clean with just a tissue or sponge, featuring bamboo handles and lined with luxurious satin.\n\n*Coming with a personalised dustbag.\n\n\n\n\n\n\n','',7,'IMG_1898.jpg#',78.4,112,'Morocco','Sienna, AfricaBlack, AfricaWhite',1,'<p>Introducing the \"Morocco\" purse, a luxurious addition to our collection crafted from stain-resistant and excellent quality fabric. This purse is designed to combine practicality with elegance, featuring a sleek design that\'s easy to clean with just a tissue or sponge. Complete with bamboo handles for a touch of natural sophistication and lined with luxurious satin, the \"Morocco\" purse is the perfect accessory for any occasion.</p>\n<p><br>\nFeatures:</p>\n<p>➺ Luxury fabric</p>\n<p>➺ Magnetic button</p>\n<p>➺ Bamboo handles</p>\n<p>➺ Satin lining</p>\n<p><br></p>\n<p>Creation &amp; Delivery:</p>\n<p>Savor the anticipation as skilled hands craft your handmade purse, delivered to you within 8-10 working days.</p>\n<p><br></p>\n<p>Maintenance &amp; Repair:</p>\n<p>➺ Store the purse in its dust bag when not in use to maintain its pristine condition</p>\n<p>➺ For any repairs or maintenance inquiries, please contact Tierraboutique20@gmail.</p>',0,'Morocco'),(70,'Cheryl','Introducing the \"Cheryl\" purse—a luxurious statement piece crafted from stain-resistant HERMES® fabric. Easy to clean with just a tissue or sponge, featuring a zipper closure, magnetic buttons, and lined with luxurious satin.\n\n*Coming with a personalised dustbag.\n','',7,'IMG_2535.JPG#',87.5,125,'Cheryl','Pistachio',1,'<p>Introducing the \"Cheryl\" purse, a luxurious statement piece crafted from stain-resistant HERMES® fabric. This exquisite purse combines practicality with elegance, boasting a sleek design that\'s easy to clean with just a tissue or sponge. Complete with a zipper closure for security and metallic buttons for added flair, the \"Cheryl\" purse is lined with luxurious satin, offering both style and sophistication.<br>\n<br>\n</p>\n<p>Features:<br>\n<br>\n➺ Luxury HERMES® fabric<br>\n<br>\n➺ Magnetic buttons<br>\n<br>\n➺ Zipper<br>\n<br>\n➺ Satin lining<br>\n<br>\n<br>\nCreation &amp; Delivery:<br>\n<br>\nSavor the anticipation as skilled hands craft your handmade purse, delivered to you within 8-10 working days.<br>\n<br>\n<br>\nMaintenance &amp; Repair:<br>\n<br>\n➺ Store the purse in its dust bag when not in use to maintain its pristine condition<br>\n<br>\n➺ For any repairs or maintenance inquiries, please contact Tierraboutique20@gmail.</p>',0,'Pistachio'),(71,'Pistachio','Introducing the \"Pistachio\" purse—a luxurious statement piece crafted from stain-resistant HERMES® fabric. Easy to clean with just a tissue or sponge, featuring a zipper closure, magnetic buttons, and lined with luxurious satin.\n\n*Coming with a personalised dustbag.\n','',7,'IMG_2542.JPG#',87.5,125,'Pistachio','Cheryl',1,'<p>Introducing the \"Pistachio\" purse, a luxurious statement piece crafted from stain-resistant HERMES® fabric. This exquisite purse combines practicality with elegance, boasting a sleek design that\'s easy to clean with just a tissue or sponge. Complete with a zipper closure for security and metallic buttons for added flair, the \"Cheryl\" purse is lined with luxurious satin, offering both style and sophistication.</p>\n<p><br>\nFeatures:</p>\n<p>➺ Luxury HERMES® fabric</p>\n<p>➺ Magnetic buttons</p>\n<p>➺ Zipper</p>\n<p>➺ Satin lining</p>\n<p><br></p>\n<p>Creation &amp; Delivery:</p>\n<p>Savor the anticipation as skilled hands craft your handmade purse, delivered to you within 8-10 working days.</p>\n<p><br></p>\n<p>Maintenance &amp; Repair:</p>\n<p>➺ Store the purse in its dust bag when not in use to maintain its pristine condition</p>\n<p>➺ For any repairs or maintenance inquiries, please contact Tierraboutique20@gmail.</p>',0,'Cheryl'),(72,'Africa (black)','Introducing \"Africa\"—a luxurious summer purse crafted from FENDI® fabric, adorned with intricate velvet details. Stain-resistant and easy to clean, featuring a metallic button and sumptuous satin lining.\n\n*Coming with a personalised dustbag.\n','',6,'IMG_3173.jpg#IMG_2598.jpg#IMG_3217.jpg#',89.6,128,'AfricaBlack','AfricaWhite, Morocco, Sienna',1,'<p>Introducing \"Africa,\" where elegance meets adventure. Crafted from luxurious FENDI® fabric, this summer purse is adorned with intricate velvet details, making it a stylish companion for your summer adventures. Stain-resistant and easy to clean, with a metallic button and sumptuous satin lining. <br>\n<br>\nFeatures: <br>\n<br>\n➺ Luxury FENDI® fabric <br>\n<br>\n➺ Magnetic button <br>\n<br>\n➺ Satin lining <br>\n<br>\n<br>\nCreation &amp; Delivery: <br>\n<br>\nSavor the anticipation as skilled hands craft your handmade purse, delivered to you within 8-10 working days. <br>\n<br>\n<br>\nMaintenance &amp; Repair: <br>\n<br>\n➺ Store the purse in its dust bag when not in use to maintain its pristine condition <br>\n<br>\n➺ For any repairs or maintenance inquiries, please contact Tierraboutique20@gmail</p>',0,'AfriceWhite'),(73,'Africa (white)','Introducing \"Africa\"—a luxurious summer purse crafted from FENDI® fabric, adorned with intricate velvet details. Stain-resistant and easy to clean, featuring a metallic button and sumptuous satin lining.\n\n*Coming with a personalised dustbag.\n','',6,'IMG_3117.jpg#IMG_2598.jpg#IMG_3414.jpg#',89.6,128,'AfricaWhite','AfricaBlack, Sienna, Morocco',1,'<p>Introducing \"Africa,\" where elegance meets adventure. Crafted from luxurious FENDI® fabric, this summer purse is adorned with intricate velvet details, making it a stylish companion for your summer adventures. Stain-resistant and easy to clean, with a metallic button and sumptuous satin lining. <br>\n<br>\nFeatures: <br>\n<br>\n➺ Luxury FENDI® fabric <br>\n<br>\n➺ Magnetic button <br>\n<br>\n➺ Satin lining <br>\n<br>\n<br>\nCreation &amp; Delivery: <br>\n<br>\nSavor the anticipation as skilled hands craft your handmade purse, delivered to you within 8-10 working days. <br>\n<br>\n<br>\nMaintenance &amp; Repair: <br>\n<br>\n➺ Store the purse in its dust bag when not in use to maintain its pristine condition <br>\n<br>\n➺ For any repairs or maintenance inquiries, please contact Tierraboutique20@gmail</p>',0,'AfricaBlack'),(74,'Sienna','Introducing the \"Sienna\" purse—crafted with luxury fabric, stain-resistant and easy to clean. Adorned with metallic details and a button, complemented by a satin lining for added elegance.\n\n*Coming with a personalised dustbag.\n','',6,'IMG_3135.jpg#',89.6,128,'Sienna','AfricaBlack, AfricaWhite, Morocco',1,'<p>Introducing the \"Sienna\" purse—a stylish companion for your summer adventures. Crafted from stain-resistant fabric, it\'s perfect for days spent under the sun. Complete with metallic details and a button, paired with a luxurious satin lining for effortless elegance.<br>\n</p>\n<p>Features:</p>\n<p>➺ Luxury &amp; stain-resistant fabric</p>\n<p>➺ Magnetic button</p>\n<p>➺ Metallic handle</p>\n<p>➺ Satin lining</p>\n<p><br></p>\n<p>Creation &amp; Delivery:</p>\n<p>Savor the anticipation as skilled hands craft your handmade purse, delivered to you within 8-10 working days.</p>\n<p><br></p>\n<p>Maintenance &amp; Repair:</p>\n<p>➺ Store the purse in its dust bag when not in use to maintain its pristine condition</p>\n<p>➺ For any repairs or maintenance inquiries, please contact Tierraboutique20@gmail</p>',0,''),(75,'Limoncello','Introducing \"Limoncello\"—a state-of-the-art little purse with lime and golden details, featuring a versatile chain for two different ways to wear.\n\n*Coming with a personalised dustbag.\n','',8,'IMG_0365.jpg#IMG_0393.jpg#',92.4,132,'Limoncello','Jasmine, Bella',1,'<p>Introducing \"Limoncello,\" a masterpiece adorned with refreshing lime and opulent golden details, evoking the sunny charm of a Mediterranean summer. Its chain offers two distinct ways to wear:as a chic handbag or a trendy crossbody. A piece of art that adapts to your style and mood. <br>\n<br>\nFeatures: <br>\n<br>\n➺ Luxury &amp; Stain-resistant fabric <br>\n<br>\n➺ Metallic adjustable chain <br>\n<br>\n➺ Satin lining <br>\n<br>\n<br>\nCreation &amp; Delivery: <br>\n<br>\nSavor the anticipation as skilled hands craft your handmade purse, delivered to you within 8-10 working days. <br>\n<br>\n<br>\nMaintenance &amp; Repair: <br>\n<br>\n➺ Store the purse in its dust bag when not in use to maintain its pristine condition <br>\n<br>\n➺ For any repairs or maintenance inquiries, please contact Tierraboutique20@gmail.com</p>',0,''),(76,'Jasmine Dummy product for tests','\r\nIntroducing the \"Jasmine\" purse—timeless elegance and sophistication. Crafted from high-quality jacquard fabric, exuding luxury. Adorned with a metallic clasp and pearl chain for glamour. \r\n\r\n*Coming with a personalised dustbag.\r\n\r\n\r\n\r\n\r\n\r\n','',34,'IMG_1181.jpg#',70,100,'Jasmine','Bella, Limoncello',0,'<p>Introducing the \"Jasmine\" purse, an epitome of timeless elegance and sophistication. Crafted from high-quality jacquard fabric, it exudes luxury with every detail. Adorned with a metallic clasp and a pearl chain, it adds a touch of glamour to any ensemble. Inside, indulge in the plush comfort of the satin lining, ensuring a delightful experience every time you reach for your essentials. Features: ➺ High-quality jacquard fabric ➺ Metallic clasp and pearl chain ➺ Plush satin lining for luxurious comfort Creation &amp; Delivery: Savor the anticipation as skilled hands craft your handmade purse, delivered to you within 8-10 working days. Maintenance &amp; Repair: ➺ Store the purse in its dust bag when not in use to maintain its pristine condition. ➺ For repairs or maintenance inquiries, please contact Tierraboutique20@gmail.com.</p>',0,'Bella'),(91,'Rosalia','Introducing the \"Rosalia\" purse—timeless elegance and sophistication. Crafted from high-quality jacquard fabric, exuding luxury. Adorned with a metallic clasp and beads chain for extra glamour. \n\n*Coming with a personalised dustbag.',NULL,4,'IMG_3377-min.jpeg#new.jpg.jpeg#',66.5,95,'Rosalia','Bella, Jasmine ',1,'<p>Introducing the \"Rpsalia\" purse, an epitome of timeless elegance and sophistication. Crafted from high-quality jacquard fabric, it exudes luxury with every detail. Adorned with a metallic clasp and a beads chain, it adds a touch of glamour to any ensemble. Inside, indulge in the plush comfort of the satin lining, ensuring a delightful experience every time you reach for your essentials.</p>\n<p>Features:</p>\n<p>➺ High-quality jacquard fabric</p>\n<p>➺ Metallic clasp and pearl chain</p>\n<p>➺ Plush satin lining for luxurious comfort<br>\n</p>\n<p>Creation &amp; Delivery:</p>\n<p>Savor the anticipation as skilled hands craft your handmade purse, delivered to you within 8-10 working days.</p>\n<p><br>\nMaintenance &amp; Repair:</p>\n<p>➺ Store the purse in its dust bag when not in use to maintain its pristine condition.</p>\n<p>➺ For repairs or maintenance inquiries, please contact Tierraboutique20@gmail.com.</p>',0,''),(92,'Violetta','Introducing \"Violetta\"—a purse from our limited luxury collection, perfect for special occasions. Crafted from high-quality satin fabric with a metallic clasp and adorned with feathers. Satin lining ensures luxurious comfort. \n\n*Coming with a personalised dustbag.',NULL,3,'IMG_3323_jpg-min.jpeg#',92.4,132,'Violetta','Cinderella, Argenta, Princessa, Kate\'s',1,'<p>Introducing \"Violetta,\" a purse from our limited luxury collection, designed for special occasions where opulence meets elegance. Crafted from high-quality satin fabric, it exudes sophistication and refinement. Adorned with a metallic clasp and delicately embellished with feathers, it adds a touch of luxury and allure to your ensemble. Inside, indulge in the luxurious comfort of the satin lining, ensuring you feel pampered and stylish throughout the event.</p>\n<p>Features:</p>\n<p>➺ High-quality fabric</p>\n<p>➺ Feathers</p>\n<p>➺ Metallic details</p>\n<p>➺ Luxurious satin lining<br>\n</p>\n<p>Creation &amp; Delivery:<br>\n<br>\nSavor the anticipation as skilled hands craft your handmade purse, delivered to you within 8-10 working days.<br>\n</p>\n<p>Maintenance &amp; Repair:</p>\n<p>➺ Store the purse in its dust bag when not in use to maintain its pristine condition</p>\n<p>➺ For any repairs or maintenance inquiries, please contact Tierraboutique20@gmail.com</p>',0,'Princessa, Kate\'s'),(94,'111','111',NULL,0,'.webp#',70,100,'111','',0,'<p></p>',0,''),(95,'1111111','1111',NULL,0,'.webp#',70,100,'111','',0,'<p></p>',0,'');
/*!40000 ALTER TABLE `products` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `products_backup`
--

DROP TABLE IF EXISTS `products_backup`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `products_backup` (
  `productId` int(11) NOT NULL DEFAULT 0,
  `productTitle` varchar(100) NOT NULL,
  `productDescription` text NOT NULL,
  `productSubHeader` varchar(45) DEFAULT NULL,
  `stock` int(11) NOT NULL,
  `imgHref` text DEFAULT NULL,
  `price` double NOT NULL,
  `initialPrice` double NOT NULL,
  `code` varchar(45) NOT NULL,
  `related_products` varchar(45) DEFAULT NULL,
  `isActive` int(11) NOT NULL,
  `productLargeDescription` text NOT NULL,
  `isNew` int(11) NOT NULL DEFAULT 0,
  `colorOptions` text NOT NULL DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `products_backup`
--

LOCK TABLES `products_backup` WRITE;
/*!40000 ALTER TABLE `products_backup` DISABLE KEYS */;
INSERT INTO `products_backup` VALUES (38,'Amarillo','Introducing \"Amarillo\" purse—sophistication meets practicality. Stain-resistant fabric, luxurious satin interior, and secure clasp. \n\n*Coming with a personalised dustbag.\n\n\n\n\n\n','',6,'IMG_0549.jpg#IMG_6950.jpg#',128,128,'Amarillo','Chloe, Vanilla',1,'<p>Introducing the \"Amarillo\" purse from our winter collection—a fusion of sophistication and practicality. Crafted with precision from stain-resistant fabric, effortlessly cleanable with a tissue or sponge. Inside, discover a luxurious satin interior and a meticulously organized vanity, secured by an engraved clasp. Delivered in a branded dustbag and cardboard box for safekeeping. <br>\n<br>\n<br>\nFeatures: <br>\n<br>\n➺ Stain-resistant fabric <br>\n<br>\n➺ Effortless cleanup with just a tissue or sponge <br>\n<br>\n➺ Luxurious satin interior <br>\n<br>\n➺ Securely delivered in a branded dustbag and cardboard box <br>\n<br>\n➺ Crafted from certified Italian fabric <br>\n<br>\n<br>\nCreation &amp; Delivery: <br>\n<br>\nSavor the anticipation as skilled hands craft your handmade purse, delivered to you within 8-10 working days. <br>\n<br>\n<br>\nMaintenance &amp; Repair:<br>\n<br>\n➺ Do not overfill the bag; store it in its dust bag <br>\n<br>\n➺ For repair reach out to Tierraboutique20@gmail.com after sales service.</p>',0,'Chloe'),(39,'Amare','Introducing \"Amare\"—a summer purse with a vibrant boho pattern, metallic handle, and magnetic button closure. Complete with luxurious satin lining for added comfort and style.\n\n*Coming with a personalised dustbag.\n\n\n\n\n\n','',3,'DSC_0022.jpg#IMG_0537.jpg#',128,128,'Amare','Estrella, ElMar, Paloma, Verano',1,'<p>Introducing \"Amare,\" the ultimate summer purse with a vibrant boho pattern, metallic handle, and magnetic button closure. Luxurious satin lining adds comfort and style to your adventures. <br>\n<br>\n<br>\nFeatures: <br>\n<br>\n➺ High quality fabric <br>\n<br>\n➺ Luxurious satin interior <br>\n<br>\n➺ Metallic handle <br>\n<br>\n<br>\nCreation &amp; Delivery: <br>\n<br>\nSavor the anticipation as skilled hands craft your handmade purse, delivered to you within 8-10 working days. <br>\n<br>\n<br>\nMaintenance &amp; Repair: <br>\n<br>\n➺ Do not overfill the bag; store it in its dust bag <br>\n<br>\n➺ For repair reach out to Tierraboutique20@gmail.com after sales service.</p>',0,''),(40,'Chloe','Introducing \"Chloe\" purse—sophistication and practicality combined. Stain-resistant fabric, luxurious satin interior, and secure clasp. \n\n*Coming with a personalised dustbag.\n\n\n','',6,'B2BCB614-8565-4482-9A90-78A51DBEB2D7.jpg#IMG_8965.jpg#',128,128,'Chloe','Amarillo, Vanilla',1,'<p>Introducing the \"Chloe\" purse from our winter collection—a fusion of sophistication and practicality. Crafted with precision from stain-resistant fabric, effortlessly cleanable with a tissue or sponge. Inside, discover a luxurious satin interior and a meticulously organized vanity, secured by an engraved clasp. Delivered in a branded dustbag and cardboard box for safekeeping. *The dustbag comes personalised with the first letter of your name. <br>\n<br>\n<br>\nFeatures: <br>\n<br>\n➺ Stain-resistant fabric <br>\n<br>\n➺ Effortless cleanup with just a tissue or sponge <br>\n<br>\n➺ Luxurious satin interior <br>\n<br>\n➺ Securely delivered in a branded dustbag and cardboard box <br>\n<br>\n➺ Crafted from certified Italian fabric <br>\n<br>\n<br>\nCreation &amp; Delivery: <br>\n<br>\nSavor the anticipation as skilled hands craft your handmade purse, delivered to you within 8-10 working days. <br>\n<br>\n<br>\nMaintenance &amp; Repair: <br>\n<br>\n➺ Do not overfill the bag; store it in its dust bag <br>\n<br>\n➺ For repair reach out to Tierraboutique20@gmail.com after sales service.</p>',0,'Amarillo'),(41,'Vanilla','Introducing the \"Vanilla\" purse—elegance meets versatility. Stain-resistant fabric, luxurious satin interior, and secure zip closure. \n\n*Coming with a personalised dustbag.','',5,'IMG_8383.jpg#',135,135,'Vanilla','Amarillo, Chloy',1,'<p>Introducing \"Vanilla\" purse from our winter collection, where elegance meets versatility. Crafted with finesse from stain-resistant fabric, cleaning becomes a breeze with just a tissue or sponge. Inside, luxuriate in the satin interior, while a thoughtful vanity ensures your belongings stay organized. This essential accessory is secured with an engraved clasp on the flap, complemented by a reliable zip closure for added security. Delivered in a branded dustbag and cardboard box, your purse is meticulously protected. *Personalize your dustbag with the first letter of your name. <br>\n<br>\nFeatures: <br>\n<br>\n➺ Stain-resistant fabric <br>\n<br>\n➺ Effortless cleanup with just a tissue or sponge <br>\n<br>\n➺ Luxurious satin interior <br>\n<br>\n➺ Secure delivery in a branded dustbag and cardboard box <br>\n<br>\n➺ Crafted with care from certified Italian fabric <br>\n<br>\n➺ Reliable zip closure <br>\n<br>\n<br>\nCreation &amp; Delivery: <br>\n<br>\nSavor the anticipation as skilled hands craft your handmade purse, delivered to you within 8-10 working days. <br>\n<br>\n<br>\nMaintenance &amp; Repair: <br>\n<br>\n➺ Ensure optimal care by avoiding overfilling the bag and storing it in its dust bag. <br>\n<br>\n➺ For repairs and maintenance inquiries, reach out to Tierraboutique20@gmail.com.</p>',0,''),(42,'Safari','Introducing the \"#Safari\" purse—adventure meets elegance. Crafted from eco-leather, it balances sustainability with style. Adorned with a metallic chain and clasp for sophistication. \n\n*Coming with a personalised dustbag.\n\n\n\n\n\n\n','',8,'IMG_7762.jpg#IMG_6547.HEIC#',128,128,'Safari','Evelyn, Croco, Elvira',1,'<p>Introducing the \"#Safari\" purse, a symbol of adventure and elegance. Crafted from high-quality eco-leather, this purse embodies sustainability without compromising on style. Adorned with a metallic chain and clasp, it exudes sophistication with a touch of edge. Inside, indulge in the luxurious satin lining, providing both comfort and refinement. *Personalize your dustbag with the first letter of your name. <br>\n<br>\n<br>\nFeatures: <br>\n<br>\n➺ High-quality eco-leather <br>\n<br>\n➺ Metallic chain and clasp <br>\n<br>\n➺ Luxurious satin lining <br>\n<br>\n<br>\nCreation &amp; Delivery: <br>\n<br>\nSavor the anticipation as skilled hands craft your handmade purse, delivered to you within 8-10 working days. <br>\n<br>\n<br>\nMaintenance &amp; Repair: <br>\n<br>\n➺ To maintain its pristine appearance, store the purse in its dust bag when not in use. <br>\n<br>\n➺ For repairs and maintenance inquiries, please contact Tierraboutique20@gmail.com.</p>',0,'Evelyn'),(43,'Evelyn','Introducing the \"Evelyn\" purse—timeless charm. Crafted from jacquard fabric, it exudes elegance. Adorned with a metallic clasp and chain for a touch of glamour. \n\n*Coming with a personalised dustbag.\n\n\n\n\n','',6,'IMG_7024.JPG#',128,128,'Evelyn','Safari, Croco, Elvira',1,'<p>Introducing the \"Evelyn\" purse, a timeless accessory blending sophistication and charm. Crafted from high-quality jacquard fabric, it exudes elegance with every detail. Adorned with a metallic clasp and chain, this purse adds a touch of glamour to any ensemble. Inside, experience luxury with the satin lining, providing both comfort and refinement. *Personalize your dustbag with the first letter of your name. <br>\n<br>\n<br>\nFeatures: <br>\n<br>\n➺ High-quality jacquard fabric <br>\n<br>\n➺ Metallic clasp and chain <br>\n<br>\n➺ Luxurious satin lining <br>\n<br>\n<br>\nCreation &amp; Delivery: <br>\n<br>\nSavor the anticipation as skilled hands craft your handmade purse, delivered to you within 8-10 working days. <br>\n<br>\n<br>\nMaintenance &amp; Repair: <br>\n<br>\n➺ To preserve its pristine appearance, store the purse in its dust bag when not in use. <br>\n<br>\n➺ For repairs and maintenance inquiries, please contact Tierraboutique20@gmail.com.</p>',0,'Safari'),(44,'Elvira','Introducing the \"Elvira\" purse—a glamorous essential. Crafted from high-quality fabric with a metallic clasp and chain for added sophistication. \n\n*Coming with a personalised dustbag.\n\n\n\n\n\n','',7,'IMG_6584.jpg#',92,92,'Elvira','Evelyn, Croco, Safari',1,'<p>Introducing the \"Elvira\" purse, your go-to accessory for glamorous nights out.&nbsp;</p>\n<p>Crafted from high-quality fabric, it exudes luxury and style, complete with a metallic clasp and chain for added sophistication. Inside, enjoy the comfort of the satin lining as you dance the night away. *Personalize your dustbag with the first letter of your name.&nbsp;</p>\n<p><br></p>\n<p>Features:&nbsp;</p>\n<p>➺ High-quality fabric&nbsp;</p>\n<p>➺ Metallic clasp and chain&nbsp;</p>\n<p>➺ Luxurious satin lining&nbsp;</p>\n<p><br></p>\n<p>Creation &amp; Delivery:&nbsp;</p>\n<p>Savor the anticipation as skilled hands craft your handmade purse, delivered to you within 8-10 working days.&nbsp;</p>\n<p><br></p>\n<p>Maintenance &amp; Repair:&nbsp;</p>\n<p>➺ To maintain its allure, store the purse in its dust bag when not in use.&nbsp;</p>\n<p>➺ For repairs and maintenance inquiries, please contact Tierraboutique20@gmail.com.</p>',0,''),(45,'Amelie','Introducing the \"Amelie\" winter purse—sophistication meets functionality. Crafted from high-quality fabric with chic metallic details. Spacious interior with a vanity for organization. Adjustable strap for convenience. \n\n*Coming with a personalised dustbag.\n\n','',5,'IMG_0540.jpg#IMG_3163.jpg#',128,128,'Amelie','Croco, JeannyChoo, Bohemian',1,'<p>Introducing the \"Amelie\" winter purse, a stylish blend of sophistication and functionality. Crafted from high-quality fabric with chic metallic details, it exudes timeless elegance. Inside, revel in the spacious interior featuring a vanity for effortless organization. Complete with an adjustable strap for added convenience. *Personalize your dustbag with the first letter of your name. <br>\n<br>\nFeatures: <br>\n<br>\n➺ High-quality fabric <br>\n<br>\n➺ Metallic details <br>\n<br>\n➺ Spacious interior with vanity <br>\n<br>\n➺ Adjustable strap <br>\n<br>\n➺ Luxurious satin lining <br>\n<br>\n<br>\nCreation &amp; Delivery: <br>\n<br>\nSavor the anticipation as skilled hands craft your handmade purse, delivered to you within 8-10 working days. <br>\n<br>\n<br>\nMaintenance &amp; Repair: <br>\n<br>\n➺ Avoid overfilling the bag; store it in its dust bag <br>\n<br>\n➺ For repairs, contact Tierraboutique20@gmail.com for after-sales service.</p>',0,''),(46,'Croco','.Introducing the \"Croco\" purse—sleek and luxurious. Crafted from high-quality eco-leather with metallic clasp and chain accents for elegance. \n\n*Coming with a personalised dustbag.\n\n\n\n\n\n','',4,'IMG_0526.jpg#',120,120,'Croco','Safari, Evelyn',1,'<p>Introducing the \"Croco\" purse, a sleek and luxurious accessory crafted from high-quality eco-leather. With metallic clasp and chain accents, it exudes elegance. Inside, enjoy the plush comfort of the satin lining. *Personalize your dustbag with the first letter of your name. <br>\n<br>\n<br>\nFeatures: <br>\n<br>\n➺ High-quality eco-leather <br>\n<br>\n➺ Metallic clasp and chain <br>\n<br>\n➺ Plush satin lining <br>\n<br>\n<br>\nCreation &amp; Delivery: <br>\n<br>\nSavor the anticipation as skilled hands craft your handmade purse, delivered to you within 8-10 working days. <br>\n<br>\n<br>\nMaintenance &amp; Repair: <br>\n<br>\n➺ Store the purse in its dust bag when not in use to maintain its pristine condition. <br>\n<br>\n➺ For any repairs or maintenance inquiries, please contact Tierraboutique20@gmail.com</p>',0,''),(47,'Marron','Introducing \"Marron\"—a chic handbag with a metallic chain strap and leopard print pattern. Ideal for day-to-night wear with a detachable vanity.\n\n*Coming with a personalised dustbag.\n\n\n\n\n','',5,'IMG_0579.jpg#IMG_0580.jpg#',128,128,'Marron','Croco, Bohemian, JeannyChoo',1,'<p>Introducing \"Marron\"—a stylish handbag with a metallic chain strap and textured surface. Adorned with a leopard or animal print pattern, it\'s perfect for everyday wear from day to night, with a detachable vanity for added convenience.</p>\n<p><br></p>\n<p>Features:</p>\n<p>➺ High-quality fabric</p>\n<p>➺ Metallic details &amp; chain</p>\n<p>➺ Detachable vanity</p>\n<p>➺ Luxurious satin lining</p>\n<p><br></p>\n<p>Creation &amp; Delivery:</p>\n<p>Savor the anticipation as skilled hands craft your handmade purse, delivered to you within 8-10 working days.</p>\n<p><br></p>\n<p>Maintenance &amp; Repair:</p>\n<p>➺ Store the purse in its dust bag when not in use to preserve its pristine condition.</p>\n<p>➺ For repairs or maintenance inquiries, please contact Tierraboutique20@gmail.com.</p>',0,''),(48,'Naomi','Introducing the \"Naomi\" purse—a captivating blend of sophistication and sparkle. Crafted from high-quality fabric, exuding timeless elegance. Metallic details and an acrylic chain add glamour. \n\n*Coming with a personalised dustbag.\n\n\n\n\n\n\n\n','',6,'DSC_0876.JPG#IMG_0527.jpg#',89,89,'Naomi','Elvira',1,'<p>Introducing the \"Naomi\" purse, a captivating blend of sophistication and sparkle. Crafted from high-quality fabric, it exudes timeless elegance, complemented by metallic details and an acrylic chain that add a touch of glamour. Inside, indulge in the luxurious comfort of the satin lining.</p>\n<p>*Personalize your dustbag with the first letter of your name.</p>\n<p><br></p>\n<p>Features:</p>\n<p>➺ High-quality fabric</p>\n<p>➺ Metallic details and acrylic chain</p>\n<p>➺ Luxurious satin lining</p>\n<p><br></p>\n<p>Creation &amp; Delivery:</p>\n<p>Savor the anticipation as skilled hands craft your handmade purse, delivered to you within 8-10 working days.</p>\n<p><br></p>\n<p>Maintenance &amp; Repair:</p>\n<p>➺ Store the purse in its dust bag when not in use to preserve its pristine condition.</p>\n<p>➺ For repairs or maintenance inquiries, please contact Tierraboutique20@gmail.com.</p>',0,''),(49,'Bohemian','.\n\n\n\nIntroducing the \"Bohemian\" purse—a fusion of style and elegance. Crafted from high-quality velvet fabric for luxurious texture. \n\n*Coming with a personalised dustbag.\n\n\n\n\n','',6,'IMG_0547.jpg#IMG_6522.jpg#',93,93,'Bohemian','Amelie, Marron',1,'<p>Introducing the \"Bohemian\" purse, a fusion of free-spirited style and elegance.&nbsp;</p>\n<p>Crafted from high-quality velvet fabric, it exudes luxurious texture and sophistication. Inside, revel in the comfort of the satin lining, adding a touch of opulence to your ensemble.&nbsp;</p>\n<p>*Personalize your dustbag with the first letter of your name.&nbsp;</p>\n<p><br></p>\n<p>Features:&nbsp;</p>\n<p>➺ High-quality velvet fabric&nbsp;</p>\n<p>➺Luxurious satin lining&nbsp;</p>\n<p><br></p>\n<p>Creation &amp; Delivery:&nbsp;</p>\n<p>Savor the anticipation as skilled hands craft your handmade purse, delivered to you within 8-10 working days.&nbsp;</p>\n<p><br></p>\n<p>Maintenance &amp; Repair:&nbsp;</p>\n<p>➺ Store the purse in its dust bag when not in use to maintain its pristine condition.&nbsp;</p>\n<p>➺ For any repairs or maintenance inquiries, please contact Tierraboutique20@gmail.com</p>',0,''),(50,'JeannyChoo','\r\n\r\n\r\n\r\nIntroducing the \"Jeanny Choo\" purse—a chic and versatile accessory. Crafted from high-quality jean fabric for a casual yet stylish vibe. Detachable vanity offers convenience on the go. \r\n\r\n*Coming with a personalised dustbag.\r\n\r\n\r\n\r\n\r\n','',6,'IMG_6392.jpg#IMG_6393.jpg#',92,92,'JeannyChoo','Amelie, Marron, Bohemian',1,'<p>Introducing the \"Jeanny Choo\" purse, a chic and versatile accessory designed for everyday elegance. Made from high-quality jean fabric, it exudes a casual yet stylish vibe. Complete with a detachable vanity, this purse offers convenience and organization on the go. Inside, indulge in the luxurious comfort of the satin lining.</p>\n<p>*Personalize your dustbag with the first letter of your name.</p>\n<p><br></p>\n<p>Features:</p>\n<p>➺ High-quality jean fabric</p>\n<p>➺ Detachable vanity</p>\n<p>➺ Luxurious satin lining</p>\n<p><br></p>\n<p>Creation &amp; Delivery:</p>\n<p>Savor the anticipation as skilled hands craft your handmade purse, delivered to you within 8-10 working days.</p>\n<p><br></p>\n<p>Maintenance &amp; Repair:</p>\n<p>➺ Store the purse in its dust bag when not in use to maintain its pristine condition.</p>\n<p>➺ For any repairs or maintenance inquiries, please contact Tierraboutique20@gmail.com.</p>',0,''),(51,'Vaqueros','Introducing \"Vaqueros\"—a trendy jean purse with golden details and metallic handles. Featuring a luxurious satin lining for added elegance.\n\n*Coming with a personalised dustbag.\n','',3,'IMG_0536.jpg#',95,95,'Vaqueros','Jeanny Choo',1,'<p>Introducing \"Vaqueros,\" a stylish jean purse with golden details and metallic handles. Featuring a luxurious satin lining for added elegance and comfort. Perfect for adding a touch of glamour to any outfit.&nbsp;</p>\n<p>Features:&nbsp;</p>\n<p>➺ High-quality jean fabric&nbsp;</p>\n<p>➺ Metallic handles&nbsp;</p>\n<p>➺ Luxurious satin lining&nbsp;</p>\n<p><br></p>\n<p>Creation &amp; Delivery:&nbsp;</p>\n<p>Savor the anticipation as skilled hands craft your handmade purse, delivered to you within 8-10 working days.</p>\n<p><br></p>\n<p>Maintenance &amp; Repair:&nbsp;</p>\n<p>➺ Store the purse in its dust bag when not in use to maintain its pristine condition.&nbsp;</p>\n<p>➺ For any repairs or maintenance inquiries, please contact Tierraboutique20@gmail.com.</p>',0,''),(52,'Jasmine','\r\nIntroducing the \"Jasmine\" purse—timeless elegance and sophistication. Crafted from high-quality jacquard fabric, exuding luxury. Adorned with a metallic clasp and pearl chain for glamour. \r\n\r\n*Coming with a personalised dustbag.\r\n\r\n\r\n\r\n\r\n\r\n','',6,'IMG_3232 (1)-min.jpeg#',108,108,'Jasmine','Bella, Limoncello',1,'<p>Introducing the \"Jasmine\" purse, an epitome of timeless elegance and sophistication. Crafted from high-quality jacquard fabric, it exudes luxury with every detail. Adorned with a metallic clasp and a pearl chain, it adds a touch of glamour to any ensemble. Inside, indulge in the plush comfort of the satin lining, ensuring a delightful experience every time you reach for your essentials.</p>\n<p>Features:</p>\n<p>➺ High-quality jacquard fabric</p>\n<p>➺ Metallic clasp and pearl chain</p>\n<p>➺ Plush satin lining for luxurious comfort</p>\n<p><br></p>\n<p>Creation &amp; Delivery:</p>\n<p>Savor the anticipation as skilled hands craft your handmade purse, delivered to you within 8-10 working days.</p>\n<p><br></p>\n<p>Maintenance &amp; Repair:</p>\n<p>➺ Store the purse in its dust bag when not in use to maintain its pristine condition.</p>\n<p>➺ For repairs or maintenance inquiries, please contact Tierraboutique20@gmail.com.</p>',0,'Bella'),(53,'Bella','Introducing the \"Bella\" purse—timeless elegance and sophistication. Crafted from high-quality jacquard fabric, exuding luxury. Adorned with a metallic clasp and pearl chain for glamour. \n\n*Coming with a personalised dustbag.\n','',8,'IMG_1007.jpg#IMG_1269.jpeg#',108,108,'Bella','Jasmine, Limoncello',1,'<p>Introducing the \"Bella\" purse, an epitome of timeless elegance and sophistication. Crafted from high-quality jacquard fabric, it exudes luxury with every detail. Adorned with a metallic clasp and a pearl chain, it adds a touch of glamour to any ensemble. Inside, indulge in the plush comfort of the satin lining, ensuring a delightful experience every time you reach for your essentials.</p>\n<p><br></p>\n<p>Features:</p>\n<p>➺ High-quality jacquard fabric</p>\n<p>➺ Metallic clasp and pearl chain</p>\n<p>➺ Plush satin lining for luxurious comfort</p>\n<p><br></p>\n<p>Creation &amp; Delivery:</p>\n<p>Savor the anticipation as skilled hands craft your handmade purse, delivered to you within 8-10 working days.</p>\n<p><br></p>\n<p>Maintenance &amp; Repair:</p>\n<p>➺ Store the purse in its dust bag when not in use to maintain its pristine condition.</p>\n<p>➺ For repairs or maintenance inquiries, please contact Tierraboutique20@gmail.com.</p>',0,'Jasmine'),(54,'Marine','Introducing the Marine purse, the epitome of summer chic. Crafted from high-quality jean fabric with plush satin lining, making it perfect for leisurely island strolls. \n\n*Coming with a personalised dustbag.\n\n\n\n','',9,'IMG_2398.jpg#IMG_2404.jpg#',52,52,'Marine','Magenta, ElMar, Paloma',1,'<p>Introducing the \"Marine\" purse, the ultimate summer accessory for leisurely island strolls. Crafted from high-quality fabric, it embodies the relaxed elegance of coastal living. The plush satin lining ensures comfort while adding a touch of luxury to your seaside adventures.</p>\n<p>Features:</p>\n<p>➺High-quality fabric</p>\n<p>➺Luxurious satin lining</p>\n<p>➺Perfect for island strolls and summer adventures</p>\n<p><br></p>\n<p>Creation &amp; Delivery:</p>\n<p>Savor the anticipation as skilled hands craft your handmade purse, delivered to you within 8-10 working days.</p>\n<p><br></p>\n<p>Maintenance &amp; Repair:</p>\n<p>➺Store the purse in its dust bag when not in use to maintain its pristine condition.</p>\n<p>➺For repairs or maintenance inquiries, please contact Tierraboutique20@gmail.com</p>',0,'Magenta'),(55,'Magenta','Introducing the \"Magenta\" purse—the epitome of summer chic. Crafted from high-quality leopard fabric with plush satin lining, making it perfect for leisurely island strolls. \n. \n\n*Coming with a personalised dustbag.\n\n\n\n\n\n\n','',9,'03C8C3F7-DE1C-41D6-AE65-3F8B717A56E0.JPEG#IMG_1962.jpg#',52,52,'Magenta','Marine, ElMar, Paloma',1,'<p>Introducing the \"Magenta\" purse, the ultimate summer accessory for leisurely island strolls.&nbsp;</p>\n<p>Crafted from high-quality fabric, it embodies the relaxed elegance of coastal living. The plush satin lining ensures comfort while adding a touch of luxury to your seaside adventures.&nbsp;</p>\n<p>Features:&nbsp;</p>\n<p>➺ High-quality fabric&nbsp;</p>\n<p>➺ Luxurious satin lining&nbsp;</p>\n<p>➺ Perfect for island strolls and summer adventures&nbsp;</p>\n<p><br></p>\n<p>Creation &amp; Delivery:&nbsp;</p>\n<p>Savor the anticipation as skilled hands craft your handmade purse, delivered to you within 8-10 working days.&nbsp;</p>\n<p><br></p>\n<p>Maintenance &amp; Repair:&nbsp;</p>\n<p>➺ Store the purse in its dust bag when not in use to maintain its pristine condition.&nbsp;</p>\n<p>➺ For repairs or maintenance inquiries, please contact Tierraboutique20@gmail.com</p>',0,'Marine'),(56,'Paloma','Introducing the \"Paloma\" purse—your go-to boho-chic accessory for summer. Featuring a vibrant bohemian pattern with red and gold details, and a detachable strap for versatile styling. Luxurious satin lining ensures comfort, making it perfect for leisurely island strolls. \n\n*Coming with a personalised dustbag.\n\n\n\n\n\n\n','',6,'IMG_0534.jpg#',98,98,'Paloma','ElMar, Marine, Magenta',1,'<p>Introducing the \"Paloma\" purse, your quintessential summer accessory with a boho twist. Crafted from high-quality fabric adorned with a vibrant bohemian pattern, it captures the essence of carefree island strolls. Accentuated with striking red and gold details and featuring a detachable strap for versatile styling. Inside, indulge in the luxurious comfort of the satin lining.</p>\n<p><br></p>\n<p>Features:</p>\n<p>➺High-quality fabric in striking red hue</p>\n<p>➺ Metallic details</p>\n<p>➺ Luxurious satin lining</p>\n<p><br></p>\n<p>Creation &amp; Delivery:</p>\n<p>Savor the anticipation as skilled hands craft your handmade purse, delivered to you within 8-10 working days.</p>\n<p><br></p>\n<p>Maintenance &amp; Repair:</p>\n<p>➺ Store the purse in its dust bag when not in use to maintain its pristine condition</p>\n<p>➺ For any repairs or maintenance inquiries, please contact Tierraboutique20@gmail.com</p>',0,'ElMar'),(57,'Bianca','Introducing the \"Bianca\" purse—your go-to accessory for sunny days. Cream color with golden details, featuring metallic accents and a detachable strap for versatility. Luxurious satin lining ensures comfort, making it perfect for stylish strolls in town.\n\n*Coming with a personalised dustbag.\n\n\n\n\n\n','',7,'IMG_0546.jpg#',98,98,'Bianca','Limoncello, Vanilla',1,'<p>Introducing the \"Bianca\" purse—an ideal companion for sunny days, perfect for everyday occasions and stylish strolls in town. Crafted from high-quality fabric in a cream color with golden details. Complete with metallic details and a detachable strap for versatile styling. Inside, indulge in the luxurious comfort of the satin lining.<br>\n</p>\n<p>Features:</p>\n<p>➺High-quality</p>\n<p>➺ Detachable strap</p>\n<p>➺ Metallic details</p>\n<p>➺ Luxurious satin lining</p>\n<p><br></p>\n<p>Creation &amp; Delivery:</p>\n<p>Savor the anticipation as skilled hands craft your handmade purse, delivered to you within 8-10 working days.</p>\n<p><br></p>\n<p>Maintenance &amp; Repair:</p>\n<p>➺ Store the purse in its dust bag when not in use to maintain its pristine condition</p>\n<p>➺ For any repairs or maintenance inquiries, please contact Tierraboutique20@gmail.com</p>',0,''),(58,'Verano','Introducing \"Verano\"—the epitome of summer chic. Crafted from straw with shinning stones and golden details, featuring metallic accents and beads. With luxurious satin lining. \n\n*Coming with a personalised dustbag.','',5,'IMG_0533.jpg#',132,132,'Verano','Estrella, ElMar, Paloma',1,'<p>Introducing \"Verano,\" the ultimate summer purse radiating with elegance and charm. Crafted from straw with shinning stones and golden details, it embodies the essence of summertime luxury. Its metallic details and beads add a touch of sophistication, while the satin lining ensures comfort. Complete with a stylish handle, this purse is your perfect companion for sunny days and warm evenings.<br>\n</p>\n<p>Features:</p>\n<p>➺High-quality</p>\n<p>➺ Handle</p>\n<p>➺ Metallic details</p>\n<p>➺ Luxurious satin lining</p>\n<p><br></p>\n<p>Creation &amp; Delivery:</p>\n<p>Savor the anticipation as skilled hands craft your handmade purse, delivered to you within 8-10 working days.</p>\n<p><br></p>\n<p>Maintenance &amp; Repair:</p>\n<p>➺ Store the purse in its dust bag when not in use to maintain its pristine condition</p>\n<p>➺ For any repairs or maintenance inquiries, please contact Tierraboutique20@gmail.com</p>',0,'Estrella'),(59,'Selva','Introducing the \"Selva\" purse—your tropical getaway essential. Crafted from straw with metallic details and a vibrant green acrylic chain. Satin lining ensures comfort. Perfect for adding a playful touch to your summer ensemble.\n\n\n*Coming with a personalised dustbag.\n\n\n\n','',1,'IMG_0535.jpg#IMG_0538.jpg#',132,132,'Selva','Verano, Estrella',1,'<p>Introducing the \"Selva\" purse—a summer essential that exudes tropical charm. Crafted from straw with metallic details, it captures the essence of a lush jungle retreat. Adorned with a vibrant green acrylic chain for a pop of color, it adds a playful touch to your ensemble. Inside, indulge in the luxurious comfort of the satin lining, ensuring both style and relaxation during sunny summer days.</p>\n<p><br>\nFeatures:</p>\n<p>➺High-quality straw composition</p>\n<p>➺ Acrylic handles</p>\n<p>➺ Luxurious satin lining</p>\n<p><br></p>\n<p>Creation &amp; Delivery:</p>\n<p>Savor the anticipation as skilled hands craft your handmade purse, delivered to you within 8-10 working days.</p>\n<p><br></p>\n<p>Maintenance &amp; Repair:</p>\n<p>➺ Store the purse in its dust bag when not in use to maintain its pristine condition</p>\n<p>➺ For any repairs or maintenance inquiries, please contact Tierraboutique20@gmail.com</p>',0,''),(60,'Estrella','Introducing \"Estrella\"—the epitome of summer chic. Crafted from straw with shinning, golden details. With luxurious satin lining and metallic handle. \n\n*Coming with a personalised dustbag.','',7,'IMG_0539.jpg#IMG_0545.jpg#',132,132,'Estrella','Verano, Selva, Paloma, ElMar',1,'<p>Introducing \"Estrella,\" the ultimate summer purse radiating with elegance and charm. Crafted from straw with shinning, golden details, it embodies the essence of summertime luxury. Its metallic touches add a touch of sophistication, while the satin lining ensures comfort. Complete with a stylish handle, this purse is your perfect companion for sunny days and warm evenings. <br>\n<br>\n<br>\nFeatures: <br>\n<br>\n➺High-quality <br>\n<br>\n➺ Merallic handle <br>\n<br>\n➺ Metallic details <br>\n<br>\n➺ Luxurious satin lining <br>\n<br>\n<br>\nCreation &amp; Delivery: <br>\n<br>\nSavor the anticipation as skilled hands craft your handmade purse, delivered to you within 8-10 working days. <br>\n<br>\n<br>\nMaintenance &amp; Repair: <br>\n<br>\n➺ Store the purse in its dust bag when not in use to maintain its pristine condition <br>\n<br>\n➺ For any repairs or maintenance inquiries, please contact Tierraboutique20@gmail.com</p>',0,'Verano'),(61,'El Mar','Introducing the \"El Mar\" purse—your go-to boho-chic accessory for summer. Featuring a vibrant bohemian pattern with blue and gold details, and a detachable strap for versatile styling. Luxurious satin lining ensures comfort, making it perfect for leisurely island strolls. \n\n*Coming with a personalised dustbag.\n\n\n\n\n\n\n','',2,'IMG_0543.jpg#IMG_0548.jpg#',98,98,'ElMar','Paloma, Verano, Estrella, Selva',1,'<p>Introducing the \"El Mar\" purse, your quintessential summer accessory with a boho twist. Crafted from high-quality fabric adorned with a vibrant bohemian pattern, it captures the essence of carefree island strolls. Accentuated with striking blue and gold details and featuring a detachable strap for versatile styling. Inside, indulge in the luxurious comfort of the satin lining.</p>\n<p>Features:</p>\n<p>➺High-quality fabric in striking blue hue</p>\n<p>➺ Metallic details</p>\n<p>➺ Luxurious satin lining</p>\n<p><br></p>\n<p>Creation &amp; Delivery:</p>\n<p>Savor the anticipation as skilled hands craft your handmade purse, delivered to you within 8-10 working days.</p>\n<p><br></p>\n<p>Maintenance &amp; Repair:</p>\n<p>➺ Store the purse in its dust bag when not in use to maintain its pristine condition</p>\n<p>➺ For any repairs or maintenance inquiries, please contact Tierraboutique20@gmail.com</p>',0,'Paloma'),(62,'Diamante (silver)','Introducing \"Diamante\"—a purse from our limited luxury collection, perfect for special occasions. Crafted from high-quality satin fabric with a metallic clasp and Swarovski-type rhinestones. Satin lining ensures luxurious comfort.\n\n*Coming with a personalised dustbag.\n\n\n\n\n','',8,'IMG_0541.jpg#',128,128,'DiamanteSilver','DiamanteBlack, Cinderella, Argenta, Princessa',1,'<p>Introducing \"Diamante,\" a purse from our limited luxury collection, designed for special occasions where elegance reigns supreme. Crafted from high-quality satin fabric, it exudes sophistication and refinement. Adorned with a metallic clasp and Swarovski-type rhinestones, it adds a touch of sparkle and glamour to your ensemble. Inside, indulge in the luxurious comfort of the satin lining, ensuring you feel pampered and stylish throughout the event.<br>\n</p>\n<p>Features:</p>\n<p>➺ High-quality fabric</p>\n<p>➺ Swarovski-type rhinestones</p>\n<p>➺ Metallic details</p>\n<p>➺ Luxurious satin lining</p>\n<p><br></p>\n<p>Creation &amp; Delivery:</p>\n<p>Savor the anticipation as skilled hands craft your handmade purse, delivered to you within 8-10 working days.</p>\n<p><br></p>\n<p>Maintenance &amp; Repair:</p>\n<p>➺ Store the purse in its dust bag when not in use to maintain its pristine condition</p>\n<p>➺ For any repairs or maintenance inquiries, please contact Tierraboutique20@gmail.com</p>',0,'DiamanteBlack'),(63,'Diamante (black)','Introducing \"Diamante\"—a purse from our limited luxury collection, perfect for special occasions. Crafted from high-quality satin fabric with a metallic clasp and Swarovski-type rhinestones. Satin lining ensures luxurious comfort.\n\n*Coming with a personalised dustbag.\n\n','',8,'IMG_0542.jpg#IMG_7763.jpg#',128,128,'DiamanteBlack','DiamanteSilver, Cinderella, Argenta, Princess',1,'<p>Introducing \"Diamante,\" a purse from our limited luxury collection, designed for special occasions where elegance reigns supreme. Crafted from high-quality satin fabric, it exudes sophistication and refinement. Adorned with a metallic clasp and Swarovski-type rhinestones, it adds a touch of sparkle and glamour to your ensemble. Inside, indulge in the luxurious comfort of the satin lining, ensuring you feel pampered and stylish throughout the event. &nbsp;<br>\n<br>\n<br>\nFeatures:<br>\n<br>\n➺ High-quality fabric &nbsp;<br>\n<br>\n➺ Swarovski-type rhinestones<br>\n<br>\n➺ Metallic details &nbsp;<br>\n<br>\n➺ Luxurious satin lining &nbsp;&nbsp;<br>\n<br>\n<br>\nCreation &amp; Delivery:<br>\n<br>\nSavor the anticipation as skilled hands craft your handmade purse, delivered to you within 8-10 working days. &nbsp;<br>\n<br>\n<br>\n<br>\nMaintenance &amp; Repair:<br>\n<br>\n➺ Store the purse in its dust bag when not in use to maintain its pristine condition<br>\n<br>\n➺ For any repairs or maintenance inquiries, please contact Tierraboutique20@gmail.com<br>\n&nbsp;</p>',0,'DiamanteSilver'),(64,'Oceano','Introducing \"Oceano\"—a purse from our limited luxury collection, perfect for special occasions. Crafted from high-quality satin fabric with a metallic clasp and adorned with goose\'s feathers. Satin lining ensures luxurious comfort.\n\n*Coming with a personalised dustbag.\n\n\n\n','',8,'#C958CA8C-BE1C-4312-B999-879059BB3247.webp#',132,132,'Oceano','Cinderella, Argenta, Princessa, Violeta',1,'<p>Introducing \"Oceano,\" a purse from our limited luxury collection, designed for special occasions where opulence meets elegance. Crafted from high-quality satin fabric, it exudes sophistication and refinement. Adorned with a metallic clasp and delicately embellished with goose\'s feathers, it adds a touch of luxury and allure to your ensemble. Inside, indulge in the luxurious comfort of the satin lining, ensuring you feel pampered and stylish throughout the event.</p>\n<p><br>\nFeatures:</p>\n<p>➺ High-quality fabric</p>\n<p>➺ Goose\'s feathers</p>\n<p>➺ Metallic details</p>\n<p>➺ Luxurious satin lining</p>\n<p><br></p>\n<p>Creation &amp; Delivery:</p>\n<p>Savor the anticipation as skilled hands craft your handmade purse, delivered to you within 8-10 working days.</p>\n<p><br></p>\n<p>Maintenance &amp; Repair:</p>\n<p>➺ Store the purse in its dust bag when not in use to maintain its pristine condition</p>\n<p>➺ For any repairs or maintenance inquiries, please contact Tierraboutique20@gmail.com</p>',0,'Princessa, Violeta'),(65,'Princessa','Introducing \"Princessa\"—a purse from our limited luxury collection, perfect for special occasions. Crafted from high-quality satin fabric with a metallic clasp and adorned with feathers. Satin lining ensures luxurious comfort.\n\n*Coming with a personalised dustbag.','',9,'princessa1.jpg#princessa2.jpg#',132,132,'Princessa','Cinderella, Argenta, Kates',1,'<p>Introducing \"Princessa,\" a purse from our limited luxury collection, designed for special occasions where opulence meets elegance. Crafted from high-quality satin fabric, it exudes sophistication and refinement. Adorned with a metallic clasp and delicately embellished with feathers, it adds a touch of luxury and allure to your ensemble.<br>\nInside, indulge in the luxurious comfort of the satin lining, ensuring you feel pampered and stylish throughout the event.</p>\n<p><br>\nFeatures:</p>\n<p>➺ High-quality fabric</p>\n<p>➺ Feathers</p>\n<p>➺ Metallic details</p>\n<p>➺ Luxurious satin lining<br>\n<br>\n<br>\nCreation &amp; Delivery:<br>\n<br>\nSavor the anticipation as skilled hands craft your handmade purse, delivered to you within 8-10 working days.<br>\n&nbsp;</p>\n<p>Maintenance &amp; Repair:</p>\n<p>➺ Store the purse in its dust bag when not in use to maintain its pristine condition</p>\n<p>➺ For any repairs or maintenance inquiries, please contact Tierraboutique20@gmail.com</p>',0,'Kates'),(66,'Argenta','Introducing \"Argenta\"—a dazzling purse adorned with shimmering sequins for ultimate glamour. Featuring a metallic clasp and satin lining for added elegance and comfort.\n\n*Coming with a personalised dustbag.\n','',4,'IMG_0532.jpg#',132,132,'Argenta','DiamanteBlack, DiamanteSilver, Cinderella',1,'<p>Introducing \"Argenta,\" a dazzling purse that epitomizes glamour and sophistication. This exquisite piece is adorned with shimmering sequins that catch and reflect the light, ensuring you sparkle and shine at every special occasion. Complete with a metallic clasp for added elegance and a satin lining for luxurious comfort, the \"Argenta\" purse is the perfect accessory to elevate your ensemble. <br>\n<br>\nFeatures: <br>\n<br>\n➺ High-quality sequin fabric <br>\n<br>\n➺ Metallic details <br>\n<br>\n➺ Luxurious satin lining <br>\n<br>\n<br>\nCreation &amp; Delivery: <br>\n<br>\nSavor the anticipation as skilled hands craft your handmade purse, delivered to you within 8-10 working days. <br>\n<br>\n<br>\nMaintenance &amp; Repair: <br>\n<br>\n➺ Store the purse in its dust bag when not in use to maintain its pristine condition <br>\n<br>\n➺ For any repairs or maintenance inquiries, please contact Tierraboutique20@gmail.com</p>',0,'Cinderella, Aurelia'),(67,'Cinderella','Introducing \"Cinderella\"—a dazzling purse adorned with shimmering sequins for ultimate glamour. Featuring a metallic clasp and satin lining for added elegance and comfort.\n\n*Coming with a personalised dustbag.\n','',5,'DSC_0817.JPG#IMG_0525.jpg#',132,132,'Cinderella','DiamanteBlack, DiamanteSilver, Argenta',1,'<p>Introducing \"Cinderella,\" a dazzling purse that epitomizes glamour and sophistication. This exquisite piece is adorned with shimmering sequins that catch and reflect the light, ensuring you sparkle and shine at every special occasion. Complete with a metallic clasp for added elegance and a satin lining for luxurious comfort, the \"Argenta\" purse is the perfect accessory to elevate your ensemble. <br>\n<br>\n<br>\nFeatures: <br>\n<br>\n➺ High-quality sequin fabric <br>\n<br>\n➺ Metallic details <br>\n<br>\n➺ Luxurious satin lining <br>\n<br>\n<br>\nCreation &amp; Delivery: <br>\n<br>\nSavor the anticipation as skilled hands craft your handmade purse, delivered to you within 8-10 working days. <br>\n<br>\n<br>\nMaintenance &amp; Repair: <br>\n<br>\n➺ Store the purse in its dust bag when not in use to maintain its pristine condition <br>\n<br>\n➺ For any repairs or maintenance inquiries, please contact Tierraboutique20@gmail.com</p>',0,'Aurelia, Argenta'),(68,'Aurelia','Introducing \"Aurelia\"—a dazzling purse adorned with shimmering sequins for ultimate glamour. Featuring a metallic clasp and satin lining for added elegance and comfort.\n\n*Coming with a personalised dustbag.\n','',1,'IMG_0528.jpg#',145,145,'Aurelia','DiamanteBlack, DiamanteSilver, Cinderella, Ar',1,'<p>Introducing \"Aurelia,\" a dazzling purse that epitomizes glamour and sophistication. This exquisite piece is adorned with shimmering sequins that catch and reflect the light, ensuring you sparkle and shine at every special occasion. Complete with a metallic clasp for added elegance and a satin lining for luxurious comfort, the \"Argenta\" purse is the perfect accessory to elevate your ensemble. <br>\n<br>\nFeatures: <br>\n<br>\n➺ High-quality sequin fabric <br>\n<br>\n➺ Metallic details <br>\n<br>\n➺ Luxurious satin lining <br>\n<br>\n<br>\nCreation &amp; Delivery: <br>\n<br>\nSavor the anticipation as skilled hands craft your handmade purse, delivered to you within 8-10 working days. <br>\n<br>\n<br>\nMaintenance &amp; Repair: <br>\n<br>\n➺ Store the purse in its dust bag when not in use to maintain its pristine condition <br>\n<br>\n➺ For any repairs or maintenance inquiries, please contact Tierraboutique20@gmail.com</p>',0,'Cinderella, Argenta'),(69,'Morocco','Introducing the \"Morocco\" purse—a luxurious addition to our collection crafted from stain-resistant and excellent quality fabric. Easy to clean with just a tissue or sponge, featuring bamboo handles and lined with luxurious satin.\n\n*Coming with a personalised dustbag.\n\n\n\n\n\n\n','',7,'IMG_1898.jpg#',112,112,'Morocco','Sienna, AfricaBlack, AfricaWhite',1,'<p>Introducing the \"Morocco\" purse, a luxurious addition to our collection crafted from stain-resistant and excellent quality fabric. This purse is designed to combine practicality with elegance, featuring a sleek design that\'s easy to clean with just a tissue or sponge. Complete with bamboo handles for a touch of natural sophistication and lined with luxurious satin, the \"Morocco\" purse is the perfect accessory for any occasion.</p>\n<p><br>\nFeatures:</p>\n<p>➺ Luxury fabric</p>\n<p>➺ Magnetic button</p>\n<p>➺ Bamboo handles</p>\n<p>➺ Satin lining</p>\n<p><br></p>\n<p>Creation &amp; Delivery:</p>\n<p>Savor the anticipation as skilled hands craft your handmade purse, delivered to you within 8-10 working days.</p>\n<p><br></p>\n<p>Maintenance &amp; Repair:</p>\n<p>➺ Store the purse in its dust bag when not in use to maintain its pristine condition</p>\n<p>➺ For any repairs or maintenance inquiries, please contact Tierraboutique20@gmail.</p>',0,'Morocco'),(70,'Cheryl','Introducing the \"Cheryl\" purse—a luxurious statement piece crafted from stain-resistant HERMES® fabric. Easy to clean with just a tissue or sponge, featuring a zipper closure, magnetic buttons, and lined with luxurious satin.\n\n*Coming with a personalised dustbag.\n','',7,'IMG_2535.JPG#',125,125,'Cheryl','Pistachio',1,'<p>Introducing the \"Cheryl\" purse, a luxurious statement piece crafted from stain-resistant HERMES® fabric. This exquisite purse combines practicality with elegance, boasting a sleek design that\'s easy to clean with just a tissue or sponge. Complete with a zipper closure for security and metallic buttons for added flair, the \"Cheryl\" purse is lined with luxurious satin, offering both style and sophistication.<br>\n<br>\n</p>\n<p>Features:<br>\n<br>\n➺ Luxury HERMES® fabric<br>\n<br>\n➺ Magnetic buttons<br>\n<br>\n➺ Zipper<br>\n<br>\n➺ Satin lining<br>\n<br>\n<br>\nCreation &amp; Delivery:<br>\n<br>\nSavor the anticipation as skilled hands craft your handmade purse, delivered to you within 8-10 working days.<br>\n<br>\n<br>\nMaintenance &amp; Repair:<br>\n<br>\n➺ Store the purse in its dust bag when not in use to maintain its pristine condition<br>\n<br>\n➺ For any repairs or maintenance inquiries, please contact Tierraboutique20@gmail.</p>',0,'Pistachio'),(71,'Pistachio','Introducing the \"Pistachio\" purse—a luxurious statement piece crafted from stain-resistant HERMES® fabric. Easy to clean with just a tissue or sponge, featuring a zipper closure, magnetic buttons, and lined with luxurious satin.\n\n*Coming with a personalised dustbag.\n','',7,'IMG_2542.JPG#',125,125,'Pistachio','Cheryl',1,'<p>Introducing the \"Pistachio\" purse, a luxurious statement piece crafted from stain-resistant HERMES® fabric. This exquisite purse combines practicality with elegance, boasting a sleek design that\'s easy to clean with just a tissue or sponge. Complete with a zipper closure for security and metallic buttons for added flair, the \"Cheryl\" purse is lined with luxurious satin, offering both style and sophistication.</p>\n<p><br>\nFeatures:</p>\n<p>➺ Luxury HERMES® fabric</p>\n<p>➺ Magnetic buttons</p>\n<p>➺ Zipper</p>\n<p>➺ Satin lining</p>\n<p><br></p>\n<p>Creation &amp; Delivery:</p>\n<p>Savor the anticipation as skilled hands craft your handmade purse, delivered to you within 8-10 working days.</p>\n<p><br></p>\n<p>Maintenance &amp; Repair:</p>\n<p>➺ Store the purse in its dust bag when not in use to maintain its pristine condition</p>\n<p>➺ For any repairs or maintenance inquiries, please contact Tierraboutique20@gmail.</p>',0,'Cheryl'),(72,'Africa (black)','Introducing \"Africa\"—a luxurious summer purse crafted from FENDI® fabric, adorned with intricate velvet details. Stain-resistant and easy to clean, featuring a metallic button and sumptuous satin lining.\n\n*Coming with a personalised dustbag.\n','',6,'IMG_3173.jpg#IMG_2598.jpg#IMG_3217.jpg#',128,128,'AfricaBlack','AfricaWhite, Morocco, Sienna',1,'<p>Introducing \"Africa,\" where elegance meets adventure. Crafted from luxurious FENDI® fabric, this summer purse is adorned with intricate velvet details, making it a stylish companion for your summer adventures. Stain-resistant and easy to clean, with a metallic button and sumptuous satin lining. <br>\n<br>\nFeatures: <br>\n<br>\n➺ Luxury FENDI® fabric <br>\n<br>\n➺ Magnetic button <br>\n<br>\n➺ Satin lining <br>\n<br>\n<br>\nCreation &amp; Delivery: <br>\n<br>\nSavor the anticipation as skilled hands craft your handmade purse, delivered to you within 8-10 working days. <br>\n<br>\n<br>\nMaintenance &amp; Repair: <br>\n<br>\n➺ Store the purse in its dust bag when not in use to maintain its pristine condition <br>\n<br>\n➺ For any repairs or maintenance inquiries, please contact Tierraboutique20@gmail</p>',0,'AfriceWhite'),(73,'Africa (white)','Introducing \"Africa\"—a luxurious summer purse crafted from FENDI® fabric, adorned with intricate velvet details. Stain-resistant and easy to clean, featuring a metallic button and sumptuous satin lining.\n\n*Coming with a personalised dustbag.\n','',6,'IMG_3117.jpg#IMG_2598.jpg#IMG_3414.jpg#',128,128,'AfricaWhite','AfricaBlack, Sienna, Morocco',1,'<p>Introducing \"Africa,\" where elegance meets adventure. Crafted from luxurious FENDI® fabric, this summer purse is adorned with intricate velvet details, making it a stylish companion for your summer adventures. Stain-resistant and easy to clean, with a metallic button and sumptuous satin lining. <br>\n<br>\nFeatures: <br>\n<br>\n➺ Luxury FENDI® fabric <br>\n<br>\n➺ Magnetic button <br>\n<br>\n➺ Satin lining <br>\n<br>\n<br>\nCreation &amp; Delivery: <br>\n<br>\nSavor the anticipation as skilled hands craft your handmade purse, delivered to you within 8-10 working days. <br>\n<br>\n<br>\nMaintenance &amp; Repair: <br>\n<br>\n➺ Store the purse in its dust bag when not in use to maintain its pristine condition <br>\n<br>\n➺ For any repairs or maintenance inquiries, please contact Tierraboutique20@gmail</p>',0,'AfricaBlack'),(74,'Sienna','Introducing the \"Sienna\" purse—crafted with luxury fabric, stain-resistant and easy to clean. Adorned with metallic details and a button, complemented by a satin lining for added elegance.\n\n*Coming with a personalised dustbag.\n','',6,'IMG_3135.jpg#',128,128,'Sienna','AfricaBlack, AfricaWhite, Morocco',1,'<p>Introducing the \"Sienna\" purse—a stylish companion for your summer adventures. Crafted from stain-resistant fabric, it\'s perfect for days spent under the sun. Complete with metallic details and a button, paired with a luxurious satin lining for effortless elegance.<br>\n</p>\n<p>Features:</p>\n<p>➺ Luxury &amp; stain-resistant fabric</p>\n<p>➺ Magnetic button</p>\n<p>➺ Metallic handle</p>\n<p>➺ Satin lining</p>\n<p><br></p>\n<p>Creation &amp; Delivery:</p>\n<p>Savor the anticipation as skilled hands craft your handmade purse, delivered to you within 8-10 working days.</p>\n<p><br></p>\n<p>Maintenance &amp; Repair:</p>\n<p>➺ Store the purse in its dust bag when not in use to maintain its pristine condition</p>\n<p>➺ For any repairs or maintenance inquiries, please contact Tierraboutique20@gmail</p>',0,''),(75,'Limoncello','Introducing \"Limoncello\"—a state-of-the-art little purse with lime and golden details, featuring a versatile chain for two different ways to wear.\n\n*Coming with a personalised dustbag.\n','',8,'IMG_0365.jpg#IMG_0393.jpg#',132,132,'Limoncello','Jasmine, Bella',1,'<p>Introducing \"Limoncello,\" a masterpiece adorned with refreshing lime and opulent golden details, evoking the sunny charm of a Mediterranean summer. Its chain offers two distinct ways to wear:as a chic handbag or a trendy crossbody. A piece of art that adapts to your style and mood. <br>\n<br>\nFeatures: <br>\n<br>\n➺ Luxury &amp; Stain-resistant fabric <br>\n<br>\n➺ Metallic adjustable chain <br>\n<br>\n➺ Satin lining <br>\n<br>\n<br>\nCreation &amp; Delivery: <br>\n<br>\nSavor the anticipation as skilled hands craft your handmade purse, delivered to you within 8-10 working days. <br>\n<br>\n<br>\nMaintenance &amp; Repair: <br>\n<br>\n➺ Store the purse in its dust bag when not in use to maintain its pristine condition <br>\n<br>\n➺ For any repairs or maintenance inquiries, please contact Tierraboutique20@gmail.com</p>',0,''),(76,'Jasmine Dummy product for tests','\r\nIntroducing the \"Jasmine\" purse—timeless elegance and sophistication. Crafted from high-quality jacquard fabric, exuding luxury. Adorned with a metallic clasp and pearl chain for glamour. \r\n\r\n*Coming with a personalised dustbag.\r\n\r\n\r\n\r\n\r\n\r\n','',34,'IMG_1181.jpg#',100,100,'Jasmine','Bella, Limoncello',0,'<p>Introducing the \"Jasmine\" purse, an epitome of timeless elegance and sophistication. Crafted from high-quality jacquard fabric, it exudes luxury with every detail. Adorned with a metallic clasp and a pearl chain, it adds a touch of glamour to any ensemble. Inside, indulge in the plush comfort of the satin lining, ensuring a delightful experience every time you reach for your essentials. Features: ➺ High-quality jacquard fabric ➺ Metallic clasp and pearl chain ➺ Plush satin lining for luxurious comfort Creation &amp; Delivery: Savor the anticipation as skilled hands craft your handmade purse, delivered to you within 8-10 working days. Maintenance &amp; Repair: ➺ Store the purse in its dust bag when not in use to maintain its pristine condition. ➺ For repairs or maintenance inquiries, please contact Tierraboutique20@gmail.com.</p>',0,'Bella'),(91,'Rosalia','Introducing the \"Rosalia\" purse—timeless elegance and sophistication. Crafted from high-quality jacquard fabric, exuding luxury. Adorned with a metallic clasp and beads chain for extra glamour. \n\n*Coming with a personalised dustbag.',NULL,4,'IMG_3377-min.jpeg#new.jpg.jpeg#',95,95,'Rosalia','Bella, Jasmine ',1,'<p>Introducing the \"Rpsalia\" purse, an epitome of timeless elegance and sophistication. Crafted from high-quality jacquard fabric, it exudes luxury with every detail. Adorned with a metallic clasp and a beads chain, it adds a touch of glamour to any ensemble. Inside, indulge in the plush comfort of the satin lining, ensuring a delightful experience every time you reach for your essentials.</p>\n<p>Features:</p>\n<p>➺ High-quality jacquard fabric</p>\n<p>➺ Metallic clasp and pearl chain</p>\n<p>➺ Plush satin lining for luxurious comfort<br>\n</p>\n<p>Creation &amp; Delivery:</p>\n<p>Savor the anticipation as skilled hands craft your handmade purse, delivered to you within 8-10 working days.</p>\n<p><br>\nMaintenance &amp; Repair:</p>\n<p>➺ Store the purse in its dust bag when not in use to maintain its pristine condition.</p>\n<p>➺ For repairs or maintenance inquiries, please contact Tierraboutique20@gmail.com.</p>',0,''),(92,'Violetta','Introducing \"Violetta\"—a purse from our limited luxury collection, perfect for special occasions. Crafted from high-quality satin fabric with a metallic clasp and adorned with feathers. Satin lining ensures luxurious comfort. \n\n*Coming with a personalised dustbag.',NULL,3,'IMG_3323_jpg-min.jpeg#',132,132,'Violetta','Cinderella, Argenta, Princessa, Kate\'s',1,'<p>Introducing \"Violetta,\" a purse from our limited luxury collection, designed for special occasions where opulence meets elegance. Crafted from high-quality satin fabric, it exudes sophistication and refinement. Adorned with a metallic clasp and delicately embellished with feathers, it adds a touch of luxury and allure to your ensemble. Inside, indulge in the luxurious comfort of the satin lining, ensuring you feel pampered and stylish throughout the event.</p>\n<p>Features:</p>\n<p>➺ High-quality fabric</p>\n<p>➺ Feathers</p>\n<p>➺ Metallic details</p>\n<p>➺ Luxurious satin lining<br>\n</p>\n<p>Creation &amp; Delivery:<br>\n<br>\nSavor the anticipation as skilled hands craft your handmade purse, delivered to you within 8-10 working days.<br>\n</p>\n<p>Maintenance &amp; Repair:</p>\n<p>➺ Store the purse in its dust bag when not in use to maintain its pristine condition</p>\n<p>➺ For any repairs or maintenance inquiries, please contact Tierraboutique20@gmail.com</p>',0,'Princessa, Kate\'s');
/*!40000 ALTER TABLE `products_backup` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `products_brands`
--

DROP TABLE IF EXISTS `products_brands`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `products_brands` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `product_id` int(11) NOT NULL,
  `brand_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=74 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `products_brands`
--

LOCK TABLES `products_brands` WRITE;
/*!40000 ALTER TABLE `products_brands` DISABLE KEYS */;
INSERT INTO `products_brands` VALUES (3,2,1),(6,4,1),(7,4,2),(8,5,5),(13,0,5),(23,15,5),(46,3,4),(47,3,3),(48,10,1),(49,10,2),(50,10,3),(53,16,5),(55,17,3),(72,1,1),(73,1,2);
/*!40000 ALTER TABLE `products_brands` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `products_categories`
--

DROP TABLE IF EXISTS `products_categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `products_categories` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `product_id` int(11) NOT NULL,
  `category_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=1044 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `products_categories`
--

LOCK TABLES `products_categories` WRITE;
/*!40000 ALTER TABLE `products_categories` DISABLE KEYS */;
INSERT INTO `products_categories` VALUES (385,47,3),(386,47,5),(450,63,4),(451,63,2),(452,63,5),(458,62,4),(459,62,2),(460,62,5),(473,66,4),(474,66,2),(477,67,4),(478,67,2),(816,65,4),(817,65,2),(818,65,5),(819,65,1),(885,76,1),(939,68,4),(940,68,2),(941,51,3),(942,51,2),(943,55,2),(945,44,3),(946,49,3),(947,50,3),(948,50,2),(949,48,3),(950,91,2),(951,91,4),(952,91,1),(953,57,2),(954,69,2),(955,69,1),(956,38,3),(957,38,1),(958,40,3),(959,40,1),(960,39,2),(961,61,2),(962,52,2),(963,52,1),(964,53,2),(965,53,1),(966,42,3),(967,43,3),(968,46,3),(969,74,2),(970,74,1),(971,56,2),(972,45,3),(973,59,2),(978,41,3),(979,41,1),(980,58,2),(981,60,2),(986,72,2),(987,72,1),(988,73,2),(989,73,1),(990,75,2),(991,75,1),(992,92,2),(993,92,4),(994,92,1),(995,70,2),(996,70,1),(997,71,2),(998,71,1),(1007,54,2),(1040,64,4),(1041,64,2),(1042,64,5),(1043,64,1);
/*!40000 ALTER TABLE `products_categories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `products_subcategories`
--

DROP TABLE IF EXISTS `products_subcategories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `products_subcategories` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `product_id` int(11) NOT NULL,
  `subcategory_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=61 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `products_subcategories`
--

LOCK TABLES `products_subcategories` WRITE;
/*!40000 ALTER TABLE `products_subcategories` DISABLE KEYS */;
INSERT INTO `products_subcategories` VALUES (3,2,1),(4,2,3),(7,4,1),(8,4,1),(9,5,1),(10,5,5),(34,3,4),(35,10,1),(36,10,2),(37,10,3),(40,16,1),(42,17,4),(59,1,1),(60,1,2);
/*!40000 ALTER TABLE `products_subcategories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `settings`
--

DROP TABLE IF EXISTS `settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `settings` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `value` int(11) NOT NULL DEFAULT 0,
  `cost` int(11) NOT NULL DEFAULT 0,
  `isActive` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `settings`
--

LOCK TABLES `settings` WRITE;
/*!40000 ALTER TABLE `settings` DISABLE KEYS */;
INSERT INTO `settings` VALUES (1,'Βάρος',10,2,0);
/*!40000 ALTER TABLE `settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `shipping_infos`
--

DROP TABLE IF EXISTS `shipping_infos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `shipping_infos` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `first_name` varchar(45) NOT NULL,
  `last_name` varchar(45) NOT NULL,
  `email` varchar(45) NOT NULL,
  `phone` varchar(45) DEFAULT NULL,
  `mobile` varchar(45) NOT NULL,
  `address` varchar(45) NOT NULL,
  `postcode` int(11) NOT NULL,
  `city` varchar(45) DEFAULT NULL,
  `region` varchar(45) DEFAULT NULL,
  `country_id` int(11) NOT NULL,
  `prefecture_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `shipping_infos`
--

LOCK TABLES `shipping_infos` WRITE;
/*!40000 ALTER TABLE `shipping_infos` DISABLE KEYS */;
INSERT INTO `shipping_infos` VALUES (1,'vdvsv','sdvsvsvsvsvsv','mstaiko98@gmail.com','6977137837','6977137837','vdvds',13231,'athens',NULL,81,5),(2,'Maria ','Staikopoulou ','mstaiko98@gmail.com','6977137837','6977137837','Ermou',13221,'Peristeri',NULL,81,52),(3,'Maria ','Staikopoulou ','mstaiko98@gmail.com','6977137837','6977137837','Ermou',13221,'Peristeri',NULL,81,52),(4,'Christos','Krokidis','Chriskrokidis@gmail.com','6987703523','6987703523','Kanari',13231,'Petroupoli',NULL,81,9),(5,'Maria ','Staikopoulou ','mstaiko98@gmail.com','6977137837','6977137837','Ermou',13221,'Peristeri',NULL,81,52),(6,'vdvsv','sdvsvsvsvsvsv','mstaiko98@gmail.com','6977137837','6977137837','vdvds',13231,'',NULL,81,52);
/*!40000 ALTER TABLE `shipping_infos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `shipping_methods`
--

DROP TABLE IF EXISTS `shipping_methods`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `shipping_methods` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(45) NOT NULL,
  `description` varchar(45) DEFAULT NULL,
  `cost` int(11) NOT NULL DEFAULT 0,
  `isActive` int(11) DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `shipping_methods`
--

LOCK TABLES `shipping_methods` WRITE;
/*!40000 ALTER TABLE `shipping_methods` DISABLE KEYS */;
INSERT INTO `shipping_methods` VALUES (1,'COURIER',NULL,4,1),(2,'ΠΑΡΑΛΑΒΗ ΑΠΟ ΤΟ ΚΑΤΑΣΤΗΜΑ',NULL,0,0),(7,'test','test',0,0);
/*!40000 ALTER TABLE `shipping_methods` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `shipping_methods_prefectures`
--

DROP TABLE IF EXISTS `shipping_methods_prefectures`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `shipping_methods_prefectures` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `shipping_method_id` int(11) NOT NULL,
  `prefecture_id` int(11) NOT NULL,
  `cost` double NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=103 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `shipping_methods_prefectures`
--

LOCK TABLES `shipping_methods_prefectures` WRITE;
/*!40000 ALTER TABLE `shipping_methods_prefectures` DISABLE KEYS */;
INSERT INTO `shipping_methods_prefectures` VALUES (52,2,1,0),(53,1,1,4.3),(54,1,4,5),(55,1,5,5),(56,1,6,5),(57,1,7,5),(58,1,9,5),(59,1,10,5),(60,1,11,5),(61,1,12,5),(62,1,13,5),(63,1,14,5),(64,1,15,5),(65,1,16,5),(66,1,17,5),(67,1,18,5),(68,1,19,5),(69,1,20,5),(70,1,21,5),(71,1,22,5),(72,1,23,5),(73,1,24,5),(74,1,25,5),(75,1,26,5),(76,1,27,5),(77,1,28,5),(78,1,29,5),(79,1,30,5),(80,1,31,5),(81,1,32,5),(82,1,33,5),(83,1,34,5),(84,1,35,5),(85,1,36,5),(86,1,37,5),(87,1,38,5),(88,1,39,5),(89,1,40,5),(90,1,41,5),(91,1,42,5),(92,1,43,5),(93,1,44,5),(94,1,45,5),(95,1,46,5),(96,1,47,5),(97,1,48,5),(98,1,49,5),(99,1,50,5),(100,1,51,5),(101,1,52,5),(102,7,2,4.8);
/*!40000 ALTER TABLE `shipping_methods_prefectures` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `social_networks`
--

DROP TABLE IF EXISTS `social_networks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `social_networks` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(30) NOT NULL,
  `link` text NOT NULL,
  `isActive` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `social_networks`
--

LOCK TABLES `social_networks` WRITE;
/*!40000 ALTER TABLE `social_networks` DISABLE KEYS */;
INSERT INTO `social_networks` VALUES (1,'Instagram','https://www.instagram.com/tierra_purses/',1),(2,'Tik-Tok','https://www.tiktok.com/@tierra_purses',1),(3,'Facebook','https://www.facebook.com/tierrapurses',1);
/*!40000 ALTER TABLE `social_networks` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `static_pages`
--

DROP TABLE IF EXISTS `static_pages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `static_pages` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(45) NOT NULL,
  `description` text NOT NULL,
  `isActive` int(11) NOT NULL DEFAULT 0,
  `isMenu` int(11) NOT NULL DEFAULT 0,
  `isFooter` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `static_pages`
--

LOCK TABLES `static_pages` WRITE;
/*!40000 ALTER TABLE `static_pages` DISABLE KEYS */;
INSERT INTO `static_pages` VALUES (1,'Privacy Policy','<p><strong>Πολιτική Προστασίας Προσωπικών Δεδομένων</strong></p>\n<p>Με την παρούσα πολιτική η TIERRA PURSES καθορίζει και γνωστοποιεί τους όρους με τους οποίους, λειτουργώντας όπως ο νόμος ορίζει ως «Υπεύθυνος Επεξεργασίας», συλλέγει, αποθηκεύει, χρησιμοποιεί και εν γένει επεξεργάζεται τα προσωπικά δεδομένα σας, τα οποία συλλέγονται όταν επισκέπτεστε, εγγράφεστε ή χρησιμοποιείτε τον δικτυακό τόπο της Εταιρίας καθώς και όταν συναλλάσσεστε με τα φυσικά της καταστήματα. Η παρούσα Πολιτική περιγράφει επίσης τον τρόπο χρήσης, κοινοποίησης και προστασίας των προσωπικών δεδομένων σας, τις επιλογές που διαθέτετε αναφορικά με τα προσωπικά δεδομένα σας, καθώς και πώς μπορείτε να ασκήσετε τα δικαιώματά σας.</p>\n<p>Η παρούσα Πολιτική Προστασίας Προσωπικών Δεδομένων είναι σύμφωνη με τους όρους που απορρέουν από τον Ευρωπαϊκό Κανονισμό (ΕΕ) 2016/679 (Γενικός Κανονισμός για την Προστασία Δεδομένων - GDPR) και τις διατάξεις του Ν. 3471/2006, συμπληρωματικά εφαρμοζόμενες ως προς την προστασία των προσωπικών δεδομένων στις ηλεκτρονικές επικοινωνίες Εφαρμοστέο δίκαιο είναι το ελληνικό, όπως διαμορφώνεται με βάση το ισχύον εθνικό και ευρωπαϊκό νομοθετικό και κανονιστικό πλαίσιο για την προστασία προσωπικών δεδομένων.</p>\n<p>Υπεύθυνη Επεξεργασίας είναι η TIERRA PURSES, που εδρεύει στην Αθήνα και τηλέφωνο επικοινωνίας +30 6977137837.</p>\n<p>Για απορίες σας σχετικά με την παρούσα Πολιτική, αλλά και κάθε ζήτημα σχετικό με την επεξεργασία των Δεδομένων σας και την άσκηση των δικαιωμάτων σας, μπορείτε να απευθύνεστε στη δ/νση ηλεκτρονικού ταχυδρομείου (email) tierrapurses@outlook.com</p>\n<p><strong>1. Ποια Προσωπικά Δεδομένα σας συλλέγονται;</strong></p>\n<p>Η TIERRA PURSES ABEE συλλέγει μόνο τα απολύτως απαραίτητα Προσωπικά Δεδομένα, τα οποία είναι κατάλληλα, συναφή και αναγκαία για τον σκοπό που προορίζονται. Αυτά τα Δεδομένα περιλαμβάνουν τα εξής:</p>\n<p>α. Δεδομένα που παρέχετε κατά την εγγραφή σε newsletter μας ή κατά την εγγραφή σας και τη δημιουργία λογαριασμού χρήστη στον δικτυακό μας τόπο μέσω του διαδικτύου ή του κινητού σας ή μέσω της προσωπικής σας επαφής με τα καταστήματα μας ή τους αντιπροσώπους μας στην Ελλάδα και το εξωτερικό και συγκεκριμένα : όνομα, επίθετο, ταχυδρομική διεύθυνση, ηλεκτρονική διεύθυνση (e-mail), αριθμό σταθερού και κινητού τηλεφώνου και σε περίπτωση αγοράς με έκδοση τιμολογίου, επάγγελμα και ΑΦΜ.</p>\n<p>β. Δεδομένα και πληροφορίες που μας παρέχετε μέσα από τις μεταξύ μας συναλλαγές (αγορές, παραγγελίες κ.λπ.) και τη μεταξύ μας επικοινωνία (μέσω των φυσικών καταστημάτων, του ηλεκτρονικού μας καταστήματος, των αντιπροσώπων μας, του τηλεφώνου, ηλεκτρονικού ταχυδρομείου ή μέσω οποιουδήποτε άλλου τρόπου), όπως π.χ. πληροφορίες (feedback) σχετικά με τα προσφερόμενα προϊόντα και υπηρεσίες του ιστοτόπου, προϊόντα που προστέθηκαν στο καλάθι σας ή αφαιρέθηκαν από αυτό, λίστα προϊόντων που επιθυμείτε να αγοράσετε (wish list), συμμετοχή σε διαγωνισμούς κλπ. Οι πληροφορίες αυτές βοηθούν στη βελτίωση των παροχών μας.</p>\n<p>γ. Πληροφορίες που συλλέγονται από τη χρήση cookies στο πρόγραμμα περιήγησής σας.</p>\n<p><strong>2. Πώς χρησιμοποιούνται τα Προσωπικά Δεδομένα;</strong></p>\n<p>Κατά περίπτωση η TIERRA PURSES ABEE χρησιμοποιεί τα Δεδομένα σας:</p>\n<p>α. Για τη Δημιουργία Λογαριασμού Χρήστη: Η TIERRA PURSES ABEE επεξεργάζεται Δεδομένα σας προκειμένου να σας παρέχει τις λειτουργίες λογαριασμού και να διευκολυνθεί η σύναψη αγοράς προϊόντων ή/και υπηρεσιών. Ακύρωση του λογαριασμού εγγεγραμμένου χρήστη μπορεί να γίνει μέσω των Προτιμήσεων στο λογαριασμό σας.</p>\n<p>β. Για την εκτέλεση Σύμβασης πώλησης προϊόντων/ υπηρεσιών: Η επεξεργασία των Δεδομένων σας είναι απαραίτητη για την εκτέλεση της Σύμβασης που συνάπτετε μαζί μας κατά την πραγματοποίηση μιας αγοράς ή παροχής εκ μέρους μας υπηρεσιών.</p>\n<p>γ. Για την Επικοινωνία και την Εξυπηρέτηση Πελατών: Η TIERRA PURSES ABEE χρησιμοποιεί Δεδομένα σας για να απαντήσει στα αιτήματα/ερωτήματα που υποβάλλετε μέσω της εξυπηρέτησης πελατών, να διαχειρίζεται και να ενημερώνει για τα αιτήματα επιστροφής χρημάτων/ ακυρώσεων, να γνωστοποιεί πληροφορίες σε συμμόρφωση προς νομικές υποχρεώσεις της, όπως π.χ. αλλαγή στην πολιτική απορρήτου.</p>\n<p>δ. Για την Αποστολή ενημερωτικού δελτίου (newsletter)/ προσφορών: Με τη συγκατάθεσή σας, η TIERRA PURSES ABEE θα χρησιμοποιήσει τα Προσωπικά σας Δεδομένα, τις προτιμήσεις και τα στοιχεία των συναλλαγών σας για να σας ενημερώνει μέσω e-mail, διαδικτύου, τηλεφώνου ή/και μέσω μέσων κοινωνικής δικτύωσης για νέα προϊόντα και υπηρεσίες, συμπεριλαμβανομένων εξατομικευμένων/ προσωποποιημένων προσφορών, για τη διενέργεια διαγωνισμών, την παροχή προσφορών, τη διεξαγωγή προωθητικών ενεργειών, τη διαφημιστική προβολή και προώθηση του ιστοτόπου από απόσταση. Διαγραφή από το ενημερωτικό δελτίο γίνεται οποτεδήποτε με την επιλογή του συνδέσμου «Για διαγραφή από τη «λίστα αποστολής newsletter» κάντε κλικ εδώ» που βρίσκεται στο κάτω μέρος κάθε newsletter.</p>\n<p>ε. Για την ανάπτυξη και βελτίωση των προϊόντων και των υπηρεσιών: Η TIERRA ABEΕ επεξεργάζεται τα Δεδομένα σας για να είναι σε θέση, με βάση τα νόμιμα επιχειρηματικά της συμφέροντα, να βελτιώσει το επίπεδο των προϊόντων και των υπηρεσιών της, καθώς και την αναγνωρισιμότητα του ιστοτόπου της. Σε περίπτωση που η εταιρία διεξάγει, στα πλαίσια βελτίωσης των προϊόντων και των υπηρεσιών της, έρευνα αγοράς, θα ζητηθεί πρώτα η συναίνεσή σας στην επεξεργασία των δεδομένων σας.</p>\n<p><strong>3. Ποια είναι η νόμιμη βάση επεξεργασίας των Δεδομένων σας;</strong></p>\n<p>Αναλόγως με τον σκοπό της επεξεργασίας, οι νόμιμες βάσεις που επιτρέπουν στην TIERRA ABEΕ να επεξεργάζεται τα προσωπικά σας δεδομένα, σύμφωνα με την ισχύουσα νομοθεσία, είναι κατά περίπτωση οι εξής:</p>\n<p>Οι υποχρεώσεις της Εταιρίας που πηγάζουν είτε απευθείας από τον νόμο (π.χ. φορολογική νομοθεσία, νομοθεσία για το ηλεκτρονικό εμπόριο κ.ά.) είτε από Σύμβαση που συνάπτετε με την εταιρία κατά την αγορά προϊόντος ή τη λήψη μίας υπηρεσίας.</p>\n<p>Η συγκατάθεσή σας, όπου απαιτείται, π.χ. όταν επιλέγετε να λαμβάνετε newsletter.</p>\n<p>Το έννομο συμφέρον της Εταιρίας. Σε συγκεκριμένες περιπτώσεις, επεξεργάζονται τα Δεδομένα σας διότι αποτελεί μέρος της λειτουργίας της επιχείρησης, στο πλαίσιο της βελτίωσης των παρεχομένων προϊόντων και υπηρεσιών, χωρίς η επξεργασία αυτή να θίγει τα δικαιώματα, τις ελευθερίες ή τα συμφέροντά σας.</p>\n<p><strong>4. Ποιος έχει πρόσβαση στα Δεδομένα σας;</strong></p>\n<p>Πρόσβαση στα Δεδομένα σας έχει το απολύτως απαραίτητο προσωπικό της TIERRA ABEΕ, το οποίο έχει δεσμευτεί με τήρηση εμπιστευτικότητας και οι συνεργαζόμενες επιχειρήσεις ή τρίτοι πάροχοι υπηρεσιών, όπως ενδεικτικά χρηματοοικονομικοί οργανισμοί για την επεξεργασία πιστωτικών καρτών και πληρωμών, πάροχοι υπηρεσιών τεχνολογίας, μάρκετινγκ, διαφήμισης, λογιστικής υποστήριξης, μεταφοράς και παράδοσης, οι οποίοι επεξεργάζονται τα Δεδομένα σας ως Εκτελούντες την Επεξεργασία για λογαριασμό μας και σύμφωνα με τις εντολές μας.</p>\n<p>Για το σκοπό αυτό η TIERRA ABEΕ χρησιμοποιεί μόνο Εκτελούντες την Επεξεργασία που παρέχουν επαρκείς διαβεβαιώσεις για την εφαρμογή κατάλληλων τεχνικών και οργανωτικών μέτρων, κατά τρόπο ώστε η επεξεργασία να πληροί τις απαιτήσεις του Κανονισμού και να διασφαλίζεται η προστασία των δικαιωμάτων σας. Ειδικότερα, στα πλαίσια έγγραφων συμφωνιών που συνάπτει η TIERRA ABEΕ με τους Εκτελούντες την Επεξεργασία:</p>\n<p>Τους παρέχουμε μόνο τις πληροφορίες που χρειάζονται για την εκτέλεση των συγκεκριμένων υπηρεσιών τους.</p>\n<p>Μπορούν να χρησιμοποιήσουν τα Δεδομένα σας μόνο για τους ακριβείς σκοπούς που καθορίζουμε στη σύμβασή μας μαζί τους.</p>\n<p>Αν σταματήσουμε να χρησιμοποιούμε τις υπηρεσίες τους, οποιαδήποτε από τα δεδομένα που κατέχουν θα διαγραφούν ή θα καταστούν ανώνυμα.</p>\n<p>Έχουν συμφωνήσει και δεσμευτεί συμβατικά να τηρούν εχεμύθεια, να μη στέλνουν σε τρίτους Δεδομένα σας χωρίς την άδειά μας, να λαμβάνουν κατάλληλα μέτρα ασφάλειας και να συμμορφώνονται με το νομικό πλαίσιο για την προστασία των προσωπικών δεδομένων και ιδίως τον Γενικό Κανονισμό για την Προστασία των Δεδομένων.</p>\n<p><strong>5. Για πόσο χρονικό διάστημα διατηρούνται τα Δεδομένα σας;</strong></p>\n<p>Η TIERRA ABEΕ διατηρεί τα Προσωπικά Δεδομένα σας όσο χρειάζεται για να εκπληρώσει τους σκοπούς που ορίζονται στην παρούσα Πολιτική (εκτός αν απαιτείται από την ισχύουσα νομοθεσία μεγαλύτερη περίοδος διατήρησης). Ειδικότερα, τα Προσωπικά σας Δεδομένα θα διατηρηθούν ανάλογα με το σκοπό ως εξής:</p>\n<p>Ως προς τα δεδομένα του Λογαριασμού Χρήστη: Για όσο καιρό παραμένετε εγγεγραμμένος χρήστης.</p>\n<p>Ως προς τα δεδομένα για την εκτέλεση Σύμβασης αγοράς προϊόντων ή παροχής υπηρεσιών: Για όσο χρόνο απαιτείται για τη διαχείριση της αγοράς προϊόντων ή παροχής υπηρεσιών, συμπεριλαμβανομένου του χρόνου που ορίσθηκε συμβατικά για τυχόν επιστροφές ή ορίζεται από το νόμο για το ενδεχόμενο άσκησης αστικών αξιώσεων ή τη φορολογική ή την εμπορική νομοθεσία (π.χ. για λόγους παροχής εγγύησης όπου συντρέχει).</p>\n<p>Ως προς τα δεδομένα για την Εξυπηρέτηση Πελατών: Για όσο χρόνο απαιτείται για να ικανοποιήσουμε το αίτημα ή να απαντήσουμε στο ερώτημά σας, αν δεν συντρέχει κάποια άλλη από τις εδώ αναφερόμενες περιπτώσεις διατήρησης των δεδομένων Εάν συμμετέχετε σε προωθητικές ενέργειες ή διαγωνισμούς θα διατηρήσουμε τα δεδομένα σας για μία περίοδο έξι μηνών μετά τη λήξη της ενέργειας/ διαγωνισμού, εκτός αν ρητώς ορίζεται μεγαλύτερη ή μικρότερη χρονική διάρκεια στους ειδικότερους όρους της εκάστοτε προωθητικής ενέργειας/ διαγωνισμού.</p>\n<p>Ως προς τα τηρούμενα για λόγους απευθείας εμπορικής προώθησης (μάρκετινγκ) δεδομένα: Μέχρι να διαγραφείτε ή να ακυρώσετε την εγγραφή σας στο ενημερωτικό δελτίο.</p>\n<p>Μετά την παρέλευση της εκάστοτε κατά τα ανωτέρω προσδιοριζόμενης περιόδου διατήρησης, καθώς και του χρονικού διαστήματος κατά το οποίο θα μπορούσε να προκύψει ευθύνη από την επεξεργασία, σύμφωνα με την εκάστοτε ισχύουσα νομοθεσία για την προστασία προσωπικών δεδομένων, τα δεδομένα σας θα διαγραφούν πλήρως ή θα καταστούν ανώνυμα, για παράδειγμα με τη συγκέντρωση με άλλα δεδομένα, έτσι ώστε να μπορούν να χρησιμοποιηθούν με μη αναγνωρίσιμο τρόπο για στατιστική ανάλυση και επιχειρηματικό προγραμματισμό.</p>\n<p><strong>6. Είναι ασφαλή τα Δεδομένα σας;</strong></p>\n<p>Η TIERRA ABEΕ δεσμεύεται ότι τα Προσωπικά σας Δεδομένα:</p>\n<p>υποβάλλονται σε σύννομη και θεμιτή επεξεργασία με διαφανή τρόπο</p>\n<p>συλλέγονται για καθορισμένους, ρητούς και νόμιμους σκοπούς και δεν υποβάλλονται σε περαιτέρω επεξεργασία κατά τρόπο ασύμβατο προς τους σκοπούς αυτούς.</p>\n<p>είναι κατάλληλα, συναφή και περιορίζονται στο αναγκαίο για τους σκοπούς για τους οποίους υποβάλλονται σε επεξεργασία.</p>\n<p>είναι ακριβή και όταν είναι αναγκαίο επικαιροποιούνται</p>\n<p>διατηρούνται υπό μορφή που επιτρέπει την ταυτοποίηση των φυσικών προσώπων μόνο για το διάστημα που απαιτείται για τους σκοπούς της επεξεργασίας.</p>\n<p>υποβάλλονται σε επεξεργασία κατά τρόπο που εγγυάται την ενδεδειγμένη ασφάλεια των δεδομένων, μεταξύ άλλων την προστασία τους από μη εξουσιοδοτημένη ή παράνομη επεξεργασία και τυχαία απώλεια, καταστροφή ή φθορά, με τη χρησιμοποίηση κατάλληλων τεχνικών ή οργανωτικών μέτρων. Έτσι, ενδεικτικά η TIERRA ABEE και οι εκτελούντες για λογαριασμό της την επεξεργασία εφαρμόζουν μέτρα τα οποία διασφαλίζουν σε συνεχή βάση το απόρρητο, την ακεραιότητα, τη διαθεσιμότητα και την αξιοπιστία των συστημάτων και των υπηρεσιών επεξεργασίας, αποκαθιστούν σε εύθετο χρόνο τη διαθεσιμότητα και την πρόσβαση στα δεδομένα σε περίπτωση φυσικού ή τεχνικού συμβάντος και δοκιμάζουν, εκτιμούν και αξιολογούν σε τακτική βάση την αποτελεσματικότητα των μέτρων αυτών.</p>\n<p><strong>7. Ποια είναι τα δικαιώματά σας;</strong></p>\n<p><strong>Πρόσβασης στα Προσωπικά σας Δεδομένα.</strong></p>\n<p>Αυτό σημαίνει ότι έχετε το δικαίωμα να ενημερωθείτε από εμάς εάν επεξεργαζόμαστε Δεδομένα σας. Αν επεξεργαζόμαστε Δεδομένα σας μπορείτε να ζητήσετε να ενημερωθείτε για τον σκοπό της επεξεργασίας, το είδος των Δεδομένων σας που τηρούμε, σε ποιους κοινολογήθηκαν, πόσο διάστημα τα αποθηκεύουμε, αν γίνεται αυτοματοποιημένη λήψη αποφάσεων, αλλά και για τα λοιπά δικαιώματα σας, όπως διόρθωσης, διαγραφής δεδομένων, περιορισμού της επεξεργασίας και υποβολής καταγγελίας στην Αρχή Προστασίας Προσωπικών Δεδομένων.</p>\n<p><strong>Διόρθωσης ανακριβών δεδομένων προσωπικού χαρακτήρα.</strong></p>\n<p>Αν διαπιστώσετε ότι υφίσταται λάθος στα Δεδομένα σας μπορείτε να μας υποβάλετε αίτηση για να τα διορθώσουμε (π.χ. διόρθωση ονόματος ή ενημέρωση αλλαγής διεύθυνσης). Αν είστε εγγεγραμμένος χρήστης, μπορείτε να τροποποιήσετε ή επικαιροποιήσετε τα προσωπικά σας δεδομένα μέσω του Λογαριασμού σας.</p>\n<p><strong>Διαγραφής.</strong></p>\n<p>Μπορείτε να μας ζητήσετε να διαγράψουμε τα δεδομένα σας αν δεν είναι απαραίτητα πλέον για τους ως άνω αναφερόμενους σκοπούς επεξεργασίας ή επιθυμείτε να ανακαλέσετε τη συγκατάθεσή σας στην περίπτωση που αυτή είναι η μόνη νόμιμη βάση επεξεργασίας τους, στέλνοντας το αίτημά σας εδώ: tierrapurses@outlook.com . Μόλις λάβουμε και επιβεβαιώσουμε το αίτημά σας, θα διαγράψουμε (και θα κατευθύνουμε τους παρόχους υπηρεσιών μας να διαγράψουν) τα προσωπικά σας στοιχεία από τα αρχεία μας, εκτός εάν ισχύει εξαίρεση.</p>\n<p><strong>Περιορισμού της επεξεργασίας.</strong></p>\n<p>Μπορείτε να μας ζητήσετε να περιορίσουμε την επεξεργασία των Δεδομένων σας για όσο χρόνο εκκρεμεί η εξέταση τυχόν αντιρρήσεών σας ως προς την επεξεργασία ή μέχρι να διαπιστωθεί η ακρίβειά τους, εφόσον την αμφισβητείτε. Επίσης μπορείτε να ζητήσετε τον περιορισμό της επεξεργασίας, εφόσον τα δεδομένα δεν είναι πλέον απαραίτητα για τους σκοπούς της επεξεργασίας αλλά απαιτούνται για την εκ μέρους σας άσκηση νομικών αξιώσεων.</p>\n<p><strong>Φορητότητας των Δεδομένων.</strong></p>\n<p>Μπορείτε να μας ζητήσετε να λάβετε σε αναγνώσιμη μορφή τα Δεδομένα που έχετε παράσχει ή να μας ζητήσετε να τα διαβιβάσουμε απευθείας σε άλλο υπεύθυνο επεξεργασίας.</p>\n<p><strong>Εναντίωσης και ανάκλησης συγκατάθεσης στην επεξεργασία των Δεδομένων σας.</strong></p>\n<p>Μπορείτε να αντιταχθείτε στην επεξεργασία των Δεδομένων σας για λόγους που σχετίζονται με την προσωπική σας κατάσταση και δεν θα υποβάλλουμε εφεξής τα Δεδομένα σας σε επεξεργασία, εκτός αν υφίστανται άλλοι επιτακτικοί και νόμιμοι λόγοι για την επεξεργασία που υπερισχύουν έναντι του δικαιώματός σας ή για τη θεμελίωση, άσκηση ή υποστήριξη νομικών αξιώσεων. Εάν έχετε δηλώσει τη συγκατάθεσή σας για την επεξεργασία των δεδομένων σας, μπορείτε να ανακαλέσετε τη συγκατάθεσή σας ανά πάσα στιγμή με μελλοντική ισχύ, επιλέγοντας να μη λαμβάνετε επικοινωνίες marketing, πατώντας το link «διαγραφή» ή ακολουθώντας τις οδηγίες που περιλαμβάνονται στο μήνυμα. Για να ασκήσετε τα δικαιώματα σας μπορείτε να μας υποβάλετε σχετικό αίτημα στην ηλεκτρονική διεύθυνση tierrapurses@outlook.com και εμείς θα το εξετάσουμε και θα σας απαντήσουμε το συντομότερο δυνατό.</p>\n<p><strong>Καταγγελίας.</strong></p>\n<p>Έχετε δικαίωμα να υποβάλετε καταγγελία στην Αρχή Προστασίας Προσωπικών Δεδομένων (ταχυδρομική δ/νση Κηφισίας 1-3, Τ.Κ. 115 23, Αθήνα, τηλ. 2106475600, δ/νση ηλεκτρονικού ταχυδρομείου (e-mail) contact@dpa.gr), αν θεωρείτε ότι η επεξεργασία των Προσωπικών Δεδομένων σας παραβαίνει τον Γενικό Κανονισμό για την Προστασία Δεδομένων ή το εν γένει ισχύον νομικό πλαίσιο για την προστασία των προσωπικών δεδομένων.</p>\n<p><strong>8. Πώς θα ενημερωθείτε για τυχόν τροποποιήσεις της παρούσας Πολιτικής;</strong></p>\n<p>Η TIERRA ABEE τροποποιεί την παρούσα Πολιτική Προστασίας Προσωπικών Δεδομένων όποτε αυτό είναι αναγκαίο. Εάν υπάρχουν σημαντικές αλλαγές στην Πολιτική Απορρήτου ή στον τρόπο με τον οποίο χρησιμοποιούμε τα Προσωπικά Δεδομένα σας, θα δημοσιεύουμε στην ιστοσελίδα μας την επικαιροποίηση της παρούσας, προτού οι αλλαγές τεθούν σε ισχύ και θα σας ειδοποιούμε με κάθε πρόσφορο τρόπο, ώστε να μπορείτε να ελέγξετε τις αλλαγές, να τις αξιολογήσετε και, κατά περίπτωση, να εναντιωθείτε ή να διαγραφείτε από μια υπηρεσία ή λειτουργία. Σας ενθαρρύνουμε να διαβάζετε, ανά τακτά διαστήματα, την παρούσα Πολιτική για να γνωρίζετε πώς προστατεύονται τα Δεδομένα σας.</p>\n<p>Έχετε τα ακόλουθα <strong>δικαιώματα</strong> επί των προσωπικών δεδομένων, που μας έχετε γνωστοποιήσει:</p>\n<p>Να έχετε πρόσβαση στα προσωπικά δεδομένα και να ενημερώνεστε για τον τρόπο συλλογής, επεξεργασίας, διατήρησης και αποθήκευσής τους.</p>\n<p>Να μας ζητήσετε να διορθώσουμε ή να συμπληρώσουμε τα προσωπικά σας δεδομένα.</p>\n<p>Να μας ζητήσετε να διαγράψουμε τα προσωπικά δεδομένα ή να περιορίσουμε την επεξεργασία τους, υπό τις νόμιμες προϋποθέσεις.</p>\n<p>Να ζητήσετε να διακόψουμε την επεξεργασία αν διαφωνείτε με αυτήν ή ανακαλέσετε τη συγκατάθεσή σας για λήψη ενημερωτικών δελτίων και υπηρεσιών marketing.</p>\n<p>Να σταματήσετε να λαμβάνετε προωθητικά/διαφημιστικά μηνύματα, επιλέγοντας τον σύνδεσμο «διαγραφή», ο οποίος υπάρχει σε κάθε σχετικό email που σας αποστέλλουμε.</p>\n<p>Να αντιταχθείτε στην αυτοματοποιημένη επεξεργασία των δεδομένων σας, συμπεριλαμβανομένης της κατάρτισης προφίλ.</p>\n<p>Να λαμβάνετε τα δεδομένα προσωπικού χαρακτήρα, σε δομημένο, κοινώς χρησιμοποιούμενο και αναγνώσιμο από μηχανήματα μορφότυπο ή/ και να ζητήσετε να διαβιβαστούν σε άλλον υπεύθυνο επεξεργασίας (δικαίωμα στη φορητότητα).</p>\n<p>Να υποβάλετε καταγγελία στην Αρχή Προστασίας Προσωπικών Δεδομένων (ταχυδρομική δ/νση Κηφισίας 1-3, Τ.Κ. 115 23, Αθήνα, τηλ. 2106475600, δ/νση ηλεκτρονικού ταχυδρομείου (e-mail): contact@dpa.gr)</p>\n<p>Για να ασκήσετε τα δικαιώματα σας μπορείτε να μας υποβάλετε σχετικό αίτημα στην ηλεκτρονική διεύθυνση tierrapurses@outlook.com και εμείς θα το εξετάσουμε και θα σας απαντήσουμε το συντομότερο δυνατό.</p>\n<p>Η παρούσα Πολιτική Προστασίας Προσωπικών Δεδομένων τροποποιήθηκε για τελευταία φορά τον Απρίλιο του 2024.</p>',1,0,0),(2,'Payment Methods','<p>Πραγματοποιήστε εύκολα, γρήγορα &amp; με ασφάλεια τις αγορές σας μέσα από το ηλεκτρονικό κατάστημα της TIERRA PURSES, επιλέγοντας τον τρόπο πληρωμής που εξυπηρετεί τις ανάγκες σας:</p>\n<p><strong>Πληρωμή με Αντικαταβολή</strong></p>\n<p>Κατά την παράδοση της παραγγελίας Επιλέξτε την πληρωμή με αντικαταβολή, για εξόφληση κατά την παράδοση της παραγγελίας σας στον υπάλληλο της εταιρείας ταχυμεταφορών. Τα έξοδα αντικαταβολής για αγορές από το eshop της TIERRA PURSES ανέρχονται στα 2€ ανά αποστολή. Για παραγγελίες άνω των 500€ προς ιδιώτες (Απόδειξη Λιανικής), δεν προσφέρεται δυνατότητα αντικαταβολής, καθόσον δεν επιτρέπεται η πληρωμή σε μετρητά.</p>\n<p><strong>Πληρωμή με Κατάθεση / Έμβασμα</strong></p>\n<p>Μπορείτε να εξοφλήσετε τις αγορές σας με πληρωμή μέσω κατάθεσης / εμβάσματος στον τραπεζικό λογαριασμό της TIERRA PURSES αμέσως μετά την καταχώρηση της παραγγελίας σας. Στην αιτιολογία κατάθεσης παρακαλούμε να αναφέρετε πρώτα τον αριθμό της παραγγελίας σας, έπειτα το επώνυμο σας, και στη συνέχεια το όνομά σας. Απαντήστε στο e-mail επιβεβαίωσης της παραγγελίας με το αποδεικτικό πληρωμής.</p>\n<p><strong>PIRAEUS BANK:</strong></p>\n<p><strong>Δικαιούχος: ΣΤΑΙΚΟΠΟΥΛΟΥ ΜΑΡΙΑ ΜΑΓΔΑΛΗΝΗ</strong></p>',1,0,0),(3,'Shipping Methods','<p>Η TIERRA PURSES σας αποστέλλει τα προϊόντα της με συνεργαζόμενες εταιρείες ταχυμεταφορών (ACS, Γενική Ταχυδρομική).</p>\n<p>Οι παραγγελίες εκτελούνται σε διάστημα από <strong>6 έως 12 εργάσιμες ημέρες.</strong></p>\n<p>Όλες οι παραδόσεις γίνονται με courier. Τα έξοδα αποστολής είναι ΔΩΡΕΑΝ εντός Αττικής.</p>\n<p>Σε περίοδο εκπτώσεων, η αποστολή και παράδοση μπορεί να παραταθεί κατά 7 εργάσιμες ημέρες.</p>\n<p>Στις τιμές των προϊόντων συμπεριλαμβάνεται ΦΠΑ.</p>\n<p>Εάν το προϊόν της παραγγελίας σας αφορά δώρο, παρακαλούμε να το επισημάνετε στις παρατηρήσεις, ώστε να αποσταλεί ανάλογη συσκευασία.</p>',1,0,0),(4,'Our Story','<p><img src=\"https://api.tierrapurses.com/images/ourstorynew.png\" width=\"945\" height=\"1680\"/></p>',1,0,1);
/*!40000 ALTER TABLE `static_pages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `statuses`
--

DROP TABLE IF EXISTS `statuses`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `statuses` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(45) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `statuses`
--

LOCK TABLES `statuses` WRITE;
/*!40000 ALTER TABLE `statuses` DISABLE KEYS */;
INSERT INTO `statuses` VALUES (1,'ΚΑΤΑΧΩΡΗΘΗΚΕ'),(2,'ΑΠΕΣΤΑΛΗ'),(3,'ΑΚΥΡΩΘΗΚΕ');
/*!40000 ALTER TABLE `statuses` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `subcategories`
--

DROP TABLE IF EXISTS `subcategories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `subcategories` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(45) NOT NULL,
  `description` text DEFAULT NULL,
  `isActive` int(11) DEFAULT 1,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `subcategories`
--

LOCK TABLES `subcategories` WRITE;
/*!40000 ALTER TABLE `subcategories` DISABLE KEYS */;
INSERT INTO `subcategories` VALUES (1,'ΑΝΤΗΛΙΑΚΗ ΠΡΟΣΤΑΣΙΑ',NULL,0),(2,'ΠΡΟΣΩΠΟ','',0),(3,'ΡΥΤΙΔΕΣ',NULL,0),(4,'ΣΤΟΜΑΤΙΚΗ ΠΡΟΣΤΑΣΙΑ',NULL,0);
/*!40000 ALTER TABLE `subcategories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_payment_info`
--

DROP TABLE IF EXISTS `user_payment_info`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_payment_info` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `first_name` varchar(45) NOT NULL,
  `last_name` varchar(45) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_payment_info`
--

LOCK TABLES `user_payment_info` WRITE;
/*!40000 ALTER TABLE `user_payment_info` DISABLE KEYS */;
/*!40000 ALTER TABLE `user_payment_info` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_shipping_info`
--

DROP TABLE IF EXISTS `user_shipping_info`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_shipping_info` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `first_name` varchar(45) NOT NULL,
  `last_name` varchar(45) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_shipping_info`
--

LOCK TABLES `user_shipping_info` WRITE;
/*!40000 ALTER TABLE `user_shipping_info` DISABLE KEYS */;
/*!40000 ALTER TABLE `user_shipping_info` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(45) NOT NULL,
  `password` text NOT NULL,
  `isAdmin` int(11) NOT NULL DEFAULT 0,
  `email` varchar(100) NOT NULL,
  `isActive` int(11) NOT NULL DEFAULT 1,
  `birthDate` date NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,'a','$2a$12$aiGDqjV4uJidjAkeoT0RQOaX4R/8EzMqM2rVfl08Af/3P2odjtZ6O',0,'vakis_a@yahoo.gr',1,'2024-03-08'),(2,'admin','$2a$12$aiGDqjV4uJidjAkeoT0RQOaX4R/8EzMqM2rVfl08Af/3P2odjtZ6O',1,'vaios_a@outlook.com',1,'2024-03-08'),(3,'vaios','$2b$10$ukTrm/474LLn.q12sXsm7.zfXV1m0r/Ka0sS6bhrrohNi6NWx6Rdm',1,'vaios_a@yahoo.gr',1,'2024-03-08'),(4,'teo','$2b$10$EVPRv4LOaKQ0XLWStZtAo./CtkU7H85eTHL7oC97llDBjQsFYBDf.',0,'teo@teo.gr',1,'2024-03-08'),(5,'FASDFASDFADS','$2b$10$g/rU6b.QaS6izXqW08uNd.zUauBrRxuYhBJx9wb99UK9WEbaGSWyu',0,'FASDFA@FASDFSDA.GR',1,'2024-03-08'),(6,'bbb','$2b$10$FeBeTy5kZw5h/kaEx6vbbuMaQk0aFTJP5wKEXeQKS/ewd02Cft2.C',0,'bbb@bbb.gr',1,'2024-03-08'),(7,'bbbb','$2b$10$YqA.SpemtchbJ7oo5jS2S.QcRizcThLRfRzpphoM1EUS1k1Yz/uSG',0,'bbb@bbbbbbbb.gr',1,'2024-03-08'),(8,'ccc','$2b$10$lX40i9H3G0NESEQqcQE/Mu8nBFFpDMTlKTzaY7InDvnnMG79cdn8K',0,'ccc@ccc.gr',1,'2024-03-30'),(9,'ddd','$2b$10$9bYqMm4oluBiRYLCxFJtU.nmxu7AUolnQP3cNBwZ2X6H8LC87F7pW',0,'ddd@ddd.gr',1,'2024-03-28'),(10,'ttt','$2b$10$1BUtDipdSrWU28ayJ9sZ2OEqmcrnksa2BxAwaNqIihvQ0YdECcZAm',0,'ttt@ttt.gr',1,'0000-00-00'),(11,'yyy','$2b$10$YZFm0tyfC.MeT7L/PL3q2Of459XKlPompqcxTwXt.0k.XhQ7pAZsG',0,'yyy@yyy.gr',1,'2024-03-21'),(12,'MariaSt','$2b$10$Yw.TN2GcoQy1uA2kaaGbAu548HdgmTKg0OZfN05xYyZ4wD0ofCqLC',0,'tierraboutique20@gmail.com',1,'1998-03-08'),(13,'Lydia','$2b$10$X0m35VB2sj8L9dY/oiYvNOfPXlw3b56JEsgaQerSf/UdYhT6kfvze',0,'lidia.staikopoulou@gmail.com',1,'2005-10-21'),(14,'MARIASTAIK','$2a$12$aiGDqjV4uJidjAkeoT0RQOaX4R/8EzMqM2rVfl08Af/3P2odjtZ6O',0,'Mstaiko98@gmail.com',1,'1998-08-30'),(15,'testvaios','$2b$12$CIyaBrMOz/9anuauXv36e.fyyiTOah4CGYB5ynMgHqd0ZdLfwzqYW',0,'aaaa@aaaa.gr',1,'2001-05-14'),(16,'Maria','$2b$12$zarpD9FoLLZghHteCCFYCOSoOyg9yCmTSP1.S7hL03lw4M5C2R4Oa',0,'m.tasiadami@gmail.com',1,'1998-06-22');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wishlist_products`
--

DROP TABLE IF EXISTS `wishlist_products`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `wishlist_products` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wishlist_products`
--

LOCK TABLES `wishlist_products` WRITE;
/*!40000 ALTER TABLE `wishlist_products` DISABLE KEYS */;
/*!40000 ALTER TABLE `wishlist_products` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping routines for database 'tierradb'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-07-31 10:22:40
